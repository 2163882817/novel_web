import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/NovelSettingsView.vue");import { onMounted, reactive, ref } from "/node_modules/.vite/deps/vue.js?v=755ab909"
import { useRoute, useRouter } from "/node_modules/.vite/deps/vue-router.js?v=755ab909"
import {
  clearWritingRestrictions,
  createCharacter,
  createForeshadowing,
  createVolume,
  deleteCharacter,
  deleteForeshadowing,
  genVolumeOutline,
  genVolumeSummary,
  getMemory,
  importDoc,
  updateCharacter,
  updateForeshadowing,
  updateVolume,
} from "/src/api.js"
import { fmtTime } from "/src/utils.js"


const _sfc_main = {
  __name: 'NovelSettingsView',
  setup(__props, { expose: __expose }) {
  __expose();

const route = useRoute()
const router = useRouter()
const novelId = Number(route.params.id)

const memory = ref(null)
const tab = ref('characters')
const msg = ref('')
const msgOk = ref(true)

const CHAR_KEYS = ['外貌', '性格', '目标', '关系', '位置', '情感']

/* ---------- 人物卡 ---------- */
const charForm = reactive({ id: null, name: '', role: '配角', card: {} })

function newCharacter() {
  charForm.id = null
  charForm.name = ''
  charForm.role = '配角'
  charForm.card = {}
}

function editCharacter(c) {
  charForm.id = c.id
  charForm.name = c.name
  charForm.role = c.role
  charForm.card = { ...(c.card || {}) }
}

async function onSaveCharacter() {
  if (!charForm.name.trim()) {
    msg.value = '请填写角色名'
    msgOk.value = false
    return
  }
  try {
    if (charForm.id)
      await updateCharacter(charForm.id, { name: charForm.name, role: charForm.role, card: charForm.card })
    else await createCharacter(novelId, { name: charForm.name, role: charForm.role, card: charForm.card })
    msg.value = '已保存'
    msgOk.value = true
    newCharacter()
    await load()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  }
}

async function onDeleteCharacter(c) {
  if (!confirm(`删除人物卡「${c.name}」？`)) return
  try {
    await deleteCharacter(c.id)
    await load()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  }
}

/* ---------- 伏笔库 ---------- */
const fForm = reactive({ id: null, title: '', description: '', status: '待回收' })
const FS_STATUS = ['待回收', '已回收', '废弃']

function newForeshadowing() {
  fForm.id = null
  fForm.title = ''
  fForm.description = ''
  fForm.status = '待回收'
}

function editForeshadowing(f) {
  fForm.id = f.id
  fForm.title = f.title
  fForm.description = f.description
  fForm.status = f.status
}

async function onSaveForeshadowing() {
  if (!fForm.title.trim()) {
    msg.value = '请填写伏笔标题'
    msgOk.value = false
    return
  }
  try {
    if (fForm.id)
      await updateForeshadowing(fForm.id, { title: fForm.title, description: fForm.description, status: fForm.status })
    else await createForeshadowing(novelId, { title: fForm.title, description: fForm.description, status: fForm.status })
    msg.value = '已保存'
    msgOk.value = true
    newForeshadowing()
    await load()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  }
}

async function onDeleteForeshadowing(f) {
  if (!confirm(`删除伏笔「${f.title}」？`)) return
  try {
    await deleteForeshadowing(f.id)
    await load()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  }
}

/* ---------- 卷管理 ---------- */
const volumeForm = reactive({ id: null, title: '', status: '连载中', outline: '', summary: '' })
const showNewVolume = ref(false)
const newVolForm = reactive({ title: '', outline: '' })
const genningOutline = ref(false)
const genningSummary = ref(false)
const creatingVol = ref(false)

function selectVolume(v) {
  volumeForm.id = v.id
  volumeForm.title = v.title
  volumeForm.status = v.status
  volumeForm.outline = v.outline
  volumeForm.summary = v.summary
}

function openNewVolume() {
  const nextNo = (memory.value?.volumes?.length || 0) + 1
  newVolForm.title = `第${nextNo}卷`
  newVolForm.outline = ''
  showNewVolume.value = true
}

async function onGenVolumeOutline() {
  genningOutline.value = true
  try {
    const r = await genVolumeOutline(novelId)
    if (r.volume_title) newVolForm.title = r.volume_title
    newVolForm.outline = r.outline
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    genningOutline.value = false
  }
}

async function onCreateVolume() {
  creatingVol.value = true
  try {
    const v = await createVolume(novelId, { title: newVolForm.title, outline: newVolForm.outline })
    showNewVolume.value = false
    msg.value = `已开新卷：${v.title}（上一卷已自动完结）`
    msgOk.value = true
    await load()
    const fresh = memory.value.volumes.find((x) => x.id === v.id)
    if (fresh) selectVolume(fresh)
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    creatingVol.value = false
  }
}

async function onSaveVolume() {
  if (!volumeForm.id) return
  try {
    await updateVolume(volumeForm.id, {
      title: volumeForm.title,
      outline: volumeForm.outline,
      status: volumeForm.status,
    })
    msg.value = '卷已保存'
    msgOk.value = true
    await load()
    const fresh = memory.value.volumes.find((x) => x.id === volumeForm.id)
    if (fresh) selectVolume(fresh)
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  }
}

async function onGenVolumeSummary() {
  if (!volumeForm.id) return
  genningSummary.value = true
  try {
    const r = await genVolumeSummary(volumeForm.id)
    volumeForm.summary = r.summary
    msg.value = '卷摘要已生成'
    msgOk.value = true
    await load()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    genningSummary.value = false
  }
}

/* ---------- 设定导入 ---------- */
const importTexts = reactive({ bible: '', outline: '', characters: '', restrictions: '' })
const importMode = ref('replace')
const importing = ref(false)

function onFile(e, kind) {
  const f = e.target.files && e.target.files[0]
  if (!f) return
  const reader = new FileReader()
  reader.onload = () => {
    importTexts[kind] = String(reader.result || '')
  }
  reader.readAsText(f, 'utf-8')
  e.target.value = '' // 允许重复选择同一文件
}

async function onClearRestrictions() {
  if (!confirm('确定清空当前 AI 写作限制词文档？')) return
  importing.value = true
  try {
    const r = await clearWritingRestrictions(novelId)
    msg.value = r.message
    msgOk.value = true
    await load()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    importing.value = false
  }
}

async function onImport(kind) {
  const text = importTexts[kind].trim()
  if (!text) {
    msg.value = '请先选择文件或粘贴内容'
    msgOk.value = false
    return
  }
  if (
    (kind === 'characters' || kind === 'restrictions') &&
    importMode.value === 'replace' &&
    ((kind === 'characters' && memory.value?.characters?.length) ||
      (kind === 'restrictions' && memory.value?.writing_restrictions?.has_text))
  ) {
    const target = kind === 'characters'
      ? `现有 ${memory.value.characters.length} 张人物卡`
      : `现有限制词文档（${memory.value.writing_restrictions.length} 字）`
    if (!confirm(`将以「替换」模式导入，${target}将被覆盖。继续？`)) return
  }
  importing.value = true
  try {
    const r = await importDoc(novelId, { kind, text, mode: importMode.value })
    msg.value = r.message
    msgOk.value = true
    importTexts[kind] = ''
    await load()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    importing.value = false
  }
}

async function load() {
  try {
    memory.value = await getMemory(novelId)
    const cur = memory.value.volumes.find((v) => v.status === '连载中') || memory.value.volumes.at(-1)
    if (cur) selectVolume(cur)
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  }
}
onMounted(load)

const __returned__ = { route, router, novelId, memory, tab, msg, msgOk, CHAR_KEYS, charForm, newCharacter, editCharacter, onSaveCharacter, onDeleteCharacter, fForm, FS_STATUS, newForeshadowing, editForeshadowing, onSaveForeshadowing, onDeleteForeshadowing, volumeForm, showNewVolume, newVolForm, genningOutline, genningSummary, creatingVol, selectVolume, openNewVolume, onGenVolumeOutline, onCreateVolume, onSaveVolume, onGenVolumeSummary, importTexts, importMode, importing, onFile, onClearRestrictions, onImport, load, onMounted, reactive, ref, get useRoute() { return useRoute }, get useRouter() { return useRouter }, get clearWritingRestrictions() { return clearWritingRestrictions }, get createCharacter() { return createCharacter }, get createForeshadowing() { return createForeshadowing }, get createVolume() { return createVolume }, get deleteCharacter() { return deleteCharacter }, get deleteForeshadowing() { return deleteForeshadowing }, get genVolumeOutline() { return genVolumeOutline }, get genVolumeSummary() { return genVolumeSummary }, get getMemory() { return getMemory }, get importDoc() { return importDoc }, get updateCharacter() { return updateCharacter }, get updateForeshadowing() { return updateForeshadowing }, get updateVolume() { return updateVolume }, get fmtTime() { return fmtTime } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, normalizeClass as _normalizeClass, toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, renderList as _renderList, Fragment as _Fragment, withModifiers as _withModifiers, vModelText as _vModelText, withDirectives as _withDirectives, vModelSelect as _vModelSelect } from "/node_modules/.vite/deps/vue.js?v=755ab909"

const _hoisted_1 = { class: "novel-head" }
const _hoisted_2 = { class: "tabs" }
const _hoisted_3 = {
  key: 1,
  class: "mem-grid"
}
const _hoisted_4 = { class: "card" }
const _hoisted_5 = ["onClick"]
const _hoisted_6 = { class: "tag" }
const _hoisted_7 = ["onClick"]
const _hoisted_8 = {
  key: 0,
  class: "hint"
}
const _hoisted_9 = { class: "card" }
const _hoisted_10 = { class: "row2" }
const _hoisted_11 = ["onUpdate:modelValue", "placeholder"]
const _hoisted_12 = { class: "row" }
const _hoisted_13 = { class: "card" }
const _hoisted_14 = { class: "row2" }
const _hoisted_15 = ["value"]
const _hoisted_16 = { class: "row" }
const _hoisted_17 = { class: "f-list" }
const _hoisted_18 = ["onClick"]
const _hoisted_19 = { class: "hint" }
const _hoisted_20 = ["onClick"]
const _hoisted_21 = {
  key: 0,
  class: "hint"
}
const _hoisted_22 = { class: "vol-grid" }
const _hoisted_23 = ["onClick"]
const _hoisted_24 = { class: "hint" }
const _hoisted_25 = {
  key: 0,
  class: "card",
  style: {"margin-top":"14px"}
}
const _hoisted_26 = { class: "row2" }
const _hoisted_27 = {
  key: 0,
  class: "summary-box"
}
const _hoisted_28 = {
  key: 1,
  class: "hint"
}
const _hoisted_29 = { class: "row" }
const _hoisted_30 = ["disabled"]
const _hoisted_31 = ["disabled"]
const _hoisted_32 = { class: "hint" }
const _hoisted_33 = {
  key: 0,
  class: "hint"
}
const _hoisted_34 = {
  key: 1,
  class: "tags"
}
const _hoisted_35 = {
  key: 1,
  class: "hint"
}
const _hoisted_36 = { class: "modal" }
const _hoisted_37 = { class: "row" }
const _hoisted_38 = ["disabled"]
const _hoisted_39 = { class: "row" }
const _hoisted_40 = ["disabled"]
const _hoisted_41 = { class: "import-grid" }
const _hoisted_42 = { class: "card" }
const _hoisted_43 = { class: "row" }
const _hoisted_44 = ["disabled"]
const _hoisted_45 = { class: "card" }
const _hoisted_46 = { class: "row" }
const _hoisted_47 = ["disabled"]
const _hoisted_48 = { class: "card" }
const _hoisted_49 = { class: "row" }
const _hoisted_50 = ["disabled"]
const _hoisted_51 = { class: "card" }
const _hoisted_52 = {
  key: 0,
  class: "hint"
}
const _hoisted_53 = { class: "row" }
const _hoisted_54 = ["disabled"]
const _hoisted_55 = ["disabled"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", null, [
    _createElementVNode("div", _hoisted_1, [
      _createElementVNode("button", {
        class: "link",
        onClick: _cache[0] || (_cache[0] = $event => ($setup.router.push(`/novel/${$setup.novelId}`)))
      }, "← 返回工作台"),
      _cache[31] || (_cache[31] = _createElementVNode("h2", null, "设定 / 记忆", -1 /* CACHED */)),
      _cache[32] || (_cache[32] = _createElementVNode("span", { class: "hint" }, "人物卡、伏笔库、卷大纲与卷摘要会被自动注入 AI 写作的上下文中", -1 /* CACHED */))
    ]),
    _createElementVNode("div", _hoisted_2, [
      _createElementVNode("div", {
        class: _normalizeClass(["tab", { active: $setup.tab === 'characters' }]),
        onClick: _cache[1] || (_cache[1] = $event => ($setup.tab = 'characters'))
      }, "人物卡", 2 /* CLASS */),
      _createElementVNode("div", {
        class: _normalizeClass(["tab", { active: $setup.tab === 'foreshadowings' }]),
        onClick: _cache[2] || (_cache[2] = $event => ($setup.tab = 'foreshadowings'))
      }, "伏笔库", 2 /* CLASS */),
      _createElementVNode("div", {
        class: _normalizeClass(["tab", { active: $setup.tab === 'volume' }]),
        onClick: _cache[3] || (_cache[3] = $event => ($setup.tab = 'volume'))
      }, "卷管理 / 章摘要", 2 /* CLASS */),
      _createElementVNode("div", {
        class: _normalizeClass(["tab", { active: $setup.tab === 'import' }]),
        onClick: _cache[4] || (_cache[4] = $event => ($setup.tab = 'import'))
      }, "📥 导入设定", 2 /* CLASS */)
    ]),
    ($setup.msg)
      ? (_openBlock(), _createElementBlock("p", {
          key: 0,
          class: _normalizeClass(["msg", $setup.msgOk ? 'ok' : 'err'])
        }, _toDisplayString($setup.msg), 3 /* TEXT, CLASS */))
      : _createCommentVNode("v-if", true),
    _createCommentVNode(" ============ 人物卡 ============ "),
    ($setup.tab === 'characters' && $setup.memory)
      ? (_openBlock(), _createElementBlock("div", _hoisted_3, [
          _createElementVNode("aside", _hoisted_4, [
            _cache[33] || (_cache[33] = _createElementVNode("h3", null, "角色列表", -1 /* CACHED */)),
            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.memory.characters, (c) => {
              return (_openBlock(), _createElementBlock("div", {
                key: c.id,
                class: "mem-item",
                onClick: $event => ($setup.editCharacter(c))
              }, [
                _createElementVNode("span", null, _toDisplayString(c.name), 1 /* TEXT */),
                _createElementVNode("span", _hoisted_6, _toDisplayString(c.role), 1 /* TEXT */),
                _createElementVNode("button", {
                  class: "mini-del",
                  onClick: _withModifiers($event => ($setup.onDeleteCharacter(c)), ["stop"])
                }, "×", 8 /* PROPS */, _hoisted_7)
              ], 8 /* PROPS */, _hoisted_5))
            }), 128 /* KEYED_FRAGMENT */)),
            (!$setup.memory.characters.length)
              ? (_openBlock(), _createElementBlock("p", _hoisted_8, " 暂无人物卡。AI 定稿章节时会自动登记新角色；也可手工添加。 "))
              : _createCommentVNode("v-if", true),
            _createElementVNode("button", {
              class: "primary",
              style: {"margin-top":"10px"},
              onClick: $setup.newCharacter
            }, "＋ 新角色")
          ]),
          _createElementVNode("section", _hoisted_9, [
            _createElementVNode("h3", null, _toDisplayString($setup.charForm.id ? `编辑：${$setup.charForm.name}` : '新角色'), 1 /* TEXT */),
            _createElementVNode("div", _hoisted_10, [
              _createElementVNode("div", null, [
                _cache[34] || (_cache[34] = _createElementVNode("label", null, "角色名 *", -1 /* CACHED */)),
                _withDirectives(_createElementVNode("input", {
                  "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => (($setup.charForm.name) = $event)),
                  placeholder: "张三"
                }, null, 512 /* NEED_PATCH */), [
                  [_vModelText, $setup.charForm.name]
                ])
              ]),
              _createElementVNode("div", null, [
                _cache[36] || (_cache[36] = _createElementVNode("label", null, "身份", -1 /* CACHED */)),
                _withDirectives(_createElementVNode("select", {
                  "onUpdate:modelValue": _cache[6] || (_cache[6] = $event => (($setup.charForm.role) = $event))
                }, [...(_cache[35] || (_cache[35] = [
                  _createElementVNode("option", { value: "主角" }, "主角", -1 /* CACHED */),
                  _createElementVNode("option", { value: "反派" }, "反派", -1 /* CACHED */),
                  _createElementVNode("option", { value: "配角" }, "配角", -1 /* CACHED */)
                ]))], 512 /* NEED_PATCH */), [
                  [_vModelSelect, $setup.charForm.role]
                ])
              ])
            ]),
            (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.CHAR_KEYS, (k) => {
              return _createElementVNode("div", { key: k }, [
                _createElementVNode("label", null, _toDisplayString(k), 1 /* TEXT */),
                _withDirectives(_createElementVNode("input", {
                  "onUpdate:modelValue": $event => (($setup.charForm.card[k]) = $event),
                  placeholder: `${k}（可留空）`
                }, null, 8 /* PROPS */, _hoisted_11), [
                  [_vModelText, $setup.charForm.card[k]]
                ])
              ])
            }), 64 /* STABLE_FRAGMENT */)),
            _createElementVNode("div", _hoisted_12, [
              _createElementVNode("button", {
                class: "primary",
                onClick: $setup.onSaveCharacter
              }, "保存人物卡"),
              ($setup.charForm.id)
                ? (_openBlock(), _createElementBlock("button", {
                    key: 0,
                    onClick: $setup.newCharacter
                  }, "取消"))
                : _createCommentVNode("v-if", true)
            ])
          ])
        ]))
      : _createCommentVNode("v-if", true),
    _createCommentVNode(" ============ 伏笔库 ============ "),
    ($setup.tab === 'foreshadowings' && $setup.memory)
      ? (_openBlock(), _createElementBlock(_Fragment, { key: 2 }, [
          _createElementVNode("section", _hoisted_13, [
            _createElementVNode("h3", null, _toDisplayString($setup.fForm.id ? `编辑伏笔：${$setup.fForm.title}` : '新伏笔'), 1 /* TEXT */),
            _createElementVNode("div", _hoisted_14, [
              _createElementVNode("div", null, [
                _cache[37] || (_cache[37] = _createElementVNode("label", null, "伏笔标题 *", -1 /* CACHED */)),
                _withDirectives(_createElementVNode("input", {
                  "onUpdate:modelValue": _cache[7] || (_cache[7] = $event => (($setup.fForm.title) = $event)),
                  placeholder: "如：F01 神秘玉佩"
                }, null, 512 /* NEED_PATCH */), [
                  [_vModelText, $setup.fForm.title]
                ])
              ]),
              _createElementVNode("div", null, [
                _cache[38] || (_cache[38] = _createElementVNode("label", null, "状态", -1 /* CACHED */)),
                _withDirectives(_createElementVNode("select", {
                  "onUpdate:modelValue": _cache[8] || (_cache[8] = $event => (($setup.fForm.status) = $event))
                }, [
                  (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.FS_STATUS, (s) => {
                    return _createElementVNode("option", {
                      key: s,
                      value: s
                    }, _toDisplayString(s), 9 /* TEXT, PROPS */, _hoisted_15)
                  }), 64 /* STABLE_FRAGMENT */))
                ], 512 /* NEED_PATCH */), [
                  [_vModelSelect, $setup.fForm.status]
                ])
              ])
            ]),
            _cache[39] || (_cache[39] = _createElementVNode("label", null, "伏笔内容", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("textarea", {
              "onUpdate:modelValue": _cache[9] || (_cache[9] = $event => (($setup.fForm.description) = $event)),
              rows: "2",
              placeholder: "埋设了什么信息，未来要如何揭晓"
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.fForm.description]
            ]),
            _createElementVNode("div", _hoisted_16, [
              _createElementVNode("button", {
                class: "primary",
                onClick: $setup.onSaveForeshadowing
              }, "保存伏笔"),
              ($setup.fForm.id)
                ? (_openBlock(), _createElementBlock("button", {
                    key: 0,
                    onClick: $setup.newForeshadowing
                  }, "取消"))
                : _createCommentVNode("v-if", true)
            ])
          ]),
          _createElementVNode("div", _hoisted_17, [
            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.memory.foreshadowings, (f) => {
              return (_openBlock(), _createElementBlock("div", {
                key: f.id,
                class: "f-item",
                onClick: $event => ($setup.editForeshadowing(f))
              }, [
                _createElementVNode("div", null, [
                  _createElementVNode("span", {
                    class: _normalizeClass(["badge", f.status === '已回收' ? 'b-green' : f.status === '废弃' ? 'b-gray' : 'b-yellow'])
                  }, _toDisplayString(f.status), 3 /* TEXT, CLASS */),
                  _createElementVNode("b", null, _toDisplayString(f.title), 1 /* TEXT */)
                ]),
                _createElementVNode("div", _hoisted_19, _toDisplayString(f.description), 1 /* TEXT */),
                _createElementVNode("button", {
                  class: "mini-del",
                  onClick: _withModifiers($event => ($setup.onDeleteForeshadowing(f)), ["stop"])
                }, "×", 8 /* PROPS */, _hoisted_20)
              ], 8 /* PROPS */, _hoisted_18))
            }), 128 /* KEYED_FRAGMENT */)),
            (!$setup.memory.foreshadowings.length)
              ? (_openBlock(), _createElementBlock("p", _hoisted_21, " 暂无伏笔。AI 定稿时会自动登记新埋伏笔；也可手工添加（如按你的规划编号 F01~F16）。 "))
              : _createCommentVNode("v-if", true)
          ])
        ], 64 /* STABLE_FRAGMENT */))
      : _createCommentVNode("v-if", true),
    _createCommentVNode(" ============ 卷管理 / 章摘要 ============ "),
    ($setup.tab === 'volume' && $setup.memory)
      ? (_openBlock(), _createElementBlock(_Fragment, { key: 3 }, [
          _createElementVNode("div", {
            class: "shelf-head",
            style: {"margin-bottom":"10px"}
          }, [
            _cache[40] || (_cache[40] = _createElementVNode("h3", { style: {"margin":"0"} }, "卷列表", -1 /* CACHED */)),
            _cache[41] || (_cache[41] = _createElementVNode("div", { class: "spacer" }, null, -1 /* CACHED */)),
            _createElementVNode("button", {
              class: "primary",
              onClick: $setup.openNewVolume
            }, "＋ 开新卷")
          ]),
          _createElementVNode("div", _hoisted_22, [
            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.memory.volumes, (v) => {
              return (_openBlock(), _createElementBlock("div", {
                key: v.id,
                class: _normalizeClass(["vol-item", { active: $setup.volumeForm.id === v.id }]),
                onClick: $event => ($setup.selectVolume(v))
              }, [
                _createElementVNode("div", null, [
                  _createElementVNode("b", null, "第" + _toDisplayString(v.volume_no) + "卷 " + _toDisplayString(v.title), 1 /* TEXT */),
                  _createElementVNode("span", {
                    class: _normalizeClass(["badge", v.status === '连载中' ? 'b-yellow' : 'b-gray'])
                  }, _toDisplayString(v.status), 3 /* TEXT, CLASS */)
                ]),
                _createElementVNode("div", _hoisted_24, _toDisplayString(v.chapter_count) + " 章" + _toDisplayString(v.summary ? ' · 已有卷摘要' : ' · 未生成卷摘要'), 1 /* TEXT */)
              ], 10 /* CLASS, PROPS */, _hoisted_23))
            }), 128 /* KEYED_FRAGMENT */))
          ]),
          ($setup.volumeForm.id)
            ? (_openBlock(), _createElementBlock("section", _hoisted_25, [
                _createElementVNode("h3", null, "编辑：第 " + _toDisplayString($setup.memory.volumes.find((v) => v.id === $setup.volumeForm.id)?.volume_no) + " 卷", 1 /* TEXT */),
                _createElementVNode("div", _hoisted_26, [
                  _createElementVNode("div", null, [
                    _cache[42] || (_cache[42] = _createElementVNode("label", null, "卷名", -1 /* CACHED */)),
                    _withDirectives(_createElementVNode("input", {
                      "onUpdate:modelValue": _cache[10] || (_cache[10] = $event => (($setup.volumeForm.title) = $event))
                    }, null, 512 /* NEED_PATCH */), [
                      [_vModelText, $setup.volumeForm.title]
                    ])
                  ]),
                  _createElementVNode("div", null, [
                    _cache[44] || (_cache[44] = _createElementVNode("label", null, "状态", -1 /* CACHED */)),
                    _withDirectives(_createElementVNode("select", {
                      "onUpdate:modelValue": _cache[11] || (_cache[11] = $event => (($setup.volumeForm.status) = $event))
                    }, [...(_cache[43] || (_cache[43] = [
                      _createElementVNode("option", { value: "连载中" }, "连载中", -1 /* CACHED */),
                      _createElementVNode("option", { value: "完结" }, "完结", -1 /* CACHED */)
                    ]))], 512 /* NEED_PATCH */), [
                      [_vModelSelect, $setup.volumeForm.status]
                    ])
                  ])
                ]),
                _cache[45] || (_cache[45] = _createElementVNode("label", null, "卷大纲（细纲师规划每章的总依据）", -1 /* CACHED */)),
                _withDirectives(_createElementVNode("textarea", {
                  "onUpdate:modelValue": _cache[12] || (_cache[12] = $event => (($setup.volumeForm.outline) = $event)),
                  rows: "8",
                  placeholder: "如：本卷围绕「宗门大比」展开：1-5 章报名与暗流 → 6-10 章初赛黑马 → 11-15 章决赛对手使诈 → 16-18 章揭穿阴谋夺冠 → 卷末钩子：神秘长老现身"
                }, null, 512 /* NEED_PATCH */), [
                  [_vModelText, $setup.volumeForm.outline]
                ]),
                _cache[46] || (_cache[46] = _createElementVNode("label", null, "卷摘要（由 AI 汇总本卷各章摘要生成）", -1 /* CACHED */)),
                ($setup.volumeForm.summary)
                  ? (_openBlock(), _createElementBlock("div", _hoisted_27, _toDisplayString($setup.volumeForm.summary), 1 /* TEXT */))
                  : (_openBlock(), _createElementBlock("p", _hoisted_28, "未生成。章节定稿后点「✨ AI 生成卷摘要」。")),
                _createElementVNode("div", _hoisted_29, [
                  _createElementVNode("button", {
                    class: "primary",
                    onClick: $setup.onSaveVolume
                  }, "保存卷"),
                  _createElementVNode("button", {
                    disabled: $setup.genningOutline,
                    onClick: $setup.onGenVolumeOutline
                  }, _toDisplayString($setup.genningOutline ? '生成中…' : '✨ AI 生成卷大纲（重写）'), 9 /* TEXT, PROPS */, _hoisted_30),
                  _createElementVNode("button", {
                    disabled: $setup.genningSummary,
                    onClick: $setup.onGenVolumeSummary
                  }, _toDisplayString($setup.genningSummary ? '汇总中…' : '✨ AI 生成卷摘要'), 9 /* TEXT, PROPS */, _hoisted_31)
                ])
              ]))
            : _createCommentVNode("v-if", true),
          _cache[51] || (_cache[51] = _createElementVNode("h3", { style: {"margin":"20px 0 4px"} }, "章摘要（由总结师逐章生成）", -1 /* CACHED */)),
          (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.memory.summaries, (s) => {
            return (_openBlock(), _createElementBlock("div", {
              class: "summary-card",
              key: s.chapter_no
            }, [
              _createElementVNode("div", null, [
                _createElementVNode("b", null, "第" + _toDisplayString(s.chapter_no) + "章 " + _toDisplayString(s.chapter_title), 1 /* TEXT */),
                _createElementVNode("span", _hoisted_32, _toDisplayString($setup.fmtTime(s.created_at)), 1 /* TEXT */)
              ]),
              (s.outline_progress)
                ? (_openBlock(), _createElementBlock("div", _hoisted_33, "大纲进度：" + _toDisplayString(s.outline_progress), 1 /* TEXT */))
                : _createCommentVNode("v-if", true),
              _createElementVNode("div", null, _toDisplayString(s.summary), 1 /* TEXT */),
              (s.key_events?.length)
                ? (_openBlock(), _createElementBlock("div", _hoisted_34, [
                    (_openBlock(true), _createElementBlock(_Fragment, null, _renderList(s.key_events, (ev, i) => {
                      return (_openBlock(), _createElementBlock("span", {
                        key: i,
                        class: "tag"
                      }, _toDisplayString(ev), 1 /* TEXT */))
                    }), 128 /* KEYED_FRAGMENT */))
                  ]))
                : _createCommentVNode("v-if", true)
            ]))
          }), 128 /* KEYED_FRAGMENT */)),
          (!$setup.memory.summaries.length)
            ? (_openBlock(), _createElementBlock("p", _hoisted_35, "暂无摘要。在工作台对章节点「📝 定稿（更新记忆）」后生成。"))
            : _createCommentVNode("v-if", true),
          _createCommentVNode(" 开新卷弹窗 "),
          ($setup.showNewVolume)
            ? (_openBlock(), _createElementBlock("div", {
                key: 2,
                class: "overlay",
                onClick: _cache[16] || (_cache[16] = _withModifiers($event => ($setup.showNewVolume = false), ["self"]))
              }, [
                _createElementVNode("div", _hoisted_36, [
                  _cache[47] || (_cache[47] = _createElementVNode("h3", null, "开新卷", -1 /* CACHED */)),
                  _cache[48] || (_cache[48] = _createElementVNode("p", { class: "hint" }, "创建后上一卷将自动标记为「完结」，新章节默认写入新卷", -1 /* CACHED */)),
                  _cache[49] || (_cache[49] = _createElementVNode("label", null, "卷名", -1 /* CACHED */)),
                  _withDirectives(_createElementVNode("input", {
                    "onUpdate:modelValue": _cache[13] || (_cache[13] = $event => (($setup.newVolForm.title) = $event))
                  }, null, 512 /* NEED_PATCH */), [
                    [_vModelText, $setup.newVolForm.title]
                  ]),
                  _cache[50] || (_cache[50] = _createElementVNode("label", null, "卷大纲（可先 AI 生成再修改）", -1 /* CACHED */)),
                  _withDirectives(_createElementVNode("textarea", {
                    "onUpdate:modelValue": _cache[14] || (_cache[14] = $event => (($setup.newVolForm.outline) = $event)),
                    rows: "6",
                    placeholder: "AI 会根据全书简介、上一卷摘要与待回收伏笔生成本卷大纲"
                  }, null, 512 /* NEED_PATCH */), [
                    [_vModelText, $setup.newVolForm.outline]
                  ]),
                  _createElementVNode("div", _hoisted_37, [
                    _createElementVNode("button", {
                      disabled: $setup.genningOutline,
                      onClick: $setup.onGenVolumeOutline
                    }, _toDisplayString($setup.genningOutline ? '生成中…' : '✨ AI 生成卷大纲'), 9 /* TEXT, PROPS */, _hoisted_38)
                  ]),
                  _createElementVNode("div", _hoisted_39, [
                    _createElementVNode("button", {
                      class: "primary",
                      disabled: $setup.creatingVol,
                      onClick: $setup.onCreateVolume
                    }, _toDisplayString($setup.creatingVol ? '创建中…' : '创建新卷'), 9 /* TEXT, PROPS */, _hoisted_40),
                    _createElementVNode("button", {
                      onClick: _cache[15] || (_cache[15] = $event => ($setup.showNewVolume = false))
                    }, "取消")
                  ])
                ])
              ]))
            : _createCommentVNode("v-if", true)
        ], 64 /* STABLE_FRAGMENT */))
      : _createCommentVNode("v-if", true),
    _createCommentVNode(" ============ 导入设定 ============ "),
    ($setup.tab === 'import')
      ? (_openBlock(), _createElementBlock(_Fragment, { key: 4 }, [
          _createElementVNode("div", _hoisted_41, [
            _createElementVNode("section", _hoisted_42, [
              _cache[52] || (_cache[52] = _createElementVNode("h3", null, "📖 导入故事圣经", -1 /* CACHED */)),
              _cache[53] || (_cache[53] = _createElementVNode("p", { class: "hint" }, " 整篇作为「设定铁律」注入写手/校对/细纲师每次生成；自动同步书名/题材/风格/简介/目标字数 ", -1 /* CACHED */)),
              _createElementVNode("input", {
                type: "file",
                accept: ".md,.txt",
                onChange: _cache[17] || (_cache[17] = $event => ($setup.onFile($event, 'bible')))
              }, null, 32 /* NEED_HYDRATION */),
              _withDirectives(_createElementVNode("textarea", {
                "onUpdate:modelValue": _cache[18] || (_cache[18] = $event => (($setup.importTexts.bible) = $event)),
                rows: "8",
                placeholder: "选择或粘贴 00-故事圣经.md 全文"
              }, null, 512 /* NEED_PATCH */), [
                [_vModelText, $setup.importTexts.bible]
              ]),
              _createElementVNode("div", _hoisted_43, [
                _createElementVNode("button", {
                  class: "primary",
                  disabled: $setup.importing,
                  onClick: _cache[19] || (_cache[19] = $event => ($setup.onImport('bible')))
                }, "导入故事圣经", 8 /* PROPS */, _hoisted_44)
              ])
            ]),
            _createElementVNode("section", _hoisted_45, [
              _cache[54] || (_cache[54] = _createElementVNode("h3", null, "🗺 导入故事大纲", -1 /* CACHED */)),
              _cache[55] || (_cache[55] = _createElementVNode("p", { class: "hint" }, " 自动按「### 卷X」建立分卷结构并填充各卷大纲（卷一连载中、其余未开始）；「全书总纲」作为硬性红线注入细纲师；「小说简介」同步为简介 ", -1 /* CACHED */)),
              _createElementVNode("input", {
                type: "file",
                accept: ".md,.txt",
                onChange: _cache[20] || (_cache[20] = $event => ($setup.onFile($event, 'outline')))
              }, null, 32 /* NEED_HYDRATION */),
              _withDirectives(_createElementVNode("textarea", {
                "onUpdate:modelValue": _cache[21] || (_cache[21] = $event => (($setup.importTexts.outline) = $event)),
                rows: "8",
                placeholder: "选择或粘贴 02-故事大纲.md 全文"
              }, null, 512 /* NEED_PATCH */), [
                [_vModelText, $setup.importTexts.outline]
              ]),
              _createElementVNode("div", _hoisted_46, [
                _createElementVNode("button", {
                  class: "primary",
                  disabled: $setup.importing,
                  onClick: _cache[22] || (_cache[22] = $event => ($setup.onImport('outline')))
                }, "导入故事大纲", 8 /* PROPS */, _hoisted_47)
              ])
            ]),
            _createElementVNode("section", _hoisted_48, [
              _cache[57] || (_cache[57] = _createElementVNode("h3", null, "👥 导入人物卡", -1 /* CACHED */)),
              _cache[58] || (_cache[58] = _createElementVNode("p", { class: "hint" }, " 按「## N. 角色名」解析每张卡（身份自动识别主角/反派），整卡原文保留为人设约束注入写手上下文 ", -1 /* CACHED */)),
              _createElementVNode("input", {
                type: "file",
                accept: ".md,.txt",
                onChange: _cache[23] || (_cache[23] = $event => ($setup.onFile($event, 'characters')))
              }, null, 32 /* NEED_HYDRATION */),
              _withDirectives(_createElementVNode("textarea", {
                "onUpdate:modelValue": _cache[24] || (_cache[24] = $event => (($setup.importTexts.characters) = $event)),
                rows: "8",
                placeholder: "选择或粘贴 01-人物卡.md 全文"
              }, null, 512 /* NEED_PATCH */), [
                [_vModelText, $setup.importTexts.characters]
              ]),
              _cache[59] || (_cache[59] = _createElementVNode("label", null, "导入模式", -1 /* CACHED */)),
              _withDirectives(_createElementVNode("select", {
                "onUpdate:modelValue": _cache[25] || (_cache[25] = $event => (($setup.importMode) = $event))
              }, [...(_cache[56] || (_cache[56] = [
                _createElementVNode("option", { value: "replace" }, "替换现有全部人物卡", -1 /* CACHED */),
                _createElementVNode("option", { value: "append" }, "追加（同名覆盖）", -1 /* CACHED */)
              ]))], 512 /* NEED_PATCH */), [
                [_vModelSelect, $setup.importMode]
              ]),
              _createElementVNode("div", _hoisted_49, [
                _createElementVNode("button", {
                  class: "primary",
                  disabled: $setup.importing,
                  onClick: _cache[26] || (_cache[26] = $event => ($setup.onImport('characters')))
                }, _toDisplayString($setup.importing ? '导入中…' : '导入人物卡'), 9 /* TEXT, PROPS */, _hoisted_50)
              ])
            ]),
            _createElementVNode("section", _hoisted_51, [
              _cache[61] || (_cache[61] = _createElementVNode("h3", null, "✍️ 导入 AI 写作限制词", -1 /* CACHED */)),
              _cache[62] || (_cache[62] = _createElementVNode("p", { class: "hint" }, " 约束写手、修稿和校对的表达方式，减少模板化词汇与句式；不改变故事设定，也不能替代人工审稿。 ", -1 /* CACHED */)),
              ($setup.memory?.writing_restrictions?.has_text)
                ? (_openBlock(), _createElementBlock("p", _hoisted_52, " 当前已保存 " + _toDisplayString($setup.memory.writing_restrictions.length) + " 字；超长文档仅在注入模型时保留首尾部分。 ", 1 /* TEXT */))
                : _createCommentVNode("v-if", true),
              _createElementVNode("input", {
                type: "file",
                accept: ".md,.txt",
                onChange: _cache[27] || (_cache[27] = $event => ($setup.onFile($event, 'restrictions')))
              }, null, 32 /* NEED_HYDRATION */),
              _withDirectives(_createElementVNode("textarea", {
                "onUpdate:modelValue": _cache[28] || (_cache[28] = $event => (($setup.importTexts.restrictions) = $event)),
                rows: "8",
                placeholder: "选择或粘贴限制词、禁用词和自检规则文档"
              }, null, 512 /* NEED_PATCH */), [
                [_vModelText, $setup.importTexts.restrictions]
              ]),
              _cache[63] || (_cache[63] = _createElementVNode("label", null, "导入模式", -1 /* CACHED */)),
              _withDirectives(_createElementVNode("select", {
                "onUpdate:modelValue": _cache[29] || (_cache[29] = $event => (($setup.importMode) = $event))
              }, [...(_cache[60] || (_cache[60] = [
                _createElementVNode("option", { value: "replace" }, "替换现有限制词文档", -1 /* CACHED */),
                _createElementVNode("option", { value: "append" }, "追加到现有文档", -1 /* CACHED */)
              ]))], 512 /* NEED_PATCH */), [
                [_vModelSelect, $setup.importMode]
              ]),
              _createElementVNode("div", _hoisted_53, [
                _createElementVNode("button", {
                  class: "primary",
                  disabled: $setup.importing,
                  onClick: _cache[30] || (_cache[30] = $event => ($setup.onImport('restrictions')))
                }, _toDisplayString($setup.importing ? '导入中…' : '导入限制词文档'), 9 /* TEXT, PROPS */, _hoisted_54),
                ($setup.memory?.writing_restrictions?.has_text)
                  ? (_openBlock(), _createElementBlock("button", {
                      key: 0,
                      class: "danger",
                      disabled: $setup.importing,
                      onClick: $setup.onClearRestrictions
                    }, "清空", 8 /* PROPS */, _hoisted_55))
                  : _createCommentVNode("v-if", true)
              ])
            ])
          ]),
          ($setup.msg && $setup.tab === 'import')
            ? (_openBlock(), _createElementBlock("p", {
                key: 0,
                class: _normalizeClass(["msg", $setup.msgOk ? 'ok' : 'err'])
              }, _toDisplayString($setup.msg), 3 /* TEXT, CLASS */))
            : _createCommentVNode("v-if", true)
        ], 64 /* STABLE_FRAGMENT */))
      : _createCommentVNode("v-if", true)
  ]))
}



_sfc_main.__hmrId = "ab36bce5"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/86184/Desktop/novel_web/frontend/src/views/NovelSettingsView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTm92ZWxTZXR0aW5nc1ZpZXcudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgeyBvbk1vdW50ZWQsIHJlYWN0aXZlLCByZWYgfSBmcm9tICd2dWUnXG5pbXBvcnQgeyB1c2VSb3V0ZSwgdXNlUm91dGVyIH0gZnJvbSAndnVlLXJvdXRlcidcbmltcG9ydCB7XG4gIGNsZWFyV3JpdGluZ1Jlc3RyaWN0aW9ucyxcbiAgY3JlYXRlQ2hhcmFjdGVyLFxuICBjcmVhdGVGb3Jlc2hhZG93aW5nLFxuICBjcmVhdGVWb2x1bWUsXG4gIGRlbGV0ZUNoYXJhY3RlcixcbiAgZGVsZXRlRm9yZXNoYWRvd2luZyxcbiAgZ2VuVm9sdW1lT3V0bGluZSxcbiAgZ2VuVm9sdW1lU3VtbWFyeSxcbiAgZ2V0TWVtb3J5LFxuICBpbXBvcnREb2MsXG4gIHVwZGF0ZUNoYXJhY3RlcixcbiAgdXBkYXRlRm9yZXNoYWRvd2luZyxcbiAgdXBkYXRlVm9sdW1lLFxufSBmcm9tICcuLi9hcGknXG5pbXBvcnQgeyBmbXRUaW1lIH0gZnJvbSAnLi4vdXRpbHMnXG5cbmNvbnN0IHJvdXRlID0gdXNlUm91dGUoKVxuY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbmNvbnN0IG5vdmVsSWQgPSBOdW1iZXIocm91dGUucGFyYW1zLmlkKVxuXG5jb25zdCBtZW1vcnkgPSByZWYobnVsbClcbmNvbnN0IHRhYiA9IHJlZignY2hhcmFjdGVycycpXG5jb25zdCBtc2cgPSByZWYoJycpXG5jb25zdCBtc2dPayA9IHJlZih0cnVlKVxuXG5jb25zdCBDSEFSX0tFWVMgPSBbJ+WkluiyjCcsICfmgKfmoLwnLCAn55uu5qCHJywgJ+WFs+ezuycsICfkvY3nva4nLCAn5oOF5oSfJ11cblxuLyogLS0tLS0tLS0tLSDkurrnianljaEgLS0tLS0tLS0tLSAqL1xuY29uc3QgY2hhckZvcm0gPSByZWFjdGl2ZSh7IGlkOiBudWxsLCBuYW1lOiAnJywgcm9sZTogJ+mFjeinkicsIGNhcmQ6IHt9IH0pXG5cbmZ1bmN0aW9uIG5ld0NoYXJhY3RlcigpIHtcbiAgY2hhckZvcm0uaWQgPSBudWxsXG4gIGNoYXJGb3JtLm5hbWUgPSAnJ1xuICBjaGFyRm9ybS5yb2xlID0gJ+mFjeinkidcbiAgY2hhckZvcm0uY2FyZCA9IHt9XG59XG5cbmZ1bmN0aW9uIGVkaXRDaGFyYWN0ZXIoYykge1xuICBjaGFyRm9ybS5pZCA9IGMuaWRcbiAgY2hhckZvcm0ubmFtZSA9IGMubmFtZVxuICBjaGFyRm9ybS5yb2xlID0gYy5yb2xlXG4gIGNoYXJGb3JtLmNhcmQgPSB7IC4uLihjLmNhcmQgfHwge30pIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gb25TYXZlQ2hhcmFjdGVyKCkge1xuICBpZiAoIWNoYXJGb3JtLm5hbWUudHJpbSgpKSB7XG4gICAgbXNnLnZhbHVlID0gJ+ivt+Whq+WGmeinkuiJsuWQjSdcbiAgICBtc2dPay52YWx1ZSA9IGZhbHNlXG4gICAgcmV0dXJuXG4gIH1cbiAgdHJ5IHtcbiAgICBpZiAoY2hhckZvcm0uaWQpXG4gICAgICBhd2FpdCB1cGRhdGVDaGFyYWN0ZXIoY2hhckZvcm0uaWQsIHsgbmFtZTogY2hhckZvcm0ubmFtZSwgcm9sZTogY2hhckZvcm0ucm9sZSwgY2FyZDogY2hhckZvcm0uY2FyZCB9KVxuICAgIGVsc2UgYXdhaXQgY3JlYXRlQ2hhcmFjdGVyKG5vdmVsSWQsIHsgbmFtZTogY2hhckZvcm0ubmFtZSwgcm9sZTogY2hhckZvcm0ucm9sZSwgY2FyZDogY2hhckZvcm0uY2FyZCB9KVxuICAgIG1zZy52YWx1ZSA9ICflt7Lkv53lrZgnXG4gICAgbXNnT2sudmFsdWUgPSB0cnVlXG4gICAgbmV3Q2hhcmFjdGVyKClcbiAgICBhd2FpdCBsb2FkKClcbiAgfSBjYXRjaCAoZSkge1xuICAgIG1zZy52YWx1ZSA9IGUubWVzc2FnZVxuICAgIG1zZ09rLnZhbHVlID0gZmFsc2VcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBvbkRlbGV0ZUNoYXJhY3RlcihjKSB7XG4gIGlmICghY29uZmlybShg5Yig6Zmk5Lq654mp5Y2h44CMJHtjLm5hbWV944CN77yfYCkpIHJldHVyblxuICB0cnkge1xuICAgIGF3YWl0IGRlbGV0ZUNoYXJhY3RlcihjLmlkKVxuICAgIGF3YWl0IGxvYWQoKVxuICB9IGNhdGNoIChlKSB7XG4gICAgbXNnLnZhbHVlID0gZS5tZXNzYWdlXG4gICAgbXNnT2sudmFsdWUgPSBmYWxzZVxuICB9XG59XG5cbi8qIC0tLS0tLS0tLS0g5LyP56yU5bqTIC0tLS0tLS0tLS0gKi9cbmNvbnN0IGZGb3JtID0gcmVhY3RpdmUoeyBpZDogbnVsbCwgdGl0bGU6ICcnLCBkZXNjcmlwdGlvbjogJycsIHN0YXR1czogJ+W+heWbnuaUticgfSlcbmNvbnN0IEZTX1NUQVRVUyA9IFsn5b6F5Zue5pS2JywgJ+W3suWbnuaUticsICflup/lvIMnXVxuXG5mdW5jdGlvbiBuZXdGb3Jlc2hhZG93aW5nKCkge1xuICBmRm9ybS5pZCA9IG51bGxcbiAgZkZvcm0udGl0bGUgPSAnJ1xuICBmRm9ybS5kZXNjcmlwdGlvbiA9ICcnXG4gIGZGb3JtLnN0YXR1cyA9ICflvoXlm57mlLYnXG59XG5cbmZ1bmN0aW9uIGVkaXRGb3Jlc2hhZG93aW5nKGYpIHtcbiAgZkZvcm0uaWQgPSBmLmlkXG4gIGZGb3JtLnRpdGxlID0gZi50aXRsZVxuICBmRm9ybS5kZXNjcmlwdGlvbiA9IGYuZGVzY3JpcHRpb25cbiAgZkZvcm0uc3RhdHVzID0gZi5zdGF0dXNcbn1cblxuYXN5bmMgZnVuY3Rpb24gb25TYXZlRm9yZXNoYWRvd2luZygpIHtcbiAgaWYgKCFmRm9ybS50aXRsZS50cmltKCkpIHtcbiAgICBtc2cudmFsdWUgPSAn6K+35aGr5YaZ5LyP56yU5qCH6aKYJ1xuICAgIG1zZ09rLnZhbHVlID0gZmFsc2VcbiAgICByZXR1cm5cbiAgfVxuICB0cnkge1xuICAgIGlmIChmRm9ybS5pZClcbiAgICAgIGF3YWl0IHVwZGF0ZUZvcmVzaGFkb3dpbmcoZkZvcm0uaWQsIHsgdGl0bGU6IGZGb3JtLnRpdGxlLCBkZXNjcmlwdGlvbjogZkZvcm0uZGVzY3JpcHRpb24sIHN0YXR1czogZkZvcm0uc3RhdHVzIH0pXG4gICAgZWxzZSBhd2FpdCBjcmVhdGVGb3Jlc2hhZG93aW5nKG5vdmVsSWQsIHsgdGl0bGU6IGZGb3JtLnRpdGxlLCBkZXNjcmlwdGlvbjogZkZvcm0uZGVzY3JpcHRpb24sIHN0YXR1czogZkZvcm0uc3RhdHVzIH0pXG4gICAgbXNnLnZhbHVlID0gJ+W3suS/neWtmCdcbiAgICBtc2dPay52YWx1ZSA9IHRydWVcbiAgICBuZXdGb3Jlc2hhZG93aW5nKClcbiAgICBhd2FpdCBsb2FkKClcbiAgfSBjYXRjaCAoZSkge1xuICAgIG1zZy52YWx1ZSA9IGUubWVzc2FnZVxuICAgIG1zZ09rLnZhbHVlID0gZmFsc2VcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBvbkRlbGV0ZUZvcmVzaGFkb3dpbmcoZikge1xuICBpZiAoIWNvbmZpcm0oYOWIoOmZpOS8j+eslOOAjCR7Zi50aXRsZX3jgI3vvJ9gKSkgcmV0dXJuXG4gIHRyeSB7XG4gICAgYXdhaXQgZGVsZXRlRm9yZXNoYWRvd2luZyhmLmlkKVxuICAgIGF3YWl0IGxvYWQoKVxuICB9IGNhdGNoIChlKSB7XG4gICAgbXNnLnZhbHVlID0gZS5tZXNzYWdlXG4gICAgbXNnT2sudmFsdWUgPSBmYWxzZVxuICB9XG59XG5cbi8qIC0tLS0tLS0tLS0g5Y23566h55CGIC0tLS0tLS0tLS0gKi9cbmNvbnN0IHZvbHVtZUZvcm0gPSByZWFjdGl2ZSh7IGlkOiBudWxsLCB0aXRsZTogJycsIHN0YXR1czogJ+i/nui9veS4rScsIG91dGxpbmU6ICcnLCBzdW1tYXJ5OiAnJyB9KVxuY29uc3Qgc2hvd05ld1ZvbHVtZSA9IHJlZihmYWxzZSlcbmNvbnN0IG5ld1ZvbEZvcm0gPSByZWFjdGl2ZSh7IHRpdGxlOiAnJywgb3V0bGluZTogJycgfSlcbmNvbnN0IGdlbm5pbmdPdXRsaW5lID0gcmVmKGZhbHNlKVxuY29uc3QgZ2VubmluZ1N1bW1hcnkgPSByZWYoZmFsc2UpXG5jb25zdCBjcmVhdGluZ1ZvbCA9IHJlZihmYWxzZSlcblxuZnVuY3Rpb24gc2VsZWN0Vm9sdW1lKHYpIHtcbiAgdm9sdW1lRm9ybS5pZCA9IHYuaWRcbiAgdm9sdW1lRm9ybS50aXRsZSA9IHYudGl0bGVcbiAgdm9sdW1lRm9ybS5zdGF0dXMgPSB2LnN0YXR1c1xuICB2b2x1bWVGb3JtLm91dGxpbmUgPSB2Lm91dGxpbmVcbiAgdm9sdW1lRm9ybS5zdW1tYXJ5ID0gdi5zdW1tYXJ5XG59XG5cbmZ1bmN0aW9uIG9wZW5OZXdWb2x1bWUoKSB7XG4gIGNvbnN0IG5leHRObyA9IChtZW1vcnkudmFsdWU/LnZvbHVtZXM/Lmxlbmd0aCB8fCAwKSArIDFcbiAgbmV3Vm9sRm9ybS50aXRsZSA9IGDnrKwke25leHROb33ljbdgXG4gIG5ld1ZvbEZvcm0ub3V0bGluZSA9ICcnXG4gIHNob3dOZXdWb2x1bWUudmFsdWUgPSB0cnVlXG59XG5cbmFzeW5jIGZ1bmN0aW9uIG9uR2VuVm9sdW1lT3V0bGluZSgpIHtcbiAgZ2VubmluZ091dGxpbmUudmFsdWUgPSB0cnVlXG4gIHRyeSB7XG4gICAgY29uc3QgciA9IGF3YWl0IGdlblZvbHVtZU91dGxpbmUobm92ZWxJZClcbiAgICBpZiAoci52b2x1bWVfdGl0bGUpIG5ld1ZvbEZvcm0udGl0bGUgPSByLnZvbHVtZV90aXRsZVxuICAgIG5ld1ZvbEZvcm0ub3V0bGluZSA9IHIub3V0bGluZVxuICB9IGNhdGNoIChlKSB7XG4gICAgbXNnLnZhbHVlID0gZS5tZXNzYWdlXG4gICAgbXNnT2sudmFsdWUgPSBmYWxzZVxuICB9IGZpbmFsbHkge1xuICAgIGdlbm5pbmdPdXRsaW5lLnZhbHVlID0gZmFsc2VcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBvbkNyZWF0ZVZvbHVtZSgpIHtcbiAgY3JlYXRpbmdWb2wudmFsdWUgPSB0cnVlXG4gIHRyeSB7XG4gICAgY29uc3QgdiA9IGF3YWl0IGNyZWF0ZVZvbHVtZShub3ZlbElkLCB7IHRpdGxlOiBuZXdWb2xGb3JtLnRpdGxlLCBvdXRsaW5lOiBuZXdWb2xGb3JtLm91dGxpbmUgfSlcbiAgICBzaG93TmV3Vm9sdW1lLnZhbHVlID0gZmFsc2VcbiAgICBtc2cudmFsdWUgPSBg5bey5byA5paw5Y2377yaJHt2LnRpdGxlfe+8iOS4iuS4gOWNt+W3suiHquWKqOWujOe7k++8iWBcbiAgICBtc2dPay52YWx1ZSA9IHRydWVcbiAgICBhd2FpdCBsb2FkKClcbiAgICBjb25zdCBmcmVzaCA9IG1lbW9yeS52YWx1ZS52b2x1bWVzLmZpbmQoKHgpID0+IHguaWQgPT09IHYuaWQpXG4gICAgaWYgKGZyZXNoKSBzZWxlY3RWb2x1bWUoZnJlc2gpXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBtc2cudmFsdWUgPSBlLm1lc3NhZ2VcbiAgICBtc2dPay52YWx1ZSA9IGZhbHNlXG4gIH0gZmluYWxseSB7XG4gICAgY3JlYXRpbmdWb2wudmFsdWUgPSBmYWxzZVxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG9uU2F2ZVZvbHVtZSgpIHtcbiAgaWYgKCF2b2x1bWVGb3JtLmlkKSByZXR1cm5cbiAgdHJ5IHtcbiAgICBhd2FpdCB1cGRhdGVWb2x1bWUodm9sdW1lRm9ybS5pZCwge1xuICAgICAgdGl0bGU6IHZvbHVtZUZvcm0udGl0bGUsXG4gICAgICBvdXRsaW5lOiB2b2x1bWVGb3JtLm91dGxpbmUsXG4gICAgICBzdGF0dXM6IHZvbHVtZUZvcm0uc3RhdHVzLFxuICAgIH0pXG4gICAgbXNnLnZhbHVlID0gJ+WNt+W3suS/neWtmCdcbiAgICBtc2dPay52YWx1ZSA9IHRydWVcbiAgICBhd2FpdCBsb2FkKClcbiAgICBjb25zdCBmcmVzaCA9IG1lbW9yeS52YWx1ZS52b2x1bWVzLmZpbmQoKHgpID0+IHguaWQgPT09IHZvbHVtZUZvcm0uaWQpXG4gICAgaWYgKGZyZXNoKSBzZWxlY3RWb2x1bWUoZnJlc2gpXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBtc2cudmFsdWUgPSBlLm1lc3NhZ2VcbiAgICBtc2dPay52YWx1ZSA9IGZhbHNlXG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gb25HZW5Wb2x1bWVTdW1tYXJ5KCkge1xuICBpZiAoIXZvbHVtZUZvcm0uaWQpIHJldHVyblxuICBnZW5uaW5nU3VtbWFyeS52YWx1ZSA9IHRydWVcbiAgdHJ5IHtcbiAgICBjb25zdCByID0gYXdhaXQgZ2VuVm9sdW1lU3VtbWFyeSh2b2x1bWVGb3JtLmlkKVxuICAgIHZvbHVtZUZvcm0uc3VtbWFyeSA9IHIuc3VtbWFyeVxuICAgIG1zZy52YWx1ZSA9ICfljbfmkZjopoHlt7LnlJ/miJAnXG4gICAgbXNnT2sudmFsdWUgPSB0cnVlXG4gICAgYXdhaXQgbG9hZCgpXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBtc2cudmFsdWUgPSBlLm1lc3NhZ2VcbiAgICBtc2dPay52YWx1ZSA9IGZhbHNlXG4gIH0gZmluYWxseSB7XG4gICAgZ2VubmluZ1N1bW1hcnkudmFsdWUgPSBmYWxzZVxuICB9XG59XG5cbi8qIC0tLS0tLS0tLS0g6K6+5a6a5a+85YWlIC0tLS0tLS0tLS0gKi9cbmNvbnN0IGltcG9ydFRleHRzID0gcmVhY3RpdmUoeyBiaWJsZTogJycsIG91dGxpbmU6ICcnLCBjaGFyYWN0ZXJzOiAnJywgcmVzdHJpY3Rpb25zOiAnJyB9KVxuY29uc3QgaW1wb3J0TW9kZSA9IHJlZigncmVwbGFjZScpXG5jb25zdCBpbXBvcnRpbmcgPSByZWYoZmFsc2UpXG5cbmZ1bmN0aW9uIG9uRmlsZShlLCBraW5kKSB7XG4gIGNvbnN0IGYgPSBlLnRhcmdldC5maWxlcyAmJiBlLnRhcmdldC5maWxlc1swXVxuICBpZiAoIWYpIHJldHVyblxuICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpXG4gIHJlYWRlci5vbmxvYWQgPSAoKSA9PiB7XG4gICAgaW1wb3J0VGV4dHNba2luZF0gPSBTdHJpbmcocmVhZGVyLnJlc3VsdCB8fCAnJylcbiAgfVxuICByZWFkZXIucmVhZEFzVGV4dChmLCAndXRmLTgnKVxuICBlLnRhcmdldC52YWx1ZSA9ICcnIC8vIOWFgeiuuOmHjeWkjemAieaLqeWQjOS4gOaWh+S7tlxufVxuXG5hc3luYyBmdW5jdGlvbiBvbkNsZWFyUmVzdHJpY3Rpb25zKCkge1xuICBpZiAoIWNvbmZpcm0oJ+ehruWumua4heepuuW9k+WJjSBBSSDlhpnkvZzpmZDliLbor43mlofmoaPvvJ8nKSkgcmV0dXJuXG4gIGltcG9ydGluZy52YWx1ZSA9IHRydWVcbiAgdHJ5IHtcbiAgICBjb25zdCByID0gYXdhaXQgY2xlYXJXcml0aW5nUmVzdHJpY3Rpb25zKG5vdmVsSWQpXG4gICAgbXNnLnZhbHVlID0gci5tZXNzYWdlXG4gICAgbXNnT2sudmFsdWUgPSB0cnVlXG4gICAgYXdhaXQgbG9hZCgpXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBtc2cudmFsdWUgPSBlLm1lc3NhZ2VcbiAgICBtc2dPay52YWx1ZSA9IGZhbHNlXG4gIH0gZmluYWxseSB7XG4gICAgaW1wb3J0aW5nLnZhbHVlID0gZmFsc2VcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBvbkltcG9ydChraW5kKSB7XG4gIGNvbnN0IHRleHQgPSBpbXBvcnRUZXh0c1traW5kXS50cmltKClcbiAgaWYgKCF0ZXh0KSB7XG4gICAgbXNnLnZhbHVlID0gJ+ivt+WFiOmAieaLqeaWh+S7tuaIlueymOi0tOWGheWuuSdcbiAgICBtc2dPay52YWx1ZSA9IGZhbHNlXG4gICAgcmV0dXJuXG4gIH1cbiAgaWYgKFxuICAgIChraW5kID09PSAnY2hhcmFjdGVycycgfHwga2luZCA9PT0gJ3Jlc3RyaWN0aW9ucycpICYmXG4gICAgaW1wb3J0TW9kZS52YWx1ZSA9PT0gJ3JlcGxhY2UnICYmXG4gICAgKChraW5kID09PSAnY2hhcmFjdGVycycgJiYgbWVtb3J5LnZhbHVlPy5jaGFyYWN0ZXJzPy5sZW5ndGgpIHx8XG4gICAgICAoa2luZCA9PT0gJ3Jlc3RyaWN0aW9ucycgJiYgbWVtb3J5LnZhbHVlPy53cml0aW5nX3Jlc3RyaWN0aW9ucz8uaGFzX3RleHQpKVxuICApIHtcbiAgICBjb25zdCB0YXJnZXQgPSBraW5kID09PSAnY2hhcmFjdGVycydcbiAgICAgID8gYOeOsOaciSAke21lbW9yeS52YWx1ZS5jaGFyYWN0ZXJzLmxlbmd0aH0g5byg5Lq654mp5Y2hYFxuICAgICAgOiBg546w5pyJ6ZmQ5Yi26K+N5paH5qGj77yIJHttZW1vcnkudmFsdWUud3JpdGluZ19yZXN0cmljdGlvbnMubGVuZ3RofSDlrZfvvIlgXG4gICAgaWYgKCFjb25maXJtKGDlsIbku6XjgIzmm7/mjaLjgI3mqKHlvI/lr7zlhaXvvIwke3RhcmdldH3lsIbooqvopobnm5bjgILnu6fnu63vvJ9gKSkgcmV0dXJuXG4gIH1cbiAgaW1wb3J0aW5nLnZhbHVlID0gdHJ1ZVxuICB0cnkge1xuICAgIGNvbnN0IHIgPSBhd2FpdCBpbXBvcnREb2Mobm92ZWxJZCwgeyBraW5kLCB0ZXh0LCBtb2RlOiBpbXBvcnRNb2RlLnZhbHVlIH0pXG4gICAgbXNnLnZhbHVlID0gci5tZXNzYWdlXG4gICAgbXNnT2sudmFsdWUgPSB0cnVlXG4gICAgaW1wb3J0VGV4dHNba2luZF0gPSAnJ1xuICAgIGF3YWl0IGxvYWQoKVxuICB9IGNhdGNoIChlKSB7XG4gICAgbXNnLnZhbHVlID0gZS5tZXNzYWdlXG4gICAgbXNnT2sudmFsdWUgPSBmYWxzZVxuICB9IGZpbmFsbHkge1xuICAgIGltcG9ydGluZy52YWx1ZSA9IGZhbHNlXG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZCgpIHtcbiAgdHJ5IHtcbiAgICBtZW1vcnkudmFsdWUgPSBhd2FpdCBnZXRNZW1vcnkobm92ZWxJZClcbiAgICBjb25zdCBjdXIgPSBtZW1vcnkudmFsdWUudm9sdW1lcy5maW5kKCh2KSA9PiB2LnN0YXR1cyA9PT0gJ+i/nui9veS4rScpIHx8IG1lbW9yeS52YWx1ZS52b2x1bWVzLmF0KC0xKVxuICAgIGlmIChjdXIpIHNlbGVjdFZvbHVtZShjdXIpXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBtc2cudmFsdWUgPSBlLm1lc3NhZ2VcbiAgICBtc2dPay52YWx1ZSA9IGZhbHNlXG4gIH1cbn1cbm9uTW91bnRlZChsb2FkKVxuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cbiAgPGRpdj5cbiAgICA8ZGl2IGNsYXNzPVwibm92ZWwtaGVhZFwiPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImxpbmtcIiBAY2xpY2s9XCJyb3V0ZXIucHVzaChgL25vdmVsLyR7bm92ZWxJZH1gKVwiPuKGkCDov5Tlm57lt6XkvZzlj7A8L2J1dHRvbj5cbiAgICAgIDxoMj7orr7lrpogLyDorrDlv4Y8L2gyPlxuICAgICAgPHNwYW4gY2xhc3M9XCJoaW50XCI+5Lq654mp5Y2h44CB5LyP56yU5bqT44CB5Y235aSn57qy5LiO5Y235pGY6KaB5Lya6KKr6Ieq5Yqo5rOo5YWlIEFJIOWGmeS9nOeahOS4iuS4i+aWh+S4rTwvc3Bhbj5cbiAgICA8L2Rpdj5cblxuICAgIDxkaXYgY2xhc3M9XCJ0YWJzXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwidGFiXCIgOmNsYXNzPVwieyBhY3RpdmU6IHRhYiA9PT0gJ2NoYXJhY3RlcnMnIH1cIiBAY2xpY2s9XCJ0YWIgPSAnY2hhcmFjdGVycydcIj7kurrnianljaE8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJ0YWJcIiA6Y2xhc3M9XCJ7IGFjdGl2ZTogdGFiID09PSAnZm9yZXNoYWRvd2luZ3MnIH1cIiBAY2xpY2s9XCJ0YWIgPSAnZm9yZXNoYWRvd2luZ3MnXCI+5LyP56yU5bqTPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwidGFiXCIgOmNsYXNzPVwieyBhY3RpdmU6IHRhYiA9PT0gJ3ZvbHVtZScgfVwiIEBjbGljaz1cInRhYiA9ICd2b2x1bWUnXCI+5Y23566h55CGIC8g56ug5pGY6KaBPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwidGFiXCIgOmNsYXNzPVwieyBhY3RpdmU6IHRhYiA9PT0gJ2ltcG9ydCcgfVwiIEBjbGljaz1cInRhYiA9ICdpbXBvcnQnXCI+8J+TpSDlr7zlhaXorr7lrpo8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8cCB2LWlmPVwibXNnXCIgY2xhc3M9XCJtc2dcIiA6Y2xhc3M9XCJtc2dPayA/ICdvaycgOiAnZXJyJ1wiPnt7IG1zZyB9fTwvcD5cblxuICAgIDwhLS0gPT09PT09PT09PT09IOS6uueJqeWNoSA9PT09PT09PT09PT0gLS0+XG4gICAgPHRlbXBsYXRlIHYtaWY9XCJ0YWIgPT09ICdjaGFyYWN0ZXJzJyAmJiBtZW1vcnlcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJtZW0tZ3JpZFwiPlxuICAgICAgICA8YXNpZGUgY2xhc3M9XCJjYXJkXCI+XG4gICAgICAgICAgPGgzPuinkuiJsuWIl+ihqDwvaDM+XG4gICAgICAgICAgPGRpdiB2LWZvcj1cImMgaW4gbWVtb3J5LmNoYXJhY3RlcnNcIiA6a2V5PVwiYy5pZFwiIGNsYXNzPVwibWVtLWl0ZW1cIiBAY2xpY2s9XCJlZGl0Q2hhcmFjdGVyKGMpXCI+XG4gICAgICAgICAgICA8c3Bhbj57eyBjLm5hbWUgfX08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRhZ1wiPnt7IGMucm9sZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJtaW5pLWRlbFwiIEBjbGljay5zdG9wPVwib25EZWxldGVDaGFyYWN0ZXIoYylcIj7DlzwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIHYtaWY9XCIhbWVtb3J5LmNoYXJhY3RlcnMubGVuZ3RoXCIgY2xhc3M9XCJoaW50XCI+XG4gICAgICAgICAgICDmmoLml6DkurrnianljaHjgIJBSSDlrprnqL/nq6DoioLml7bkvJroh6rliqjnmbvorrDmlrDop5LoibLvvJvkuZ/lj6/miYvlt6Xmt7vliqDjgIJcbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDEwcHhcIiBAY2xpY2s9XCJuZXdDaGFyYWN0ZXJcIj7vvIsg5paw6KeS6ImyPC9idXR0b24+XG4gICAgICAgIDwvYXNpZGU+XG5cbiAgICAgICAgPHNlY3Rpb24gY2xhc3M9XCJjYXJkXCI+XG4gICAgICAgICAgPGgzPnt7IGNoYXJGb3JtLmlkID8gYOe8lui+ke+8miR7Y2hhckZvcm0ubmFtZX1gIDogJ+aWsOinkuiJsicgfX08L2gzPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3cyXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWw+6KeS6Imy5ZCNICo8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cImNoYXJGb3JtLm5hbWVcIiBwbGFjZWhvbGRlcj1cIuW8oOS4iVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbD7ouqvku708L2xhYmVsPlxuICAgICAgICAgICAgICA8c2VsZWN0IHYtbW9kZWw9XCJjaGFyRm9ybS5yb2xlXCI+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIuS4u+inklwiPuS4u+inkjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCLlj43mtL5cIj7lj43mtL48L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi6YWN6KeSXCI+6YWN6KeSPC9vcHRpb24+XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiB2LWZvcj1cImsgaW4gQ0hBUl9LRVlTXCIgOmtleT1cImtcIj5cbiAgICAgICAgICAgIDxsYWJlbD57eyBrIH19PC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB2LW1vZGVsPVwiY2hhckZvcm0uY2FyZFtrXVwiIDpwbGFjZWhvbGRlcj1cImAke2t977yI5Y+v55WZ56m677yJYFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBAY2xpY2s9XCJvblNhdmVDaGFyYWN0ZXJcIj7kv53lrZjkurrnianljaE8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gdi1pZj1cImNoYXJGb3JtLmlkXCIgQGNsaWNrPVwibmV3Q2hhcmFjdGVyXCI+5Y+W5raIPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvdGVtcGxhdGU+XG5cbiAgICA8IS0tID09PT09PT09PT09PSDkvI/nrJTlupMgPT09PT09PT09PT09IC0tPlxuICAgIDx0ZW1wbGF0ZSB2LWlmPVwidGFiID09PSAnZm9yZXNoYWRvd2luZ3MnICYmIG1lbW9yeVwiPlxuICAgICAgPHNlY3Rpb24gY2xhc3M9XCJjYXJkXCI+XG4gICAgICAgIDxoMz57eyBmRm9ybS5pZCA/IGDnvJbovpHkvI/nrJTvvJoke2ZGb3JtLnRpdGxlfWAgOiAn5paw5LyP56yUJyB9fTwvaDM+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJyb3cyXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbD7kvI/nrJTmoIfpopggKjwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cImZGb3JtLnRpdGxlXCIgcGxhY2Vob2xkZXI9XCLlpoLvvJpGMDEg56We56eY546J5L2pXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsPueKtuaAgTwvbGFiZWw+XG4gICAgICAgICAgICA8c2VsZWN0IHYtbW9kZWw9XCJmRm9ybS5zdGF0dXNcIj5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2LWZvcj1cInMgaW4gRlNfU1RBVFVTXCIgOmtleT1cInNcIiA6dmFsdWU9XCJzXCI+e3sgcyB9fTwvb3B0aW9uPlxuICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8bGFiZWw+5LyP56yU5YaF5a65PC9sYWJlbD5cbiAgICAgICAgPHRleHRhcmVhIHYtbW9kZWw9XCJmRm9ybS5kZXNjcmlwdGlvblwiIHJvd3M9XCIyXCIgcGxhY2Vob2xkZXI9XCLln4vorr7kuobku4DkuYjkv6Hmga/vvIzmnKrmnaXopoHlpoLkvZXmj63mmZNcIj48L3RleHRhcmVhPlxuICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBAY2xpY2s9XCJvblNhdmVGb3Jlc2hhZG93aW5nXCI+5L+d5a2Y5LyP56yUPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiB2LWlmPVwiZkZvcm0uaWRcIiBAY2xpY2s9XCJuZXdGb3Jlc2hhZG93aW5nXCI+5Y+W5raIPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICA8ZGl2IGNsYXNzPVwiZi1saXN0XCI+XG4gICAgICAgIDxkaXYgdi1mb3I9XCJmIGluIG1lbW9yeS5mb3Jlc2hhZG93aW5nc1wiIDprZXk9XCJmLmlkXCIgY2xhc3M9XCJmLWl0ZW1cIiBAY2xpY2s9XCJlZGl0Rm9yZXNoYWRvd2luZyhmKVwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlXCIgOmNsYXNzPVwiZi5zdGF0dXMgPT09ICflt7Llm57mlLYnID8gJ2ItZ3JlZW4nIDogZi5zdGF0dXMgPT09ICflup/lvIMnID8gJ2ItZ3JheScgOiAnYi15ZWxsb3cnXCI+XG4gICAgICAgICAgICAgIHt7IGYuc3RhdHVzIH19XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8Yj57eyBmLnRpdGxlIH19PC9iPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaW50XCI+e3sgZi5kZXNjcmlwdGlvbiB9fTwvZGl2PlxuICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJtaW5pLWRlbFwiIEBjbGljay5zdG9wPVwib25EZWxldGVGb3Jlc2hhZG93aW5nKGYpXCI+w5c8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxwIHYtaWY9XCIhbWVtb3J5LmZvcmVzaGFkb3dpbmdzLmxlbmd0aFwiIGNsYXNzPVwiaGludFwiPlxuICAgICAgICAgIOaaguaXoOS8j+eslOOAgkFJIOWumueov+aXtuS8muiHquWKqOeZu+iusOaWsOWfi+S8j+eslO+8m+S5n+WPr+aJi+W3pea3u+WKoO+8iOWmguaMieS9oOeahOinhOWIkue8luWPtyBGMDF+RjE277yJ44CCXG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuICAgIDwvdGVtcGxhdGU+XG5cbiAgICA8IS0tID09PT09PT09PT09PSDljbfnrqHnkIYgLyDnq6DmkZjopoEgPT09PT09PT09PT09IC0tPlxuICAgIDx0ZW1wbGF0ZSB2LWlmPVwidGFiID09PSAndm9sdW1lJyAmJiBtZW1vcnlcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzaGVsZi1oZWFkXCIgc3R5bGU9XCJtYXJnaW4tYm90dG9tOiAxMHB4XCI+XG4gICAgICAgIDxoMyBzdHlsZT1cIm1hcmdpbjogMFwiPuWNt+WIl+ihqDwvaDM+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZXJcIj48L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBAY2xpY2s9XCJvcGVuTmV3Vm9sdW1lXCI+77yLIOW8gOaWsOWNtzwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3M9XCJ2b2wtZ3JpZFwiPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgdi1mb3I9XCJ2IGluIG1lbW9yeS52b2x1bWVzXCJcbiAgICAgICAgICA6a2V5PVwidi5pZFwiXG4gICAgICAgICAgY2xhc3M9XCJ2b2wtaXRlbVwiXG4gICAgICAgICAgOmNsYXNzPVwieyBhY3RpdmU6IHZvbHVtZUZvcm0uaWQgPT09IHYuaWQgfVwiXG4gICAgICAgICAgQGNsaWNrPVwic2VsZWN0Vm9sdW1lKHYpXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8Yj7nrKx7eyB2LnZvbHVtZV9ubyB9feWNtyB7eyB2LnRpdGxlIH19PC9iPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZVwiIDpjbGFzcz1cInYuc3RhdHVzID09PSAn6L+e6L295LitJyA/ICdiLXllbGxvdycgOiAnYi1ncmF5J1wiPnt7IHYuc3RhdHVzIH19PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaW50XCI+XG4gICAgICAgICAgICB7eyB2LmNoYXB0ZXJfY291bnQgfX0g56uge3sgdi5zdW1tYXJ5ID8gJyDCtyDlt7LmnInljbfmkZjopoEnIDogJyDCtyDmnKrnlJ/miJDljbfmkZjopoEnIH19XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxzZWN0aW9uIHYtaWY9XCJ2b2x1bWVGb3JtLmlkXCIgY2xhc3M9XCJjYXJkXCIgc3R5bGU9XCJtYXJnaW4tdG9wOiAxNHB4XCI+XG4gICAgICAgIDxoMz7nvJbovpHvvJrnrKwge3sgbWVtb3J5LnZvbHVtZXMuZmluZCgodikgPT4gdi5pZCA9PT0gdm9sdW1lRm9ybS5pZCk/LnZvbHVtZV9ubyB9fSDljbc8L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzPVwicm93MlwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWw+5Y235ZCNPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB2LW1vZGVsPVwidm9sdW1lRm9ybS50aXRsZVwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbD7nirbmgIE8L2xhYmVsPlxuICAgICAgICAgICAgPHNlbGVjdCB2LW1vZGVsPVwidm9sdW1lRm9ybS5zdGF0dXNcIj5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIui/nui9veS4rVwiPui/nui9veS4rTwvb3B0aW9uPlxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwi5a6M57uTXCI+5a6M57uTPC9vcHRpb24+XG4gICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxsYWJlbD7ljbflpKfnurLvvIjnu4bnurLluIjop4TliJLmr4/nq6DnmoTmgLvkvp3mja7vvIk8L2xhYmVsPlxuICAgICAgICA8dGV4dGFyZWEgdi1tb2RlbD1cInZvbHVtZUZvcm0ub3V0bGluZVwiIHJvd3M9XCI4XCIgcGxhY2Vob2xkZXI9XCLlpoLvvJrmnKzljbflm7Tnu5XjgIzlrpfpl6jlpKfmr5TjgI3lsZXlvIDvvJoxLTUg56ug5oql5ZCN5LiO5pqX5rWBIOKGkiA2LTEwIOeroOWInei1m+m7kemprCDihpIgMTEtMTUg56ug5Yaz6LWb5a+55omL5L2/6K+IIOKGkiAxNi0xOCDnq6Dmj63nqb/pmLTosIvlpLrlhqAg4oaSIOWNt+acq+mSqeWtkO+8muelnuenmOmVv+iAgeeOsOi6q1wiPjwvdGV4dGFyZWE+XG4gICAgICAgIDxsYWJlbD7ljbfmkZjopoHvvIjnlLEgQUkg5rGH5oC75pys5Y235ZCE56ug5pGY6KaB55Sf5oiQ77yJPC9sYWJlbD5cbiAgICAgICAgPGRpdiB2LWlmPVwidm9sdW1lRm9ybS5zdW1tYXJ5XCIgY2xhc3M9XCJzdW1tYXJ5LWJveFwiPnt7IHZvbHVtZUZvcm0uc3VtbWFyeSB9fTwvZGl2PlxuICAgICAgICA8cCB2LWVsc2UgY2xhc3M9XCJoaW50XCI+5pyq55Sf5oiQ44CC56ug6IqC5a6a56i/5ZCO54K544CM4pyoIEFJIOeUn+aIkOWNt+aRmOimgeOAjeOAgjwvcD5cbiAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgQGNsaWNrPVwib25TYXZlVm9sdW1lXCI+5L+d5a2Y5Y23PC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiA6ZGlzYWJsZWQ9XCJnZW5uaW5nT3V0bGluZVwiIEBjbGljaz1cIm9uR2VuVm9sdW1lT3V0bGluZVwiPlxuICAgICAgICAgICAge3sgZ2VubmluZ091dGxpbmUgPyAn55Sf5oiQ5Lit4oCmJyA6ICfinKggQUkg55Sf5oiQ5Y235aSn57qy77yI6YeN5YaZ77yJJyB9fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gOmRpc2FibGVkPVwiZ2VubmluZ1N1bW1hcnlcIiBAY2xpY2s9XCJvbkdlblZvbHVtZVN1bW1hcnlcIj5cbiAgICAgICAgICAgIHt7IGdlbm5pbmdTdW1tYXJ5ID8gJ+axh+aAu+S4reKApicgOiAn4pyoIEFJIOeUn+aIkOWNt+aRmOimgScgfX1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxoMyBzdHlsZT1cIm1hcmdpbjogMjBweCAwIDRweFwiPueroOaRmOimge+8iOeUseaAu+e7k+W4iOmAkOeroOeUn+aIkO+8iTwvaDM+XG4gICAgICA8ZGl2IGNsYXNzPVwic3VtbWFyeS1jYXJkXCIgdi1mb3I9XCJzIGluIG1lbW9yeS5zdW1tYXJpZXNcIiA6a2V5PVwicy5jaGFwdGVyX25vXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGI+56yse3sgcy5jaGFwdGVyX25vIH1956ugIHt7IHMuY2hhcHRlcl90aXRsZSB9fTwvYj5cbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImhpbnRcIj57eyBmbXRUaW1lKHMuY3JlYXRlZF9hdCkgfX08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaGludFwiIHYtaWY9XCJzLm91dGxpbmVfcHJvZ3Jlc3NcIj7lpKfnurLov5vluqbvvJp7eyBzLm91dGxpbmVfcHJvZ3Jlc3MgfX08L2Rpdj5cbiAgICAgICAgPGRpdj57eyBzLnN1bW1hcnkgfX08L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInRhZ3NcIiB2LWlmPVwicy5rZXlfZXZlbnRzPy5sZW5ndGhcIj5cbiAgICAgICAgICA8c3BhbiB2LWZvcj1cIihldiwgaSkgaW4gcy5rZXlfZXZlbnRzXCIgOmtleT1cImlcIiBjbGFzcz1cInRhZ1wiPnt7IGV2IH19PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPHAgdi1pZj1cIiFtZW1vcnkuc3VtbWFyaWVzLmxlbmd0aFwiIGNsYXNzPVwiaGludFwiPuaaguaXoOaRmOimgeOAguWcqOW3peS9nOWPsOWvueeroOiKgueCueOAjPCfk50g5a6a56i/77yI5pu05paw6K6w5b+G77yJ44CN5ZCO55Sf5oiQ44CCPC9wPlxuXG4gICAgICA8IS0tIOW8gOaWsOWNt+W8ueeqlyAtLT5cbiAgICAgIDxkaXYgdi1pZj1cInNob3dOZXdWb2x1bWVcIiBjbGFzcz1cIm92ZXJsYXlcIiBAY2xpY2suc2VsZj1cInNob3dOZXdWb2x1bWUgPSBmYWxzZVwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWxcIj5cbiAgICAgICAgICA8aDM+5byA5paw5Y23PC9oMz5cbiAgICAgICAgICA8cCBjbGFzcz1cImhpbnRcIj7liJvlu7rlkI7kuIrkuIDljbflsIboh6rliqjmoIforrDkuLrjgIzlroznu5PjgI3vvIzmlrDnq6DoioLpu5jorqTlhpnlhaXmlrDljbc8L3A+XG4gICAgICAgICAgPGxhYmVsPuWNt+WQjTwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0IHYtbW9kZWw9XCJuZXdWb2xGb3JtLnRpdGxlXCIgLz5cbiAgICAgICAgICA8bGFiZWw+5Y235aSn57qy77yI5Y+v5YWIIEFJIOeUn+aIkOWGjeS/ruaUue+8iTwvbGFiZWw+XG4gICAgICAgICAgPHRleHRhcmVhIHYtbW9kZWw9XCJuZXdWb2xGb3JtLm91dGxpbmVcIiByb3dzPVwiNlwiIHBsYWNlaG9sZGVyPVwiQUkg5Lya5qC55o2u5YWo5Lmm566A5LuL44CB5LiK5LiA5Y235pGY6KaB5LiO5b6F5Zue5pS25LyP56yU55Sf5oiQ5pys5Y235aSn57qyXCI+PC90ZXh0YXJlYT5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICA8YnV0dG9uIDpkaXNhYmxlZD1cImdlbm5pbmdPdXRsaW5lXCIgQGNsaWNrPVwib25HZW5Wb2x1bWVPdXRsaW5lXCI+XG4gICAgICAgICAgICAgIHt7IGdlbm5pbmdPdXRsaW5lID8gJ+eUn+aIkOS4reKApicgOiAn4pyoIEFJIOeUn+aIkOWNt+Wkp+e6sicgfX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgOmRpc2FibGVkPVwiY3JlYXRpbmdWb2xcIiBAY2xpY2s9XCJvbkNyZWF0ZVZvbHVtZVwiPlxuICAgICAgICAgICAgICB7eyBjcmVhdGluZ1ZvbCA/ICfliJvlu7rkuK3igKYnIDogJ+WIm+W7uuaWsOWNtycgfX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiBAY2xpY2s9XCJzaG93TmV3Vm9sdW1lID0gZmFsc2VcIj7lj5bmtog8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3RlbXBsYXRlPlxuXG4gICAgPCEtLSA9PT09PT09PT09PT0g5a+85YWl6K6+5a6aID09PT09PT09PT09PSAtLT5cbiAgICA8dGVtcGxhdGUgdi1pZj1cInRhYiA9PT0gJ2ltcG9ydCdcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJpbXBvcnQtZ3JpZFwiPlxuICAgICAgICA8c2VjdGlvbiBjbGFzcz1cImNhcmRcIj5cbiAgICAgICAgICA8aDM+8J+TliDlr7zlhaXmlYXkuovlnKPnu488L2gzPlxuICAgICAgICAgIDxwIGNsYXNzPVwiaGludFwiPlxuICAgICAgICAgICAg5pW056+H5L2c5Li644CM6K6+5a6a6ZOB5b6L44CN5rOo5YWl5YaZ5omLL+agoeWvuS/nu4bnurLluIjmr4/mrKHnlJ/miJDvvJvoh6rliqjlkIzmraXkuablkI0v6aKY5p2QL+mjjuagvC/nroDku4sv55uu5qCH5a2X5pWwXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5tZCwudHh0XCIgQGNoYW5nZT1cIm9uRmlsZSgkZXZlbnQsICdiaWJsZScpXCIgLz5cbiAgICAgICAgICA8dGV4dGFyZWEgdi1tb2RlbD1cImltcG9ydFRleHRzLmJpYmxlXCIgcm93cz1cIjhcIiBwbGFjZWhvbGRlcj1cIumAieaLqeaIlueymOi0tCAwMC3mlYXkuovlnKPnu48ubWQg5YWo5paHXCI+PC90ZXh0YXJlYT5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIDpkaXNhYmxlZD1cImltcG9ydGluZ1wiIEBjbGljaz1cIm9uSW1wb3J0KCdiaWJsZScpXCI+5a+85YWl5pWF5LqL5Zyj57uPPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICA8c2VjdGlvbiBjbGFzcz1cImNhcmRcIj5cbiAgICAgICAgICA8aDM+8J+XuiDlr7zlhaXmlYXkuovlpKfnurI8L2gzPlxuICAgICAgICAgIDxwIGNsYXNzPVwiaGludFwiPlxuICAgICAgICAgICAg6Ieq5Yqo5oyJ44CMIyMjIOWNt1jjgI3lu7rnq4vliIbljbfnu5PmnoTlubbloavlhYXlkITljbflpKfnurLvvIjljbfkuIDov57ovb3kuK3jgIHlhbbkvZnmnKrlvIDlp4vvvInvvJvjgIzlhajkuabmgLvnurLjgI3kvZzkuLrnoazmgKfnuqLnur/ms6jlhaXnu4bnurLluIjvvJvjgIzlsI/or7TnroDku4vjgI3lkIzmraXkuLrnroDku4tcbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgYWNjZXB0PVwiLm1kLC50eHRcIiBAY2hhbmdlPVwib25GaWxlKCRldmVudCwgJ291dGxpbmUnKVwiIC8+XG4gICAgICAgICAgPHRleHRhcmVhIHYtbW9kZWw9XCJpbXBvcnRUZXh0cy5vdXRsaW5lXCIgcm93cz1cIjhcIiBwbGFjZWhvbGRlcj1cIumAieaLqeaIlueymOi0tCAwMi3mlYXkuovlpKfnurIubWQg5YWo5paHXCI+PC90ZXh0YXJlYT5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIDpkaXNhYmxlZD1cImltcG9ydGluZ1wiIEBjbGljaz1cIm9uSW1wb3J0KCdvdXRsaW5lJylcIj7lr7zlhaXmlYXkuovlpKfnurI8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzPVwiY2FyZFwiPlxuICAgICAgICAgIDxoMz7wn5GlIOWvvOWFpeS6uueJqeWNoTwvaDM+XG4gICAgICAgICAgPHAgY2xhc3M9XCJoaW50XCI+XG4gICAgICAgICAgICDmjInjgIwjIyBOLiDop5LoibLlkI3jgI3op6PmnpDmr4/lvKDljaHvvIjouqvku73oh6rliqjor4bliKvkuLvop5Iv5Y+N5rS+77yJ77yM5pW05Y2h5Y6f5paH5L+d55WZ5Li65Lq66K6+57qm5p2f5rOo5YWl5YaZ5omL5LiK5LiL5paHXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5tZCwudHh0XCIgQGNoYW5nZT1cIm9uRmlsZSgkZXZlbnQsICdjaGFyYWN0ZXJzJylcIiAvPlxuICAgICAgICAgIDx0ZXh0YXJlYSB2LW1vZGVsPVwiaW1wb3J0VGV4dHMuY2hhcmFjdGVyc1wiIHJvd3M9XCI4XCIgcGxhY2Vob2xkZXI9XCLpgInmi6nmiJbnspjotLQgMDEt5Lq654mp5Y2hLm1kIOWFqOaWh1wiPjwvdGV4dGFyZWE+XG4gICAgICAgICAgPGxhYmVsPuWvvOWFpeaooeW8jzwvbGFiZWw+XG4gICAgICAgICAgPHNlbGVjdCB2LW1vZGVsPVwiaW1wb3J0TW9kZVwiPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInJlcGxhY2VcIj7mm7/mjaLnjrDmnInlhajpg6jkurrnianljaE8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhcHBlbmRcIj7ov73liqDvvIjlkIzlkI3opobnm5bvvIk8L29wdGlvbj5cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIDpkaXNhYmxlZD1cImltcG9ydGluZ1wiIEBjbGljaz1cIm9uSW1wb3J0KCdjaGFyYWN0ZXJzJylcIj5cbiAgICAgICAgICAgICAge3sgaW1wb3J0aW5nID8gJ+WvvOWFpeS4reKApicgOiAn5a+85YWl5Lq654mp5Y2hJyB9fVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICA8c2VjdGlvbiBjbGFzcz1cImNhcmRcIj5cbiAgICAgICAgICA8aDM+4pyN77iPIOWvvOWFpSBBSSDlhpnkvZzpmZDliLbor408L2gzPlxuICAgICAgICAgIDxwIGNsYXNzPVwiaGludFwiPlxuICAgICAgICAgICAg57qm5p2f5YaZ5omL44CB5L+u56i/5ZKM5qCh5a+555qE6KGo6L6+5pa55byP77yM5YeP5bCR5qih5p2/5YyW6K+N5rGH5LiO5Y+l5byP77yb5LiN5pS55Y+Y5pWF5LqL6K6+5a6a77yM5Lmf5LiN6IO95pu/5Luj5Lq65bel5a6h56i/44CCXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxwIGNsYXNzPVwiaGludFwiIHYtaWY9XCJtZW1vcnk/LndyaXRpbmdfcmVzdHJpY3Rpb25zPy5oYXNfdGV4dFwiPlxuICAgICAgICAgICAg5b2T5YmN5bey5L+d5a2YIHt7IG1lbW9yeS53cml0aW5nX3Jlc3RyaWN0aW9ucy5sZW5ndGggfX0g5a2X77yb6LaF6ZW/5paH5qGj5LuF5Zyo5rOo5YWl5qih5Z6L5pe25L+d55WZ6aaW5bC+6YOo5YiG44CCXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5tZCwudHh0XCIgQGNoYW5nZT1cIm9uRmlsZSgkZXZlbnQsICdyZXN0cmljdGlvbnMnKVwiIC8+XG4gICAgICAgICAgPHRleHRhcmVhIHYtbW9kZWw9XCJpbXBvcnRUZXh0cy5yZXN0cmljdGlvbnNcIiByb3dzPVwiOFwiIHBsYWNlaG9sZGVyPVwi6YCJ5oup5oiW57KY6LS06ZmQ5Yi26K+N44CB56aB55So6K+N5ZKM6Ieq5qOA6KeE5YiZ5paH5qGjXCI+PC90ZXh0YXJlYT5cbiAgICAgICAgICA8bGFiZWw+5a+85YWl5qih5byPPC9sYWJlbD5cbiAgICAgICAgICA8c2VsZWN0IHYtbW9kZWw9XCJpbXBvcnRNb2RlXCI+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicmVwbGFjZVwiPuabv+aNoueOsOaciemZkOWItuivjeaWh+ahozwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFwcGVuZFwiPui/veWKoOWIsOeOsOacieaWh+ahozwvb3B0aW9uPlxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgOmRpc2FibGVkPVwiaW1wb3J0aW5nXCIgQGNsaWNrPVwib25JbXBvcnQoJ3Jlc3RyaWN0aW9ucycpXCI+XG4gICAgICAgICAgICAgIHt7IGltcG9ydGluZyA/ICflr7zlhaXkuK3igKYnIDogJ+WvvOWFpemZkOWItuivjeaWh+ahoycgfX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB2LWlmPVwibWVtb3J5Py53cml0aW5nX3Jlc3RyaWN0aW9ucz8uaGFzX3RleHRcIlxuICAgICAgICAgICAgICBjbGFzcz1cImRhbmdlclwiXG4gICAgICAgICAgICAgIDpkaXNhYmxlZD1cImltcG9ydGluZ1wiXG4gICAgICAgICAgICAgIEBjbGljaz1cIm9uQ2xlYXJSZXN0cmljdGlvbnNcIlxuICAgICAgICAgICAgPua4heepujwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxwIHYtaWY9XCJtc2cgJiYgdGFiID09PSAnaW1wb3J0J1wiIGNsYXNzPVwibXNnXCIgOmNsYXNzPVwibXNnT2sgPyAnb2snIDogJ2VycidcIj57eyBtc2cgfX08L3A+XG4gICAgPC90ZW1wbGF0ZT5cbiAgPC9kaXY+XG48L3RlbXBsYXRlPlxuIl0sIm1hcHBpbmdzIjoiQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7QUFFakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUV0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUV0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRXJELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRXRFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25COztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQztBQUNGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQztBQUNGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRXJDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDO0FBQ0Y7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQztBQUNGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUU3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0I7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0I7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDO0FBQ0Y7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQztBQUNGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6RSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQztBQUNGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDO0FBQ0Y7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUUzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEM7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQztBQUNGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0UsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUM7QUFDRjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7O3FCQUtMLEtBQUssRUFBQyxZQUFZO3FCQU1sQixLQUFLLEVBQUMsTUFBTTs7O0VBVVYsS0FBSyxFQUFDLFVBQVU7O3FCQUNaLEtBQUssRUFBQyxNQUFNOztxQkFJVCxLQUFLLEVBQUMsS0FBSzs7OztFQUdpQixLQUFLLEVBQUMsTUFBTTs7cUJBTXpDLEtBQUssRUFBQyxNQUFNO3NCQUVkLEtBQUssRUFBQyxNQUFNOztzQkFrQlosS0FBSyxFQUFDLEtBQUs7c0JBVVgsS0FBSyxFQUFDLE1BQU07c0JBRWQsS0FBSyxFQUFDLE1BQU07O3NCQWNaLEtBQUssRUFBQyxLQUFLO3NCQU1iLEtBQUssRUFBQyxRQUFROztzQkFRVixLQUFLLEVBQUMsTUFBTTs7OztFQUdxQixLQUFLLEVBQUMsTUFBTTs7c0JBY2pELEtBQUssRUFBQyxVQUFVOztzQkFZWixLQUFLLEVBQUMsTUFBTTs7O0VBTVMsS0FBSyxFQUFDLE1BQU07RUFBQyxLQUF3QixFQUF4QixxQkFBd0I7O3NCQUU1RCxLQUFLLEVBQUMsTUFBTTs7O0VBZ0JjLEtBQUssRUFBQyxhQUFhOzs7O0VBQ3hDLEtBQUssRUFBQyxNQUFNOztzQkFDakIsS0FBSyxFQUFDLEtBQUs7OztzQkFlUixLQUFLLEVBQUMsTUFBTTs7O0VBRWYsS0FBSyxFQUFDLE1BQU07Ozs7RUFFWixLQUFLLEVBQUMsTUFBTTs7OztFQUlnQixLQUFLLEVBQUMsTUFBTTs7c0JBSXhDLEtBQUssRUFBQyxPQUFPO3NCQU9YLEtBQUssRUFBQyxLQUFLOztzQkFLWCxLQUFLLEVBQUMsS0FBSzs7c0JBWWYsS0FBSyxFQUFDLGFBQWE7c0JBQ2IsS0FBSyxFQUFDLE1BQU07c0JBT2QsS0FBSyxFQUFDLEtBQUs7O3NCQUtULEtBQUssRUFBQyxNQUFNO3NCQU9kLEtBQUssRUFBQyxLQUFLOztzQkFLVCxLQUFLLEVBQUMsTUFBTTtzQkFZZCxLQUFLLEVBQUMsS0FBSzs7c0JBT1QsS0FBSyxFQUFDLE1BQU07OztFQUtoQixLQUFLLEVBQUMsTUFBTTs7c0JBVVYsS0FBSyxFQUFDLEtBQUs7Ozs7O3dCQWhReEIsb0JBK1FNO0lBOVFKLG9CQUlNLE9BSk4sVUFJTTtNQUhKLG9CQUErRTtRQUF2RSxLQUFLLEVBQUMsTUFBTTtRQUFFLE9BQUssdUNBQUUsYUFBTSxDQUFDLElBQUksV0FBVyxjQUFPO1NBQUssU0FBTztrQ0FDdEUsb0JBQWdCLFlBQVosU0FBTztrQ0FDWCxvQkFBMEQsVUFBcEQsS0FBSyxFQUFDLE1BQU0sSUFBQyxrQ0FBZ0M7O0lBR3JELG9CQUtNLE9BTE4sVUFLTTtNQUpKLG9CQUFnRztRQUEzRixLQUFLLG1CQUFDLEtBQUssWUFBbUIsVUFBRztRQUFzQixPQUFLLHVDQUFFLFVBQUc7U0FBaUIsS0FBRztNQUMxRixvQkFBd0c7UUFBbkcsS0FBSyxtQkFBQyxLQUFLLFlBQW1CLFVBQUc7UUFBMEIsT0FBSyx1Q0FBRSxVQUFHO1NBQXFCLEtBQUc7TUFDbEcsb0JBQThGO1FBQXpGLEtBQUssbUJBQUMsS0FBSyxZQUFtQixVQUFHO1FBQWtCLE9BQUssdUNBQUUsVUFBRztTQUFhLFdBQVM7TUFDeEYsb0JBQTRGO1FBQXZGLEtBQUssbUJBQUMsS0FBSyxZQUFtQixVQUFHO1FBQWtCLE9BQUssdUNBQUUsVUFBRztTQUFhLFNBQU87O0tBRS9FLFVBQUc7dUJBQVosb0JBQXFFOztVQUF2RCxLQUFLLG1CQUFDLEtBQUssRUFBUyxZQUFLOzRCQUFvQixVQUFHOztJQUU5RCxzREFBc0M7S0FDdEIsVUFBRyxxQkFBcUIsYUFBTTt1QkFDNUMsb0JBdUNNLE9BdkNOLFVBdUNNO1VBdENKLG9CQVdRLFNBWFIsVUFXUTt3Q0FWTixvQkFBYSxZQUFULE1BQUk7K0JBQ1Isb0JBSU0sNkJBSlcsYUFBTSxDQUFDLFVBQVUsR0FBdEIsQ0FBQztvQ0FBYixvQkFJTTtnQkFKK0IsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFO2dCQUFFLEtBQUssRUFBQyxVQUFVO2dCQUFFLE9BQUssYUFBRSxvQkFBYSxDQUFDLENBQUM7O2dCQUN0RixvQkFBeUIsK0JBQWhCLENBQUMsQ0FBQyxJQUFJO2dCQUNmLG9CQUFxQyxRQUFyQyxVQUFxQyxtQkFBaEIsQ0FBQyxDQUFDLElBQUk7Z0JBQzNCLG9CQUFzRTtrQkFBOUQsS0FBSyxFQUFDLFVBQVU7a0JBQUUsT0FBSyw0QkFBTyx3QkFBaUIsQ0FBQyxDQUFDO21CQUFHLEdBQUM7OztjQUVyRCxhQUFNLENBQUMsVUFBVSxDQUFDLE1BQU07K0JBQWxDLG9CQUVJLEtBRkosVUFFSSxFQUY2QyxrQ0FFakQ7O1lBQ0Esb0JBQXFGO2NBQTdFLEtBQUssRUFBQyxTQUFTO2NBQUMsS0FBd0IsRUFBeEIscUJBQXdCO2NBQUUsT0FBSyxFQUFFLG1CQUFZO2VBQUUsT0FBSzs7VUFHOUUsb0JBd0JVLFdBeEJWLFVBd0JVO1lBdkJSLG9CQUEwRCw2QkFBbkQsZUFBUSxDQUFDLEVBQUUsU0FBUyxlQUFRLENBQUMsSUFBSTtZQUN4QyxvQkFhTSxPQWJOLFdBYU07Y0FaSixvQkFHTTs0Q0FGSixvQkFBb0IsZUFBYixPQUFLO2dDQUNaLG9CQUFrRDsrRUFBbEMsZUFBUSxDQUFDLElBQUk7a0JBQUUsV0FBVyxFQUFDLElBQUk7O2dDQUEvQixlQUFRLENBQUMsSUFBSTs7O2NBRS9CLG9CQU9NOzRDQU5KLG9CQUFpQixlQUFWLElBQUU7Z0NBQ1Qsb0JBSVM7K0VBSlEsZUFBUSxDQUFDLElBQUk7O2tCQUM1QixvQkFBOEIsWUFBdEIsS0FBSyxFQUFDLElBQUksSUFBQyxJQUFFO2tCQUNyQixvQkFBOEIsWUFBdEIsS0FBSyxFQUFDLElBQUksSUFBQyxJQUFFO2tCQUNyQixvQkFBOEIsWUFBdEIsS0FBSyxFQUFDLElBQUksSUFBQyxJQUFFOztrQ0FITixlQUFRLENBQUMsSUFBSTs7OzsyQkFPbEMsb0JBR00sNkJBSFcsZ0JBQVMsR0FBZCxDQUFDO3FCQUFiLG9CQUdNLFNBSHVCLEdBQUcsRUFBRSxDQUFDO2dCQUNqQyxvQkFBc0IsZ0NBQVosQ0FBQztnQ0FDWCxvQkFBK0Q7cURBQS9DLGVBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztrQkFBSSxXQUFXLEtBQUssQ0FBQzs7Z0NBQXBDLGVBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQzs7OztZQUVqQyxvQkFHTSxPQUhOLFdBR007Y0FGSixvQkFBK0Q7Z0JBQXZELEtBQUssRUFBQyxTQUFTO2dCQUFFLE9BQUssRUFBRSxzQkFBZTtpQkFBRSxPQUFLO2VBQ3hDLGVBQVEsQ0FBQyxFQUFFO2lDQUF6QixvQkFBNEQ7O29CQUFoQyxPQUFLLEVBQUUsbUJBQVk7cUJBQUUsSUFBRTs7Ozs7O0lBTTNELHNEQUFzQztLQUN0QixVQUFHLHlCQUF5QixhQUFNO3VCQUFsRCxvQkFzQ1c7VUFyQ1Qsb0JBb0JVLFdBcEJWLFdBb0JVO1lBbkJSLG9CQUF1RCw2QkFBaEQsWUFBSyxDQUFDLEVBQUUsV0FBVyxZQUFLLENBQUMsS0FBSztZQUNyQyxvQkFXTSxPQVhOLFdBV007Y0FWSixvQkFHTTs0Q0FGSixvQkFBcUIsZUFBZCxRQUFNO2dDQUNiLG9CQUF3RDsrRUFBeEMsWUFBSyxDQUFDLEtBQUs7a0JBQUUsV0FBVyxFQUFDLFlBQVk7O2dDQUFyQyxZQUFLLENBQUMsS0FBSzs7O2NBRTdCLG9CQUtNOzRDQUpKLG9CQUFpQixlQUFWLElBQUU7Z0NBQ1Qsb0JBRVM7K0VBRlEsWUFBSyxDQUFDLE1BQU07O2lDQUMzQixvQkFBbUUsNkJBQS9DLGdCQUFTLEdBQWQsQ0FBQzsyQkFBaEIsb0JBQW1FO3NCQUFuQyxHQUFHLEVBQUUsQ0FBQztzQkFBRyxLQUFLLEVBQUUsQ0FBQzt3Q0FBSyxDQUFDOzs7a0NBRHhDLFlBQUssQ0FBQyxNQUFNOzs7O3dDQUtqQyxvQkFBbUIsZUFBWixNQUFJOzRCQUNYLG9CQUF3RjsyRUFBckUsWUFBSyxDQUFDLFdBQVc7Y0FBRSxJQUFJLEVBQUMsR0FBRztjQUFDLFdBQVcsRUFBQyxpQkFBaUI7OzRCQUF6RCxZQUFLLENBQUMsV0FBVzs7WUFDcEMsb0JBR00sT0FITixXQUdNO2NBRkosb0JBQWtFO2dCQUExRCxLQUFLLEVBQUMsU0FBUztnQkFBRSxPQUFLLEVBQUUsMEJBQW1CO2lCQUFFLE1BQUk7ZUFDM0MsWUFBSyxDQUFDLEVBQUU7aUNBQXRCLG9CQUE2RDs7b0JBQXBDLE9BQUssRUFBRSx1QkFBZ0I7cUJBQUUsSUFBRTs7OztVQUl4RCxvQkFjTSxPQWROLFdBY007K0JBYkosb0JBU00sNkJBVFcsYUFBTSxDQUFDLGNBQWMsR0FBMUIsQ0FBQztvQ0FBYixvQkFTTTtnQkFUbUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFO2dCQUFFLEtBQUssRUFBQyxRQUFRO2dCQUFFLE9BQUssYUFBRSx3QkFBaUIsQ0FBQyxDQUFDOztnQkFDNUYsb0JBS007a0JBSkosb0JBRU87b0JBRkQsS0FBSyxtQkFBQyxPQUFPLEVBQVMsQ0FBQyxDQUFDLE1BQU0seUJBQXlCLENBQUMsQ0FBQyxNQUFNO3NDQUNoRSxDQUFDLENBQUMsTUFBTTtrQkFFYixvQkFBb0IsNEJBQWQsQ0FBQyxDQUFDLEtBQUs7O2dCQUVmLG9CQUEyQyxPQUEzQyxXQUEyQyxtQkFBdEIsQ0FBQyxDQUFDLFdBQVc7Z0JBQ2xDLG9CQUEwRTtrQkFBbEUsS0FBSyxFQUFDLFVBQVU7a0JBQUUsT0FBSyw0QkFBTyw0QkFBcUIsQ0FBQyxDQUFDO21CQUFHLEdBQUM7OztjQUV6RCxhQUFNLENBQUMsY0FBYyxDQUFDLE1BQU07K0JBQXRDLG9CQUVJLEtBRkosV0FFSSxFQUZpRCxrREFFckQ7Ozs7O0lBSUosNERBQTRDO0tBQzVCLFVBQUcsaUJBQWlCLGFBQU07dUJBQTFDLG9CQTRGVztVQTNGVCxvQkFJTTtZQUpELEtBQUssRUFBQyxZQUFZO1lBQUMsS0FBMkIsRUFBM0Isd0JBQTJCOzt3Q0FDakQsb0JBQThCLFFBQTFCLEtBQWlCLEVBQWpCLGNBQWlCLElBQUMsS0FBRzt3Q0FDekIsb0JBQTBCLFNBQXJCLEtBQUssRUFBQyxRQUFRO1lBQ25CLG9CQUE2RDtjQUFyRCxLQUFLLEVBQUMsU0FBUztjQUFFLE9BQUssRUFBRSxvQkFBYTtlQUFFLE9BQUs7O1VBR3RELG9CQWdCTSxPQWhCTixXQWdCTTsrQkFmSixvQkFjTSw2QkFiUSxhQUFNLENBQUMsT0FBTyxHQUFuQixDQUFDO29DQURWLG9CQWNNO2dCQVpILEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRTtnQkFDVixLQUFLLG1CQUFDLFVBQVUsWUFDRSxpQkFBVSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDdkMsT0FBSyxhQUFFLG1CQUFZLENBQUMsQ0FBQzs7Z0JBRXRCLG9CQUdNO2tCQUZKLG9CQUF3QyxXQUFyQyxHQUFDLG9CQUFHLENBQUMsQ0FBQyxTQUFTLElBQUcsSUFBRSxvQkFBRyxDQUFDLENBQUMsS0FBSztrQkFDakMsb0JBQTZGO29CQUF2RixLQUFLLG1CQUFDLE9BQU8sRUFBUyxDQUFDLENBQUMsTUFBTTtzQ0FBdUMsQ0FBQyxDQUFDLE1BQU07O2dCQUVyRixvQkFFTSxPQUZOLFdBRU0sbUJBREQsQ0FBQyxDQUFDLGFBQWEsSUFBRyxJQUFFLG9CQUFHLENBQUMsQ0FBQyxPQUFPOzs7O1dBSzFCLGlCQUFVLENBQUMsRUFBRTs2QkFBNUIsb0JBNkJVLFdBN0JWLFdBNkJVO2dCQTVCUixvQkFBbUYsWUFBL0UsT0FBSyxvQkFBRyxhQUFNLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxpQkFBVSxDQUFDLEVBQUUsR0FBRyxTQUFTLElBQUcsSUFBRTtnQkFDOUUsb0JBWU0sT0FaTixXQVlNO2tCQVhKLG9CQUdNO2dEQUZKLG9CQUFpQixlQUFWLElBQUU7b0NBQ1Qsb0JBQW9DO3FGQUFwQixpQkFBVSxDQUFDLEtBQUs7O29DQUFoQixpQkFBVSxDQUFDLEtBQUs7OztrQkFFbEMsb0JBTU07Z0RBTEosb0JBQWlCLGVBQVYsSUFBRTtvQ0FDVCxvQkFHUztxRkFIUSxpQkFBVSxDQUFDLE1BQU07O3NCQUNoQyxvQkFBZ0MsWUFBeEIsS0FBSyxFQUFDLEtBQUssSUFBQyxLQUFHO3NCQUN2QixvQkFBOEIsWUFBdEIsS0FBSyxFQUFDLElBQUksSUFBQyxJQUFFOztzQ0FGTixpQkFBVSxDQUFDLE1BQU07Ozs7NENBTXRDLG9CQUErQixlQUF4QixrQkFBZ0I7Z0NBQ3ZCLG9CQUE4SjtpRkFBM0ksaUJBQVUsQ0FBQyxPQUFPO2tCQUFFLElBQUksRUFBQyxHQUFHO2tCQUFDLFdBQVcsRUFBQyxzRkFBc0Y7O2dDQUEvSCxpQkFBVSxDQUFDLE9BQU87OzRDQUNyQyxvQkFBbUMsZUFBNUIsc0JBQW9CO2lCQUNoQixpQkFBVSxDQUFDLE9BQU87bUNBQTdCLG9CQUFpRixPQUFqRixXQUFpRixtQkFBM0IsaUJBQVUsQ0FBQyxPQUFPO21DQUN4RSxvQkFBa0QsS0FBbEQsV0FBa0QsRUFBM0IseUJBQXVCO2dCQUM5QyxvQkFRTSxPQVJOLFdBUU07a0JBUEosb0JBQTBEO29CQUFsRCxLQUFLLEVBQUMsU0FBUztvQkFBRSxPQUFLLEVBQUUsbUJBQVk7cUJBQUUsS0FBRztrQkFDakQsb0JBRVM7b0JBRkEsUUFBUSxFQUFFLHFCQUFjO29CQUFHLE9BQUssRUFBRSx5QkFBa0I7c0NBQ3hELHFCQUFjO2tCQUVuQixvQkFFUztvQkFGQSxRQUFRLEVBQUUscUJBQWM7b0JBQUcsT0FBSyxFQUFFLHlCQUFrQjtzQ0FDeEQscUJBQWM7Ozs7c0NBS3ZCLG9CQUFpRCxRQUE3QyxLQUEwQixFQUExQix1QkFBMEIsSUFBQyxlQUFhOzZCQUM1QyxvQkFVTSw2QkFWZ0MsYUFBTSxDQUFDLFNBQVMsR0FBckIsQ0FBQztrQ0FBbEMsb0JBVU07Y0FWRCxLQUFLLEVBQUMsY0FBYztjQUFnQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLFVBQVU7O2NBQ3hFLG9CQUdNO2dCQUZKLG9CQUFpRCxXQUE5QyxHQUFDLG9CQUFHLENBQUMsQ0FBQyxVQUFVLElBQUcsSUFBRSxvQkFBRyxDQUFDLENBQUMsYUFBYTtnQkFDMUMsb0JBQXFELFFBQXJELFdBQXFELG1CQUEvQixjQUFPLENBQUMsQ0FBQyxDQUFDLFVBQVU7O2VBRXBCLENBQUMsQ0FBQyxnQkFBZ0I7aUNBQTFDLG9CQUErRSxPQUEvRSxXQUErRSxFQUFuQyxPQUFLLG9CQUFHLENBQUMsQ0FBQyxnQkFBZ0I7O2NBQ3RFLG9CQUEwQiw4QkFBbEIsQ0FBQyxDQUFDLE9BQU87ZUFDTyxDQUFDLENBQUMsVUFBVSxFQUFFLE1BQU07aUNBQTVDLG9CQUVNLE9BRk4sV0FFTTt1Q0FESixvQkFBMEUsNkJBQWxELENBQUMsQ0FBQyxVQUFVLEdBQXRCLEVBQUUsRUFBRSxDQUFDOzRDQUFuQixvQkFBMEU7d0JBQW5DLEdBQUcsRUFBRSxDQUFDO3dCQUFFLEtBQUssRUFBQyxLQUFLOzBDQUFJLEVBQUU7Ozs7OztZQUcxRCxhQUFNLENBQUMsU0FBUyxDQUFDLE1BQU07NkJBQWpDLG9CQUFrRixLQUFsRixXQUFrRixFQUFsQyxnQ0FBOEI7O1VBRTlFLDhCQUFjO1dBQ0gsb0JBQWE7NkJBQXhCLG9CQW9CTTs7Z0JBcEJvQixLQUFLLEVBQUMsU0FBUztnQkFBRSxPQUFLLHdEQUFPLG9CQUFhOztnQkFDbEUsb0JBa0JNLE9BbEJOLFdBa0JNOzhDQWpCSixvQkFBWSxZQUFSLEtBQUc7OENBQ1Asb0JBQThDLE9BQTNDLEtBQUssRUFBQyxNQUFNLElBQUMsNEJBQTBCOzhDQUMxQyxvQkFBaUIsZUFBVixJQUFFO2tDQUNULG9CQUFvQzttRkFBcEIsaUJBQVUsQ0FBQyxLQUFLOztrQ0FBaEIsaUJBQVUsQ0FBQyxLQUFLOzs4Q0FDaEMsb0JBQStCLGVBQXhCLGtCQUFnQjtrQ0FDdkIsb0JBQXNHO21GQUFuRixpQkFBVSxDQUFDLE9BQU87b0JBQUUsSUFBSSxFQUFDLEdBQUc7b0JBQUMsV0FBVyxFQUFDLDhCQUE4Qjs7a0NBQXZFLGlCQUFVLENBQUMsT0FBTzs7a0JBQ3JDLG9CQUlNLE9BSk4sV0FJTTtvQkFISixvQkFFUztzQkFGQSxRQUFRLEVBQUUscUJBQWM7c0JBQUcsT0FBSyxFQUFFLHlCQUFrQjt3Q0FDeEQscUJBQWM7O2tCQUdyQixvQkFLTSxPQUxOLFdBS007b0JBSkosb0JBRVM7c0JBRkQsS0FBSyxFQUFDLFNBQVM7c0JBQUUsUUFBUSxFQUFFLGtCQUFXO3NCQUFHLE9BQUssRUFBRSxxQkFBYzt3Q0FDakUsa0JBQVc7b0JBRWhCLG9CQUFrRDtzQkFBekMsT0FBSyx5Q0FBRSxvQkFBYTt1QkFBVSxJQUFFOzs7Ozs7O0lBTWpELHVEQUF1QztLQUN2QixVQUFHO3VCQUFuQixvQkEwRVc7VUF6RVQsb0JBdUVNLE9BdkVOLFdBdUVNO1lBdEVKLG9CQVVVLFdBVlYsV0FVVTswQ0FUUixvQkFBa0IsWUFBZCxXQUFTOzBDQUNiLG9CQUVJLE9BRkQsS0FBSyxFQUFDLE1BQU0sSUFBQyxrREFFaEI7Y0FDQSxvQkFBeUU7Z0JBQWxFLElBQUksRUFBQyxNQUFNO2dCQUFDLE1BQU0sRUFBQyxVQUFVO2dCQUFFLFFBQU0seUNBQUUsYUFBTSxDQUFDLE1BQU07OzhCQUMzRCxvQkFBNEY7K0VBQXpFLGtCQUFXLENBQUMsS0FBSztnQkFBRSxJQUFJLEVBQUMsR0FBRztnQkFBQyxXQUFXLEVBQUMscUJBQXFCOzs4QkFBN0Qsa0JBQVcsQ0FBQyxLQUFLOztjQUNwQyxvQkFFTSxPQUZOLFdBRU07Z0JBREosb0JBQXdGO2tCQUFoRixLQUFLLEVBQUMsU0FBUztrQkFBRSxRQUFRLEVBQUUsZ0JBQVM7a0JBQUcsT0FBSyx5Q0FBRSxlQUFRO21CQUFXLFFBQU07OztZQUluRixvQkFVVSxXQVZWLFdBVVU7MENBVFIsb0JBQWtCLFlBQWQsV0FBUzswQ0FDYixvQkFFSSxPQUZELEtBQUssRUFBQyxNQUFNLElBQUMsdUVBRWhCO2NBQ0Esb0JBQTJFO2dCQUFwRSxJQUFJLEVBQUMsTUFBTTtnQkFBQyxNQUFNLEVBQUMsVUFBVTtnQkFBRSxRQUFNLHlDQUFFLGFBQU0sQ0FBQyxNQUFNOzs4QkFDM0Qsb0JBQThGOytFQUEzRSxrQkFBVyxDQUFDLE9BQU87Z0JBQUUsSUFBSSxFQUFDLEdBQUc7Z0JBQUMsV0FBVyxFQUFDLHFCQUFxQjs7OEJBQS9ELGtCQUFXLENBQUMsT0FBTzs7Y0FDdEMsb0JBRU0sT0FGTixXQUVNO2dCQURKLG9CQUEwRjtrQkFBbEYsS0FBSyxFQUFDLFNBQVM7a0JBQUUsUUFBUSxFQUFFLGdCQUFTO2tCQUFHLE9BQUsseUNBQUUsZUFBUTttQkFBYSxRQUFNOzs7WUFJckYsb0JBaUJVLFdBakJWLFdBaUJVOzBDQWhCUixvQkFBaUIsWUFBYixVQUFROzBDQUNaLG9CQUVJLE9BRkQsS0FBSyxFQUFDLE1BQU0sSUFBQyxxREFFaEI7Y0FDQSxvQkFBOEU7Z0JBQXZFLElBQUksRUFBQyxNQUFNO2dCQUFDLE1BQU0sRUFBQyxVQUFVO2dCQUFFLFFBQU0seUNBQUUsYUFBTSxDQUFDLE1BQU07OzhCQUMzRCxvQkFBZ0c7K0VBQTdFLGtCQUFXLENBQUMsVUFBVTtnQkFBRSxJQUFJLEVBQUMsR0FBRztnQkFBQyxXQUFXLEVBQUMsb0JBQW9COzs4QkFBakUsa0JBQVcsQ0FBQyxVQUFVOzswQ0FDekMsb0JBQW1CLGVBQVosTUFBSTs4QkFDWCxvQkFHUzsrRUFIUSxpQkFBVTs7Z0JBQ3pCLG9CQUEwQyxZQUFsQyxLQUFLLEVBQUMsU0FBUyxJQUFDLFdBQVM7Z0JBQ2pDLG9CQUF3QyxZQUFoQyxLQUFLLEVBQUMsUUFBUSxJQUFDLFVBQVE7O2dDQUZoQixpQkFBVTs7Y0FJM0Isb0JBSU0sT0FKTixXQUlNO2dCQUhKLG9CQUVTO2tCQUZELEtBQUssRUFBQyxTQUFTO2tCQUFFLFFBQVEsRUFBRSxnQkFBUztrQkFBRyxPQUFLLHlDQUFFLGVBQVE7b0NBQ3pELGdCQUFTOzs7WUFLbEIsb0JBMEJVLFdBMUJWLFdBMEJVOzBDQXpCUixvQkFBdUIsWUFBbkIsZ0JBQWM7MENBQ2xCLG9CQUVJLE9BRkQsS0FBSyxFQUFDLE1BQU0sSUFBQyxpREFFaEI7ZUFDc0IsYUFBTSxFQUFFLG9CQUFvQixFQUFFLFFBQVE7aUNBQTVELG9CQUVJLEtBRkosV0FFSSxFQUYwRCxTQUN0RCxvQkFBRyxhQUFNLENBQUMsb0JBQW9CLENBQUMsTUFBTSxJQUFHLHdCQUNoRDs7Y0FDQSxvQkFBZ0Y7Z0JBQXpFLElBQUksRUFBQyxNQUFNO2dCQUFDLE1BQU0sRUFBQyxVQUFVO2dCQUFFLFFBQU0seUNBQUUsYUFBTSxDQUFDLE1BQU07OzhCQUMzRCxvQkFBbUc7K0VBQWhGLGtCQUFXLENBQUMsWUFBWTtnQkFBRSxJQUFJLEVBQUMsR0FBRztnQkFBQyxXQUFXLEVBQUMscUJBQXFCOzs4QkFBcEUsa0JBQVcsQ0FBQyxZQUFZOzswQ0FDM0Msb0JBQW1CLGVBQVosTUFBSTs4QkFDWCxvQkFHUzsrRUFIUSxpQkFBVTs7Z0JBQ3pCLG9CQUEwQyxZQUFsQyxLQUFLLEVBQUMsU0FBUyxJQUFDLFdBQVM7Z0JBQ2pDLG9CQUF1QyxZQUEvQixLQUFLLEVBQUMsUUFBUSxJQUFDLFNBQU87O2dDQUZmLGlCQUFVOztjQUkzQixvQkFVTSxPQVZOLFdBVU07Z0JBVEosb0JBRVM7a0JBRkQsS0FBSyxFQUFDLFNBQVM7a0JBQUUsUUFBUSxFQUFFLGdCQUFTO2tCQUFHLE9BQUsseUNBQUUsZUFBUTtvQ0FDekQsZ0JBQVM7aUJBR04sYUFBTSxFQUFFLG9CQUFvQixFQUFFLFFBQVE7bUNBRDlDLG9CQUtZOztzQkFIVixLQUFLLEVBQUMsUUFBUTtzQkFDYixRQUFRLEVBQUUsZ0JBQVM7c0JBQ25CLE9BQUssRUFBRSwwQkFBbUI7dUJBQzVCLElBQUU7Ozs7O1dBSUEsVUFBRyxJQUFJLFVBQUc7NkJBQW5CLG9CQUF5Rjs7Z0JBQXZELEtBQUssbUJBQUMsS0FBSyxFQUFTLFlBQUs7a0NBQW9CLFVBQUciLCJpZ25vcmVMaXN0IjpbXX0=