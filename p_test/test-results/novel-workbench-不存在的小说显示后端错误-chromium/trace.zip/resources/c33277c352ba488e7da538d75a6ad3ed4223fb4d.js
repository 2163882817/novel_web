import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/BookshelfView.vue");import { onMounted, reactive, ref } from "/node_modules/.vite/deps/vue.js?v=755ab909"
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=755ab909"
import { createNovel, deleteNovel, listNovels } from "/src/api.js"
import { fmtTime } from "/src/utils.js"


const _sfc_main = {
  __name: 'BookshelfView',
  setup(__props, { expose: __expose }) {
  __expose();

const router = useRouter()
const novels = ref([])
const loading = ref(true)
const showCreate = ref(false)
const errMsg = ref('')
const form = reactive({
  title: '',
  genre: '',
  style: '',
  protagonist: '',
  world_setting: '',
  synopsis: '',
  target_word_count: 0,
})

async function load() {
  loading.value = true
  errMsg.value = ''
  try {
    novels.value = await listNovels()
  } catch (e) {
    errMsg.value = e.message
  } finally {
    loading.value = false
  }
}
onMounted(load)

function openCreate() {
  Object.keys(form).forEach((k) => (form[k] = k === 'target_word_count' ? 0 : ''))
  errMsg.value = ''
  showCreate.value = true
}

async function onCreate() {
  errMsg.value = ''
  if (!form.title.trim()) {
    errMsg.value = '请填写书名'
    return
  }
  try {
    const n = await createNovel({ ...form, target_word_count: Number(form.target_word_count) || 0 })
    showCreate.value = false
    router.push(`/novel/${n.id}`)
  } catch (e) {
    errMsg.value = e.message
  }
}

async function onDelete(n) {
  if (!confirm(`确定删除《${n.title}》？所有章节将一并删除，不可恢复。`)) return
  try {
    await deleteNovel(n.id)
    load()
  } catch (e) {
    errMsg.value = e.message
  }
}

const __returned__ = { router, novels, loading, showCreate, errMsg, form, load, openCreate, onCreate, onDelete, onMounted, reactive, ref, get useRouter() { return useRouter }, get createNovel() { return createNovel }, get deleteNovel() { return deleteNovel }, get listNovels() { return listNovels }, get fmtTime() { return fmtTime } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, renderList as _renderList, Fragment as _Fragment, withModifiers as _withModifiers, vModelText as _vModelText, withDirectives as _withDirectives } from "/node_modules/.vite/deps/vue.js?v=755ab909"

const _hoisted_1 = {
  key: 0,
  class: "msg err"
}
const _hoisted_2 = {
  key: 1,
  class: "hint"
}
const _hoisted_3 = {
  key: 2,
  class: "hint"
}
const _hoisted_4 = {
  key: 3,
  class: "shelf-grid"
}
const _hoisted_5 = ["onClick"]
const _hoisted_6 = ["onClick"]
const _hoisted_7 = { class: "tags" }
const _hoisted_8 = {
  key: 0,
  class: "tag"
}
const _hoisted_9 = {
  key: 1,
  class: "tag"
}
const _hoisted_10 = { class: "hint" }
const _hoisted_11 = { class: "modal" }
const _hoisted_12 = { class: "row2" }
const _hoisted_13 = { class: "row2" }
const _hoisted_14 = {
  key: 0,
  class: "msg err"
}
const _hoisted_15 = { class: "row" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", null, [
    _createElementVNode("div", { class: "shelf-head" }, [
      _cache[9] || (_cache[9] = _createElementVNode("h2", null, "书架", -1 /* CACHED */)),
      _cache[10] || (_cache[10] = _createElementVNode("div", { class: "spacer" }, null, -1 /* CACHED */)),
      _createElementVNode("button", {
        class: "primary",
        onClick: $setup.openCreate
      }, "＋ 新建小说")
    ]),
    ($setup.errMsg)
      ? (_openBlock(), _createElementBlock("p", _hoisted_1, _toDisplayString($setup.errMsg), 1 /* TEXT */))
      : _createCommentVNode("v-if", true),
    ($setup.loading)
      ? (_openBlock(), _createElementBlock("p", _hoisted_2, "加载中…"))
      : (!$setup.novels.length)
        ? (_openBlock(), _createElementBlock("p", _hoisted_3, " 书架空空如也。点击「新建小说」创建第一本书，填入设定后即可开始 AI 写作。 "))
        : (_openBlock(), _createElementBlock("div", _hoisted_4, [
            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.novels, (n) => {
              return (_openBlock(), _createElementBlock("div", {
                key: n.id,
                class: "novel-card",
                onClick: $event => ($setup.router.push(`/novel/${n.id}`))
              }, [
                _createElementVNode("button", {
                  class: "card-del",
                  title: "删除",
                  onClick: _withModifiers($event => ($setup.onDelete(n)), ["stop"])
                }, "×", 8 /* PROPS */, _hoisted_6),
                _createElementVNode("h3", null, _toDisplayString(n.title), 1 /* TEXT */),
                _createElementVNode("div", _hoisted_7, [
                  (n.genre)
                    ? (_openBlock(), _createElementBlock("span", _hoisted_8, _toDisplayString(n.genre), 1 /* TEXT */))
                    : _createCommentVNode("v-if", true),
                  (n.style)
                    ? (_openBlock(), _createElementBlock("span", _hoisted_9, _toDisplayString(n.style), 1 /* TEXT */))
                    : _createCommentVNode("v-if", true)
                ]),
                _createElementVNode("p", _hoisted_10, _toDisplayString(n.chapter_count) + " 章 · " + _toDisplayString(n.status) + " · 更新于 " + _toDisplayString($setup.fmtTime(n.updated_at)), 1 /* TEXT */)
              ], 8 /* PROPS */, _hoisted_5))
            }), 128 /* KEYED_FRAGMENT */))
          ])),
    _createCommentVNode(" 新建小说弹窗 "),
    ($setup.showCreate)
      ? (_openBlock(), _createElementBlock("div", {
          key: 4,
          class: "overlay",
          onClick: _cache[8] || (_cache[8] = _withModifiers($event => ($setup.showCreate = false), ["self"]))
        }, [
          _createElementVNode("div", _hoisted_11, [
            _cache[15] || (_cache[15] = _createElementVNode("h3", null, "新建小说", -1 /* CACHED */)),
            _cache[16] || (_cache[16] = _createElementVNode("label", null, "书名 *", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("input", {
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.form.title) = $event)),
              placeholder: "凡人修仙传"
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.title]
            ]),
            _createElementVNode("div", _hoisted_12, [
              _createElementVNode("div", null, [
                _cache[11] || (_cache[11] = _createElementVNode("label", null, "题材", -1 /* CACHED */)),
                _withDirectives(_createElementVNode("input", {
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.form.genre) = $event)),
                  placeholder: "玄幻 / 都市 / 科幻"
                }, null, 512 /* NEED_PATCH */), [
                  [_vModelText, $setup.form.genre]
                ])
              ]),
              _createElementVNode("div", null, [
                _cache[12] || (_cache[12] = _createElementVNode("label", null, "风格", -1 /* CACHED */)),
                _withDirectives(_createElementVNode("input", {
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.form.style) = $event)),
                  placeholder: "轻松幽默 / 热血 / 悬疑"
                }, null, 512 /* NEED_PATCH */), [
                  [_vModelText, $setup.form.style]
                ])
              ])
            ]),
            _createElementVNode("div", _hoisted_13, [
              _createElementVNode("div", null, [
                _cache[13] || (_cache[13] = _createElementVNode("label", null, "主角", -1 /* CACHED */)),
                _withDirectives(_createElementVNode("input", {
                  "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.form.protagonist) = $event)),
                  placeholder: "主角名"
                }, null, 512 /* NEED_PATCH */), [
                  [_vModelText, $setup.form.protagonist]
                ])
              ]),
              _createElementVNode("div", null, [
                _cache[14] || (_cache[14] = _createElementVNode("label", null, "目标字数（可选）", -1 /* CACHED */)),
                _withDirectives(_createElementVNode("input", {
                  "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => (($setup.form.target_word_count) = $event)),
                  type: "number",
                  min: "0",
                  placeholder: "500000"
                }, null, 512 /* NEED_PATCH */), [
                  [
                    _vModelText,
                    $setup.form.target_word_count,
                    void 0,
                    { number: true }
                  ]
                ])
              ])
            ]),
            _cache[17] || (_cache[17] = _createElementVNode("label", null, "世界观设定", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("textarea", {
              "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => (($setup.form.world_setting) = $event)),
              rows: "2",
              placeholder: "如：修仙界，练气→筑基→金丹"
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.world_setting]
            ]),
            _cache[18] || (_cache[18] = _createElementVNode("label", null, "内容简介", -1 /* CACHED */)),
            _withDirectives(_createElementVNode("textarea", {
              "onUpdate:modelValue": _cache[6] || (_cache[6] = $event => (($setup.form.synopsis) = $event)),
              rows: "2",
              placeholder: "一句话故事主线，AI 会据此把控剧情方向"
            }, null, 512 /* NEED_PATCH */), [
              [_vModelText, $setup.form.synopsis]
            ]),
            ($setup.errMsg)
              ? (_openBlock(), _createElementBlock("p", _hoisted_14, _toDisplayString($setup.errMsg), 1 /* TEXT */))
              : _createCommentVNode("v-if", true),
            _createElementVNode("div", _hoisted_15, [
              _createElementVNode("button", {
                class: "primary",
                onClick: $setup.onCreate
              }, "创建"),
              _createElementVNode("button", {
                onClick: _cache[7] || (_cache[7] = $event => ($setup.showCreate = false))
              }, "取消")
            ])
          ])
        ]))
      : _createCommentVNode("v-if", true)
  ]))
}



_sfc_main.__hmrId = "e6737bdd"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/86184/Desktop/novel_web/frontend/src/views/BookshelfView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQm9va3NoZWxmVmlldy52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cbmltcG9ydCB7IG9uTW91bnRlZCwgcmVhY3RpdmUsIHJlZiB9IGZyb20gJ3Z1ZSdcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ3Z1ZS1yb3V0ZXInXG5pbXBvcnQgeyBjcmVhdGVOb3ZlbCwgZGVsZXRlTm92ZWwsIGxpc3ROb3ZlbHMgfSBmcm9tICcuLi9hcGknXG5pbXBvcnQgeyBmbXRUaW1lIH0gZnJvbSAnLi4vdXRpbHMnXG5cbmNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG5jb25zdCBub3ZlbHMgPSByZWYoW10pXG5jb25zdCBsb2FkaW5nID0gcmVmKHRydWUpXG5jb25zdCBzaG93Q3JlYXRlID0gcmVmKGZhbHNlKVxuY29uc3QgZXJyTXNnID0gcmVmKCcnKVxuY29uc3QgZm9ybSA9IHJlYWN0aXZlKHtcbiAgdGl0bGU6ICcnLFxuICBnZW5yZTogJycsXG4gIHN0eWxlOiAnJyxcbiAgcHJvdGFnb25pc3Q6ICcnLFxuICB3b3JsZF9zZXR0aW5nOiAnJyxcbiAgc3lub3BzaXM6ICcnLFxuICB0YXJnZXRfd29yZF9jb3VudDogMCxcbn0pXG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWQoKSB7XG4gIGxvYWRpbmcudmFsdWUgPSB0cnVlXG4gIGVyck1zZy52YWx1ZSA9ICcnXG4gIHRyeSB7XG4gICAgbm92ZWxzLnZhbHVlID0gYXdhaXQgbGlzdE5vdmVscygpXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBlcnJNc2cudmFsdWUgPSBlLm1lc3NhZ2VcbiAgfSBmaW5hbGx5IHtcbiAgICBsb2FkaW5nLnZhbHVlID0gZmFsc2VcbiAgfVxufVxub25Nb3VudGVkKGxvYWQpXG5cbmZ1bmN0aW9uIG9wZW5DcmVhdGUoKSB7XG4gIE9iamVjdC5rZXlzKGZvcm0pLmZvckVhY2goKGspID0+IChmb3JtW2tdID0gayA9PT0gJ3RhcmdldF93b3JkX2NvdW50JyA/IDAgOiAnJykpXG4gIGVyck1zZy52YWx1ZSA9ICcnXG4gIHNob3dDcmVhdGUudmFsdWUgPSB0cnVlXG59XG5cbmFzeW5jIGZ1bmN0aW9uIG9uQ3JlYXRlKCkge1xuICBlcnJNc2cudmFsdWUgPSAnJ1xuICBpZiAoIWZvcm0udGl0bGUudHJpbSgpKSB7XG4gICAgZXJyTXNnLnZhbHVlID0gJ+ivt+Whq+WGmeS5puWQjSdcbiAgICByZXR1cm5cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IG4gPSBhd2FpdCBjcmVhdGVOb3ZlbCh7IC4uLmZvcm0sIHRhcmdldF93b3JkX2NvdW50OiBOdW1iZXIoZm9ybS50YXJnZXRfd29yZF9jb3VudCkgfHwgMCB9KVxuICAgIHNob3dDcmVhdGUudmFsdWUgPSBmYWxzZVxuICAgIHJvdXRlci5wdXNoKGAvbm92ZWwvJHtuLmlkfWApXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBlcnJNc2cudmFsdWUgPSBlLm1lc3NhZ2VcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBvbkRlbGV0ZShuKSB7XG4gIGlmICghY29uZmlybShg56Gu5a6a5Yig6Zmk44CKJHtuLnRpdGxlfeOAi++8n+aJgOacieeroOiKguWwhuS4gOW5tuWIoOmZpO+8jOS4jeWPr+aBouWkjeOAgmApKSByZXR1cm5cbiAgdHJ5IHtcbiAgICBhd2FpdCBkZWxldGVOb3ZlbChuLmlkKVxuICAgIGxvYWQoKVxuICB9IGNhdGNoIChlKSB7XG4gICAgZXJyTXNnLnZhbHVlID0gZS5tZXNzYWdlXG4gIH1cbn1cbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG4gIDxkaXY+XG4gICAgPGRpdiBjbGFzcz1cInNoZWxmLWhlYWRcIj5cbiAgICAgIDxoMj7kuabmnrY8L2gyPlxuICAgICAgPGRpdiBjbGFzcz1cInNwYWNlclwiPjwvZGl2PlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBAY2xpY2s9XCJvcGVuQ3JlYXRlXCI+77yLIOaWsOW7uuWwj+ivtDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuXG4gICAgPHAgdi1pZj1cImVyck1zZ1wiIGNsYXNzPVwibXNnIGVyclwiPnt7IGVyck1zZyB9fTwvcD5cbiAgICA8cCB2LWlmPVwibG9hZGluZ1wiIGNsYXNzPVwiaGludFwiPuWKoOi9veS4reKApjwvcD5cbiAgICA8cCB2LWVsc2UtaWY9XCIhbm92ZWxzLmxlbmd0aFwiIGNsYXNzPVwiaGludFwiPlxuICAgICAg5Lmm5p6256m656m65aaC5Lmf44CC54K55Ye744CM5paw5bu65bCP6K+044CN5Yib5bu656ys5LiA5pys5Lmm77yM5aGr5YWl6K6+5a6a5ZCO5Y2z5Y+v5byA5aeLIEFJIOWGmeS9nOOAglxuICAgIDwvcD5cblxuICAgIDxkaXYgdi1lbHNlIGNsYXNzPVwic2hlbGYtZ3JpZFwiPlxuICAgICAgPGRpdlxuICAgICAgICB2LWZvcj1cIm4gaW4gbm92ZWxzXCJcbiAgICAgICAgOmtleT1cIm4uaWRcIlxuICAgICAgICBjbGFzcz1cIm5vdmVsLWNhcmRcIlxuICAgICAgICBAY2xpY2s9XCJyb3V0ZXIucHVzaChgL25vdmVsLyR7bi5pZH1gKVwiXG4gICAgICA+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJjYXJkLWRlbFwiIHRpdGxlPVwi5Yig6ZmkXCIgQGNsaWNrLnN0b3A9XCJvbkRlbGV0ZShuKVwiPsOXPC9idXR0b24+XG4gICAgICAgIDxoMz57eyBuLnRpdGxlIH19PC9oMz5cbiAgICAgICAgPGRpdiBjbGFzcz1cInRhZ3NcIj5cbiAgICAgICAgICA8c3BhbiB2LWlmPVwibi5nZW5yZVwiIGNsYXNzPVwidGFnXCI+e3sgbi5nZW5yZSB9fTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiB2LWlmPVwibi5zdHlsZVwiIGNsYXNzPVwidGFnXCI+e3sgbi5zdHlsZSB9fTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxwIGNsYXNzPVwiaGludFwiPnt7IG4uY2hhcHRlcl9jb3VudCB9fSDnq6Agwrcge3sgbi5zdGF0dXMgfX0gwrcg5pu05paw5LqOIHt7IGZtdFRpbWUobi51cGRhdGVkX2F0KSB9fTwvcD5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuXG4gICAgPCEtLSDmlrDlu7rlsI/or7TlvLnnqpcgLS0+XG4gICAgPGRpdiB2LWlmPVwic2hvd0NyZWF0ZVwiIGNsYXNzPVwib3ZlcmxheVwiIEBjbGljay5zZWxmPVwic2hvd0NyZWF0ZSA9IGZhbHNlXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibW9kYWxcIj5cbiAgICAgICAgPGgzPuaWsOW7uuWwj+ivtDwvaDM+XG4gICAgICAgIDxsYWJlbD7kuablkI0gKjwvbGFiZWw+XG4gICAgICAgIDxpbnB1dCB2LW1vZGVsPVwiZm9ybS50aXRsZVwiIHBsYWNlaG9sZGVyPVwi5Yeh5Lq65L+u5LuZ5LygXCIgLz5cbiAgICAgICAgPGRpdiBjbGFzcz1cInJvdzJcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsPumimOadkDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cImZvcm0uZ2VucmVcIiBwbGFjZWhvbGRlcj1cIueOhOW5uyAvIOmDveW4giAvIOenkeW5u1wiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbD7po47moLw8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHYtbW9kZWw9XCJmb3JtLnN0eWxlXCIgcGxhY2Vob2xkZXI9XCLovbvmnb7lub3pu5ggLyDng63ooYAgLyDmgqznlpFcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInJvdzJcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsPuS4u+inkjwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cImZvcm0ucHJvdGFnb25pc3RcIiBwbGFjZWhvbGRlcj1cIuS4u+inkuWQjVwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbD7nm67moIflrZfmlbDvvIjlj6/pgInvvIk8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHYtbW9kZWwubnVtYmVyPVwiZm9ybS50YXJnZXRfd29yZF9jb3VudFwiIHR5cGU9XCJudW1iZXJcIiBtaW49XCIwXCIgcGxhY2Vob2xkZXI9XCI1MDAwMDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGxhYmVsPuS4lueVjOinguiuvuWumjwvbGFiZWw+XG4gICAgICAgIDx0ZXh0YXJlYSB2LW1vZGVsPVwiZm9ybS53b3JsZF9zZXR0aW5nXCIgcm93cz1cIjJcIiBwbGFjZWhvbGRlcj1cIuWmgu+8muS/ruS7meeVjO+8jOe7g+awlOKGkuetkeWfuuKGkumHkeS4uVwiPjwvdGV4dGFyZWE+XG4gICAgICAgIDxsYWJlbD7lhoXlrrnnroDku4s8L2xhYmVsPlxuICAgICAgICA8dGV4dGFyZWEgdi1tb2RlbD1cImZvcm0uc3lub3BzaXNcIiByb3dzPVwiMlwiIHBsYWNlaG9sZGVyPVwi5LiA5Y+l6K+d5pWF5LqL5Li757q/77yMQUkg5Lya5o2u5q2k5oqK5o6n5Ymn5oOF5pa55ZCRXCI+PC90ZXh0YXJlYT5cbiAgICAgICAgPHAgdi1pZj1cImVyck1zZ1wiIGNsYXNzPVwibXNnIGVyclwiPnt7IGVyck1zZyB9fTwvcD5cbiAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgQGNsaWNrPVwib25DcmVhdGVcIj7liJvlu7o8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uIEBjbGljaz1cInNob3dDcmVhdGUgPSBmYWxzZVwiPuWPlua2iDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG4iXSwibWFwcGluZ3MiOiJBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7O0FBRWpDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQzs7QUFFRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQztBQUNGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7OztFQVdxQixLQUFLLEVBQUMsU0FBUzs7OztFQUNkLEtBQUssRUFBQyxNQUFNOzs7O0VBQ0EsS0FBSyxFQUFDLE1BQU07Ozs7RUFJOUIsS0FBSyxFQUFDLFlBQVk7Ozs7cUJBU3JCLEtBQUssRUFBQyxNQUFNOzs7RUFDTSxLQUFLLEVBQUMsS0FBSzs7OztFQUNYLEtBQUssRUFBQyxLQUFLOztzQkFFL0IsS0FBSyxFQUFDLE1BQU07c0JBTVosS0FBSyxFQUFDLE9BQU87c0JBSVgsS0FBSyxFQUFDLE1BQU07c0JBVVosS0FBSyxFQUFDLE1BQU07OztFQWNBLEtBQUssRUFBQyxTQUFTOztzQkFDM0IsS0FBSyxFQUFDLEtBQUs7Ozt3QkE3RHRCLG9CQW1FTTtJQWxFSixvQkFJTSxTQUpELEtBQUssRUFBQyxZQUFZO2dDQUNyQixvQkFBVyxZQUFQLElBQUU7a0NBQ04sb0JBQTBCLFNBQXJCLEtBQUssRUFBQyxRQUFRO01BQ25CLG9CQUEyRDtRQUFuRCxLQUFLLEVBQUMsU0FBUztRQUFFLE9BQUssRUFBRSxpQkFBVTtTQUFFLFFBQU07O0tBRzNDLGFBQU07dUJBQWYsb0JBQWlELEtBQWpELFVBQWlELG1CQUFiLGFBQU07O0tBQ2pDLGNBQU87dUJBQWhCLG9CQUF1QyxLQUF2QyxVQUF1QyxFQUFSLE1BQUk7VUFDcEIsYUFBTSxDQUFDLE1BQU07eUJBQTVCLG9CQUVJLEtBRkosVUFFSSxFQUZ1QywwQ0FFM0M7eUJBRUEsb0JBZU0sT0FmTixVQWVNOytCQWRKLG9CQWFNLDZCQVpRLGFBQU0sR0FBWCxDQUFDO29DQURWLG9CQWFNO2dCQVhILEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRTtnQkFDVixLQUFLLEVBQUMsWUFBWTtnQkFDakIsT0FBSyxhQUFFLGFBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxDQUFDLEVBQUU7O2dCQUVsQyxvQkFBd0U7a0JBQWhFLEtBQUssRUFBQyxVQUFVO2tCQUFDLEtBQUssRUFBQyxJQUFJO2tCQUFFLE9BQUssNEJBQU8sZUFBUSxDQUFDLENBQUM7bUJBQUcsR0FBQztnQkFDL0Qsb0JBQXNCLDZCQUFmLENBQUMsQ0FBQyxLQUFLO2dCQUNkLG9CQUdNLE9BSE4sVUFHTTttQkFGUSxDQUFDLENBQUMsS0FBSztxQ0FBbkIsb0JBQXFELFFBQXJELFVBQXFELG1CQUFqQixDQUFDLENBQUMsS0FBSzs7bUJBQy9CLENBQUMsQ0FBQyxLQUFLO3FDQUFuQixvQkFBcUQsUUFBckQsVUFBcUQsbUJBQWpCLENBQUMsQ0FBQyxLQUFLOzs7Z0JBRTdDLG9CQUE4RixLQUE5RixXQUE4RixtQkFBM0UsQ0FBQyxDQUFDLGFBQWEsSUFBRyxPQUFLLG9CQUFHLENBQUMsQ0FBQyxNQUFNLElBQUcsU0FBTyxvQkFBRyxjQUFPLENBQUMsQ0FBQyxDQUFDLFVBQVU7Ozs7SUFJMUYsK0JBQWU7S0FDSixpQkFBVTt1QkFBckIsb0JBbUNNOztVQW5DaUIsS0FBSyxFQUFDLFNBQVM7VUFBRSxPQUFLLHNEQUFPLGlCQUFVOztVQUM1RCxvQkFpQ00sT0FqQ04sV0FpQ007d0NBaENKLG9CQUFhLFlBQVQsTUFBSTt3Q0FDUixvQkFBbUIsZUFBWixNQUFJOzRCQUNYLG9CQUFrRDsyRUFBbEMsV0FBSSxDQUFDLEtBQUs7Y0FBRSxXQUFXLEVBQUMsT0FBTzs7NEJBQS9CLFdBQUksQ0FBQyxLQUFLOztZQUMxQixvQkFTTSxPQVROLFdBU007Y0FSSixvQkFHTTs0Q0FGSixvQkFBaUIsZUFBVixJQUFFO2dDQUNULG9CQUF5RDsrRUFBekMsV0FBSSxDQUFDLEtBQUs7a0JBQUUsV0FBVyxFQUFDLGNBQWM7O2dDQUF0QyxXQUFJLENBQUMsS0FBSzs7O2NBRTVCLG9CQUdNOzRDQUZKLG9CQUFpQixlQUFWLElBQUU7Z0NBQ1Qsb0JBQTJEOytFQUEzQyxXQUFJLENBQUMsS0FBSztrQkFBRSxXQUFXLEVBQUMsZ0JBQWdCOztnQ0FBeEMsV0FBSSxDQUFDLEtBQUs7Ozs7WUFHOUIsb0JBU00sT0FUTixXQVNNO2NBUkosb0JBR007NENBRkosb0JBQWlCLGVBQVYsSUFBRTtnQ0FDVCxvQkFBc0Q7K0VBQXRDLFdBQUksQ0FBQyxXQUFXO2tCQUFFLFdBQVcsRUFBQyxLQUFLOztnQ0FBbkMsV0FBSSxDQUFDLFdBQVc7OztjQUVsQyxvQkFHTTs0Q0FGSixvQkFBdUIsZUFBaEIsVUFBUTtnQ0FDZixvQkFBNEY7K0VBQXJFLFdBQUksQ0FBQyxpQkFBaUI7a0JBQUUsSUFBSSxFQUFDLFFBQVE7a0JBQUMsR0FBRyxFQUFDLEdBQUc7a0JBQUMsV0FBVyxFQUFDLFFBQVE7Ozs7b0JBQWxFLFdBQUksQ0FBQyxpQkFBaUI7O3NCQUE5QixNQUFNLEVBQWQsSUFBdUM7Ozs7O3dDQUdsRCxvQkFBb0IsZUFBYixPQUFLOzRCQUNaLG9CQUF3RjsyRUFBckUsV0FBSSxDQUFDLGFBQWE7Y0FBRSxJQUFJLEVBQUMsR0FBRztjQUFDLFdBQVcsRUFBQyxnQkFBZ0I7OzRCQUF6RCxXQUFJLENBQUMsYUFBYTs7d0NBQ3JDLG9CQUFtQixlQUFaLE1BQUk7NEJBQ1gsb0JBQXlGOzJFQUF0RSxXQUFJLENBQUMsUUFBUTtjQUFFLElBQUksRUFBQyxHQUFHO2NBQUMsV0FBVyxFQUFDLHNCQUFzQjs7NEJBQTFELFdBQUksQ0FBQyxRQUFROzthQUN2QixhQUFNOytCQUFmLG9CQUFpRCxLQUFqRCxXQUFpRCxtQkFBYixhQUFNOztZQUMxQyxvQkFHTSxPQUhOLFdBR007Y0FGSixvQkFBcUQ7Z0JBQTdDLEtBQUssRUFBQyxTQUFTO2dCQUFFLE9BQUssRUFBRSxlQUFRO2lCQUFFLElBQUU7Y0FDNUMsb0JBQStDO2dCQUF0QyxPQUFLLHVDQUFFLGlCQUFVO2lCQUFVLElBQUUiLCJpZ25vcmVMaXN0IjpbXX0=