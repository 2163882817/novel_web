import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue");const _sfc_main = {  }
import { createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=755ab909"

const _hoisted_1 = { class: "page" }
const _hoisted_2 = { class: "topbar" }
const _hoisted_3 = { class: "nav" }

function _sfc_render(_ctx, _cache) {
  const _component_router_link = _resolveComponent("router-link")
  const _component_router_view = _resolveComponent("router-view")

  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createElementVNode("header", _hoisted_2, [
      _cache[2] || (_cache[2] = _createElementVNode("h1", null, "AI 网文写作台", -1 /* CACHED */)),
      _createElementVNode("nav", _hoisted_3, [
        _createVNode(_component_router_link, { to: "/" }, {
          default: _withCtx(() => [...(_cache[0] || (_cache[0] = [
            _createTextVNode("书架", -1 /* CACHED */)
          ]))]),
          _: 1 /* STABLE */
        }),
        _createVNode(_component_router_link, { to: "/config" }, {
          default: _withCtx(() => [...(_cache[1] || (_cache[1] = [
            _createTextVNode("API 配置", -1 /* CACHED */)
          ]))]),
          _: 1 /* STABLE */
        })
      ])
    ]),
    _createVNode(_component_router_view)
  ]))
}



_sfc_main.__hmrId = "7a7a37b1"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/86184/Desktop/novel_web/frontend/src/App.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvODYxODQvRGVza3RvcC9ub3ZlbF93ZWIvZnJvbnRlbmQvc3JjL0FwcC52dWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cbiAgPGRpdiBjbGFzcz1cInBhZ2VcIj5cbiAgICA8aGVhZGVyIGNsYXNzPVwidG9wYmFyXCI+XG4gICAgICA8aDE+QUkg572R5paH5YaZ5L2c5Y+wPC9oMT5cbiAgICAgIDxuYXYgY2xhc3M9XCJuYXZcIj5cbiAgICAgICAgPHJvdXRlci1saW5rIHRvPVwiL1wiPuS5puaetjwvcm91dGVyLWxpbms+XG4gICAgICAgIDxyb3V0ZXItbGluayB0bz1cIi9jb25maWdcIj5BUEkg6YWN572uPC9yb3V0ZXItbGluaz5cbiAgICAgIDwvbmF2PlxuICAgIDwvaGVhZGVyPlxuICAgIDxyb3V0ZXItdmlldyAvPlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG4iXSwibWFwcGluZ3MiOiI7OztxQkFJTyxLQUFLLEVBQUMsTUFBTTtxQkFDUCxLQUFLLEVBQUMsUUFBUTtxQkFFZixLQUFLLEVBQUMsS0FBSzs7Ozs7O3dCQUhwQixvQkFTTSxPQVROLFVBU007SUFSSixvQkFNUyxVQU5ULFVBTVM7Z0NBTFAsb0JBQWlCLFlBQWIsVUFBUTtNQUNaLG9CQUdNLE9BSE4sVUFHTTtRQUZKLGFBQW9DLDBCQUF2QixFQUFFLEVBQUMsR0FBRzs0QkFBQyxDQUFFOzZCQUFGLElBQUU7Ozs7UUFDdEIsYUFBOEMsMEJBQWpDLEVBQUUsRUFBQyxTQUFTOzRCQUFDLENBQU07NkJBQU4sUUFBTTs7Ozs7O0lBR3BDLGFBQWUiLCJpZ25vcmVMaXN0IjpbXX0=