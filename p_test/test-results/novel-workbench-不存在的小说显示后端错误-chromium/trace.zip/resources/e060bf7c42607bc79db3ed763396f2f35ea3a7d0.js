import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/NovelView.vue");import { computed, onMounted, reactive, ref } from "/node_modules/.vite/deps/vue.js?v=755ab909"
import { useRoute, useRouter } from "/node_modules/.vite/deps/vue-router.js?v=755ab909"
import {
  checkChapter,
  deleteChapter,
  exportChapterTxt,
  finalizeChapter,
  generateVariants,
  genOutline,
  genTitles,
  getNovel,
  reviseChapter,
  saveChapter,
  streamWrite,
  updateChapter,
} from "/src/api.js"
import { fmtTime } from "/src/utils.js"


const _sfc_main = {
  __name: 'NovelView',
  setup(__props, { expose: __expose }) {
  __expose();

const route = useRoute()
const router = useRouter()
const novelId = Number(route.params.id)

const detail = ref(null) // { novel, volumes }
const loadError = ref('')

const volumes = computed(() => detail.value?.volumes || [])
const chapters = computed(() => volumes.value.flatMap((v) => v.chapters))
const nextChapterNo = computed(() => chapters.value.reduce((m, c) => Math.max(m, c.chapter_no), 0) + 1)

/* 面板状态：new = 写新章节，edit = 编辑已有章节 */
const mode = ref('new')
const currentId = ref(null)
const currentStatus = ref('')
const current = reactive({ title: '', content: '' })
const writeForm = reactive({ outline: '', previous_text: '' })

/* ① 细纲师 */
const plannerRaw = ref(null)
const planning = ref(false)
const planError = ref('')

/* ② 写手（流式） */
const output = ref('')
const variants = ref([])
const variantsWriting = ref(false)
const variantsError = ref('')
const writing = ref(false)
const writeError = ref('')
const stats = ref(null)
const saveTitle = ref('')
let abortCtrl = null

/* ③ 校对 / 修稿 / ④ 总结 */
const checkReport = ref(null)
const checking = ref(false)
const revising = ref(false)
const revisePreview = ref('')
const finalizeResult = ref(null)
const finalizing = ref(false)

const selectedIssues = computed(() => (checkReport.value?.issues || []).filter((it) => it.selected))

/* 标题师 */
const titleCandidates = ref([])
const titling = ref(false)
const currentChapterNo = ref(0)

const msg = ref('')
const msgOk = ref(true)
const charCount = computed(() => output.value.replace(/\s/g, '').length)

async function load() {
  loadError.value = ''
  try {
    detail.value = await getNovel(novelId)
    openNew()
  } catch (e) {
    loadError.value = e.message
  }
}
onMounted(load)

function resetTransient() {
  plannerRaw.value = null
  planError.value = ''
  output.value = ''
  variants.value = []
  variantsError.value = ''
  stats.value = null
  writeError.value = ''
  checkReport.value = null
  revisePreview.value = ''
  finalizeResult.value = null
  titleCandidates.value = []
  msg.value = ''
}

function openNew() {
  mode.value = 'new'
  currentId.value = null
  currentStatus.value = ''
  currentChapterNo.value = 0
  current.title = ''
  current.content = ''
  resetTransient()
  saveTitle.value = `第${nextChapterNo.value}章`
}

function openChapter(ch) {
  mode.value = 'edit'
  currentId.value = ch.id
  currentStatus.value = ch.status
  currentChapterNo.value = ch.chapter_no
  current.title = ch.title
  current.content = ch.content
  resetTransient()
  writeForm.outline = ch.detailed_outline || ''
  writeForm.previous_text = ''
}

/* ---------- ① 细纲师 ---------- */
function outlineToText(data) {
  const lines = []
  if (data.chapter_title) lines.push(`标题：${data.chapter_title}`)
  for (const s of data.scenes || []) {
    lines.push(
      `\n场景 ${s.scene_no}｜地点：${s.location || '未定'}｜出场：${(s.participants || []).join('、') || '未定'}`,
    )
    if (s.goal) lines.push(`  剧情作用：${s.goal}`)
    if (s.events) lines.push(`  事件：${s.events}`)
  }
  if (data.foreshadowings_planted?.length)
    lines.push('\n埋设伏笔：' + data.foreshadowings_planted.map((f) => `${f.title}（${f.description}）`).join('；'))
  if (data.foreshadowings_resolved?.length) lines.push(`回收伏笔：${data.foreshadowings_resolved.join('、')}`)
  if (data.hook) lines.push(`\n章末钩子：${data.hook}`)
  if (data.word_target) lines.push(`目标字数：${data.word_target} 字`)
  return lines.join('\n')
}

/* ---------- 标题师 ---------- */
async function onGenTitles() {
  titling.value = true
  titleCandidates.value = []
  try {
    const r = await genTitles({
      novel_id: novelId,
      content: mode.value === 'edit' ? current.content : output.value,
      outline: writeForm.outline,
      chapter_no: mode.value === 'edit' ? currentChapterNo.value : nextChapterNo.value,
    })
    titleCandidates.value = r.titles || []
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    titling.value = false
  }
}

function pickTitle(t) {
  if (mode.value === 'edit') current.title = t
  else saveTitle.value = t
  titleCandidates.value = []
}

async function onPlan() {
  planning.value = true
  planError.value = ''
  try {
    const data = await genOutline(novelId, nextChapterNo.value)
    plannerRaw.value = data
    writeForm.outline = outlineToText(data)
    if (data.chapter_title) saveTitle.value = data.chapter_title
  } catch (e) {
    planError.value = e.message
  } finally {
    planning.value = false
  }
}

async function onWriteVariants() {
  if (variantsWriting.value || !writeForm.outline.trim()) return
  variantsWriting.value = true
  variantsError.value = ''
  variants.value = []
  msg.value = ''
  try {
    const r = await generateVariants({
      novel_id: novelId,
      outline: writeForm.outline,
      previous_text: writeForm.previous_text,
      max_tokens: 4096,
    })
    variants.value = r.variants || []
    stats.value = r
  } catch (e) {
    variantsError.value = e.message
  } finally {
    variantsWriting.value = false
  }
}

function importVariant(variant) {
  output.value = variant.content
  msg.value = `已将版本 ${variant.label} 导入主编辑器，其他版本仍保留为素材`
  msgOk.value = true
}

async function copyVariant(variant) {
  try {
    await navigator.clipboard.writeText(variant.content)
    msg.value = `版本 ${variant.label} 已复制，可粘贴到主编辑器合并`
    msgOk.value = true
  } catch {
    msg.value = '复制失败，请手动选择正文后复制'
    msgOk.value = false
  }
}

/* ---------- ② 写手 ---------- */
async function onWrite() {
  if (writing.value) return
  output.value = ''
  writeError.value = ''
  stats.value = null
  msg.value = ''
  writing.value = true
  abortCtrl = new AbortController()
  try {
    const done = await streamWrite(
      {
        novel_id: novelId,
        outline: writeForm.outline,
        previous_text: writeForm.previous_text,
        max_tokens: 4096,
      },
      {
        onDelta: (t) => (output.value += t),
        onError: (m) => (writeError.value = m),
        signal: abortCtrl.signal,
      },
    )
    stats.value = done
  } catch (e) {
    if (e.name !== 'AbortError') writeError.value = e.message
  } finally {
    writing.value = false
  }
}

function onStop() {
  abortCtrl && abortCtrl.abort()
}

async function onSaveAsChapter() {
  if (!output.value.trim()) {
    msg.value = '还没有生成内容'
    msgOk.value = false
    return
  }
  try {
    const ch = await saveChapter({
      novel_id: novelId,
      title: saveTitle.value || `第${nextChapterNo.value}章`,
      content: output.value,
      detailed_outline: writeForm.outline,
    })
    writeForm.previous_text = '' // 下一章自动取本章结尾衔接
    msg.value = `已保存：${ch.title}（${ch.word_count} 字）`
    msgOk.value = true
    await load()
    openChapter(ch)
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  }
}

async function onSaveEdit() {
  if (!currentId.value) return
  try {
    await updateChapter(currentId.value, {
      title: current.title,
      content: current.content,
      detailed_outline: writeForm.outline,
    })
    msg.value = '已保存修改'
    msgOk.value = true
    await load()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  }
}

/* ---------- ③ 校对 ---------- */
async function onCheck() {
  if (!currentId.value) return
  checking.value = true
  checkReport.value = null
  try {
    const r = await checkChapter(currentId.value)
    // 默认全选，方便一键修复
    checkReport.value = { ...r, issues: (r.issues || []).map((it) => ({ ...it, selected: true })) }
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    checking.value = false
  }
}

/* ---------- 修稿：按校对意见一键修复 ---------- */
async function onRevise() {
  if (!currentId.value || !selectedIssues.value.length) return
  revising.value = true
  revisePreview.value = ''
  try {
    const r = await reviseChapter(currentId.value, { issues: selectedIssues.value })
    revisePreview.value = r.content
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    revising.value = false
  }
}

function onApplyRevision() {
  current.content = revisePreview.value
  revisePreview.value = ''
  checkReport.value = null // 修订后报告已过期，建议重新校对
  msg.value = '已应用修订，请检查后点「保存修改」'
  msgOk.value = true
}

/* ---------- ④ 定稿（更新记忆） ---------- */
async function onFinalize() {
  if (!currentId.value) return
  finalizing.value = true
  finalizeResult.value = null
  try {
    finalizeResult.value = await finalizeChapter(currentId.value)
    currentStatus.value = '已定稿'
    msg.value = '记忆已更新'
    msgOk.value = true
    await load()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    finalizing.value = false
  }
}

async function onDeleteCurrent() {
  if (!currentId.value) return
  if (!confirm(`确定删除「${current.title}」？`)) return
  try {
    await deleteChapter(currentId.value)
    await load()
    openNew()
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  }
}

/* ---------- 导出 txt ---------- */
const exportShow = ref(false)
const exportSel = ref(new Set())
const exportIncludeOutline = ref(false)
const exporting = ref(false)

function openExport() {
  exportSel.value = new Set(chapters.value.map((c) => c.id)) // 默认全选
  exportIncludeOutline.value = false
  exportShow.value = true
}

function toggleExport(id) {
  if (exportSel.value.has(id)) exportSel.value.delete(id)
  else exportSel.value.add(id)
}

function exportSelectAll() {
  exportSel.value = new Set(chapters.value.map((c) => c.id))
}

function exportClear() {
  exportSel.value = new Set()
}

async function onExport() {
  if (!exportSel.value.size) return
  exporting.value = true
  try {
    const { blob, filename } = await exportChapterTxt(novelId, {
      chapter_ids: [...exportSel.value],
      include_outline: exportIncludeOutline.value,
    })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    a.click()
    URL.revokeObjectURL(url)
    exportShow.value = false
  } catch (e) {
    msg.value = e.message
    msgOk.value = false
  } finally {
    exporting.value = false
  }
}

const __returned__ = { route, router, novelId, detail, loadError, volumes, chapters, nextChapterNo, mode, currentId, currentStatus, current, writeForm, plannerRaw, planning, planError, output, variants, variantsWriting, variantsError, writing, writeError, stats, saveTitle, get abortCtrl() { return abortCtrl }, set abortCtrl(v) { abortCtrl = v }, checkReport, checking, revising, revisePreview, finalizeResult, finalizing, selectedIssues, titleCandidates, titling, currentChapterNo, msg, msgOk, charCount, load, resetTransient, openNew, openChapter, outlineToText, onGenTitles, pickTitle, onPlan, onWriteVariants, importVariant, copyVariant, onWrite, onStop, onSaveAsChapter, onSaveEdit, onCheck, onRevise, onApplyRevision, onFinalize, onDeleteCurrent, exportShow, exportSel, exportIncludeOutline, exporting, openExport, toggleExport, exportSelectAll, exportClear, onExport, computed, onMounted, reactive, ref, get useRoute() { return useRoute }, get useRouter() { return useRouter }, get checkChapter() { return checkChapter }, get deleteChapter() { return deleteChapter }, get exportChapterTxt() { return exportChapterTxt }, get finalizeChapter() { return finalizeChapter }, get generateVariants() { return generateVariants }, get genOutline() { return genOutline }, get genTitles() { return genTitles }, get getNovel() { return getNovel }, get reviseChapter() { return reviseChapter }, get saveChapter() { return saveChapter }, get streamWrite() { return streamWrite }, get updateChapter() { return updateChapter }, get fmtTime() { return fmtTime } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, createElementVNode as _createElementVNode, renderList as _renderList, Fragment as _Fragment, normalizeClass as _normalizeClass, createTextVNode as _createTextVNode, vModelText as _vModelText, withDirectives as _withDirectives, vShow as _vShow, vModelCheckbox as _vModelCheckbox, withModifiers as _withModifiers } from "/node_modules/.vite/deps/vue.js?v=755ab909"

const _hoisted_1 = {
  key: 0,
  class: "msg err"
}
const _hoisted_2 = { class: "novel-head" }
const _hoisted_3 = {
  key: 0,
  class: "tag"
}
const _hoisted_4 = {
  key: 1,
  class: "tag"
}
const _hoisted_5 = { class: "hint" }
const _hoisted_6 = { class: "workbench" }
const _hoisted_7 = { class: "chapter-list card" }
const _hoisted_8 = { class: "volume-title" }
const _hoisted_9 = ["onClick"]
const _hoisted_10 = { class: "ch-label" }
const _hoisted_11 = ["title"]
const _hoisted_12 = { class: "hint" }
const _hoisted_13 = {
  key: 0,
  class: "hint"
}
const _hoisted_14 = { class: "card panel" }
const _hoisted_15 = { class: "hint" }
const _hoisted_16 = { class: "row" }
const _hoisted_17 = ["disabled"]
const _hoisted_18 = {
  key: 0,
  class: "msg err"
}
const _hoisted_19 = {
  key: 1,
  class: "plan-preview"
}
const _hoisted_20 = {
  key: 0,
  class: "hint"
}
const _hoisted_21 = { key: 1 }
const _hoisted_22 = { class: "plan-foot" }
const _hoisted_23 = {
  key: 0,
  class: "tag tag-new"
}
const _hoisted_24 = {
  key: 1,
  class: "tag tag-done"
}
const _hoisted_25 = {
  key: 0,
  class: "plan-hook"
}
const _hoisted_26 = { class: "row" }
const _hoisted_27 = ["disabled"]
const _hoisted_28 = ["disabled"]
const _hoisted_29 = ["disabled"]
const _hoisted_30 = {
  key: 2,
  class: "msg err"
}
const _hoisted_31 = {
  key: 3,
  class: "msg err"
}
const _hoisted_32 = {
  key: 4,
  class: "variants-panel"
}
const _hoisted_33 = { class: "variant-grid" }
const _hoisted_34 = { class: "variant-head" }
const _hoisted_35 = { class: "hint" }
const _hoisted_36 = {
  class: "variant-body",
  tabindex: "0"
}
const _hoisted_37 = { class: "row variant-actions" }
const _hoisted_38 = ["onClick"]
const _hoisted_39 = ["onClick"]
const _hoisted_40 = { class: "output" }
const _hoisted_41 = { class: "output-head" }
const _hoisted_42 = {
  key: 0,
  class: "hint"
}
const _hoisted_43 = ["placeholder"]
const _hoisted_44 = { class: "row save-row" }
const _hoisted_45 = ["disabled"]
const _hoisted_46 = ["disabled"]
const _hoisted_47 = {
  key: 0,
  class: "title-cands"
}
const _hoisted_48 = ["onClick"]
const _hoisted_49 = {
  key: 2,
  class: "msg ok"
}
const _hoisted_50 = {
  class: "row",
  style: {"margin-top":"4px"}
}
const _hoisted_51 = ["disabled"]
const _hoisted_52 = {
  key: 0,
  class: "title-cands"
}
const _hoisted_53 = ["onClick"]
const _hoisted_54 = { class: "row" }
const _hoisted_55 = ["disabled"]
const _hoisted_56 = ["disabled"]
const _hoisted_57 = {
  key: 2,
  class: "check-report"
}
const _hoisted_58 = { class: "output-head" }
const _hoisted_59 = { class: "issue-check" }
const _hoisted_60 = ["onUpdate:modelValue"]
const _hoisted_61 = { class: "hint" }
const _hoisted_62 = {
  key: 0,
  class: "hint"
}
const _hoisted_63 = {
  key: 0,
  class: "msg ok"
}
const _hoisted_64 = {
  key: 1,
  class: "row"
}
const _hoisted_65 = ["disabled"]
const _hoisted_66 = {
  key: 3,
  class: "revise-preview"
}
const _hoisted_67 = { class: "output-body" }
const _hoisted_68 = { class: "row" }
const _hoisted_69 = {
  key: 4,
  class: "finalize-result"
}
const _hoisted_70 = { class: "msg ok" }
const _hoisted_71 = { class: "hint" }
const _hoisted_72 = { class: "modal modal-lg" }
const _hoisted_73 = { class: "export-list" }
const _hoisted_74 = { class: "volume-title" }
const _hoisted_75 = ["checked", "onChange"]
const _hoisted_76 = { class: "hint" }
const _hoisted_77 = {
  key: 0,
  class: "hint"
}
const _hoisted_78 = { class: "export-opt" }
const _hoisted_79 = { class: "row" }
const _hoisted_80 = ["disabled"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", null, [
    ($setup.loadError)
      ? (_openBlock(), _createElementBlock("div", _hoisted_1, _toDisplayString($setup.loadError), 1 /* TEXT */))
      : ($setup.detail)
        ? (_openBlock(), _createElementBlock(_Fragment, { key: 1 }, [
            _createElementVNode("div", _hoisted_2, [
              _createElementVNode("button", {
                class: "link",
                onClick: _cache[0] || (_cache[0] = $event => ($setup.router.push('/')))
              }, "← 返回书架"),
              _createElementVNode("h2", null, _toDisplayString($setup.detail.novel.title), 1 /* TEXT */),
              ($setup.detail.novel.genre)
                ? (_openBlock(), _createElementBlock("span", _hoisted_3, _toDisplayString($setup.detail.novel.genre), 1 /* TEXT */))
                : _createCommentVNode("v-if", true),
              ($setup.detail.novel.style)
                ? (_openBlock(), _createElementBlock("span", _hoisted_4, _toDisplayString($setup.detail.novel.style), 1 /* TEXT */))
                : _createCommentVNode("v-if", true),
              _createElementVNode("span", _hoisted_5, _toDisplayString($setup.chapters.length) + " 章 · 更新于 " + _toDisplayString($setup.fmtTime($setup.detail.novel.updated_at)), 1 /* TEXT */),
              _cache[13] || (_cache[13] = _createElementVNode("div", { class: "spacer" }, null, -1 /* CACHED */)),
              _createElementVNode("button", { onClick: $setup.openExport }, "⬇ 导出 txt"),
              _createElementVNode("button", {
                class: "link",
                onClick: _cache[1] || (_cache[1] = $event => ($setup.router.push(`/novel/${$setup.novelId}/settings`)))
              }, "🧠 设定 / 记忆"),
              _createElementVNode("button", {
                class: "primary",
                onClick: $setup.openNew
              }, "＋ 写新章节")
            ]),
            _createElementVNode("div", _hoisted_6, [
              _createCommentVNode(" 左：章节列表 "),
              _createElementVNode("aside", _hoisted_7, [
                (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.volumes, (v) => {
                  return (_openBlock(), _createElementBlock("div", {
                    key: v.id
                  }, [
                    _createElementVNode("h3", _hoisted_8, _toDisplayString(v.title), 1 /* TEXT */),
                    (_openBlock(true), _createElementBlock(_Fragment, null, _renderList(v.chapters, (ch) => {
                      return (_openBlock(), _createElementBlock("div", {
                        key: ch.id,
                        class: _normalizeClass(["chapter-item", { active: $setup.mode === 'edit' && $setup.currentId === ch.id }]),
                        onClick: $event => ($setup.openChapter(ch))
                      }, [
                        _createElementVNode("span", _hoisted_10, [
                          _createElementVNode("span", {
                            class: _normalizeClass(["dot", ch.status === '已定稿' ? 'b-green' : 'b-gray']),
                            title: ch.status
                          }, null, 10 /* CLASS, PROPS */, _hoisted_11),
                          _createTextVNode(" 第" + _toDisplayString(ch.chapter_no) + "章 " + _toDisplayString(ch.title), 1 /* TEXT */)
                        ]),
                        _createElementVNode("span", _hoisted_12, _toDisplayString(ch.word_count) + " 字", 1 /* TEXT */)
                      ], 10 /* CLASS, PROPS */, _hoisted_9))
                    }), 128 /* KEYED_FRAGMENT */))
                  ]))
                }), 128 /* KEYED_FRAGMENT */)),
                (!$setup.chapters.length)
                  ? (_openBlock(), _createElementBlock("p", _hoisted_13, " 还没有章节。建议流程：✨ 生成细纲 → 开始写作 → 保存 → 校对 → 定稿（更新记忆） "))
                  : _createCommentVNode("v-if", true)
              ]),
              _createCommentVNode(" 右：写作 / 编辑面板 "),
              _createElementVNode("section", _hoisted_14, [
                _createCommentVNode(" ============ 写新章节 ============ "),
                ($setup.mode === 'new')
                  ? (_openBlock(), _createElementBlock(_Fragment, { key: 0 }, [
                      _createElementVNode("h2", null, [
                        _cache[14] || (_cache[14] = _createTextVNode("写新章节 ", -1 /* CACHED */)),
                        _createElementVNode("span", _hoisted_15, "第 " + _toDisplayString($setup.nextChapterNo) + " 章（章号自动）", 1 /* TEXT */)
                      ]),
                      _createElementVNode("div", _hoisted_16, [
                        _createElementVNode("button", {
                          class: "primary",
                          disabled: $setup.planning || $setup.writing,
                          onClick: $setup.onPlan
                        }, _toDisplayString($setup.planning ? '生成细纲中…' : '✨ AI 生成细纲（细纲师）'), 9 /* TEXT, PROPS */, _hoisted_17)
                      ]),
                      ($setup.planError)
                        ? (_openBlock(), _createElementBlock("p", _hoisted_18, _toDisplayString($setup.planError), 1 /* TEXT */))
                        : _createCommentVNode("v-if", true),
                      ($setup.plannerRaw)
                        ? (_openBlock(), _createElementBlock("div", _hoisted_19, [
                            _createElementVNode("h3", null, _toDisplayString($setup.plannerRaw.chapter_title || `第${$setup.nextChapterNo}章`), 1 /* TEXT */),
                            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.plannerRaw.scenes, (s) => {
                              return (_openBlock(), _createElementBlock("div", {
                                key: s.scene_no,
                                class: "plan-scene"
                              }, [
                                _createElementVNode("b", null, "场景 " + _toDisplayString(s.scene_no), 1 /* TEXT */),
                                _createTextVNode(" ｜" + _toDisplayString(s.location || '地点未定') + "｜" + _toDisplayString((s.participants || []).join('、') || '出场未定') + " ", 1 /* TEXT */),
                                (s.goal)
                                  ? (_openBlock(), _createElementBlock("div", _hoisted_20, "剧情作用：" + _toDisplayString(s.goal), 1 /* TEXT */))
                                  : _createCommentVNode("v-if", true),
                                (s.events)
                                  ? (_openBlock(), _createElementBlock("div", _hoisted_21, _toDisplayString(s.events), 1 /* TEXT */))
                                  : _createCommentVNode("v-if", true)
                              ]))
                            }), 128 /* KEYED_FRAGMENT */)),
                            _createElementVNode("div", _hoisted_22, [
                              ($setup.plannerRaw.foreshadowings_planted?.length)
                                ? (_openBlock(), _createElementBlock("span", _hoisted_23, " 埋设：" + _toDisplayString($setup.plannerRaw.foreshadowings_planted.map((f) => f.title).join('、')), 1 /* TEXT */))
                                : _createCommentVNode("v-if", true),
                              ($setup.plannerRaw.foreshadowings_resolved?.length)
                                ? (_openBlock(), _createElementBlock("span", _hoisted_24, " 回收：" + _toDisplayString($setup.plannerRaw.foreshadowings_resolved.join('、')), 1 /* TEXT */))
                                : _createCommentVNode("v-if", true)
                            ]),
                            ($setup.plannerRaw.hook)
                              ? (_openBlock(), _createElementBlock("div", _hoisted_25, "🪝 " + _toDisplayString($setup.plannerRaw.hook), 1 /* TEXT */))
                              : _createCommentVNode("v-if", true)
                          ]))
                        : _createCommentVNode("v-if", true),
                      _cache[17] || (_cache[17] = _createElementVNode("label", null, "细纲（可编辑，已同步为上文生成结果）", -1 /* CACHED */)),
                      _withDirectives(_createElementVNode("textarea", {
                        "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.writeForm.outline) = $event)),
                        rows: "5",
                        placeholder: "留空则 AI 自行安排；建议先点「✨ AI 生成细纲」"
                      }, null, 512 /* NEED_PATCH */), [
                        [_vModelText, $setup.writeForm.outline]
                      ]),
                      _cache[18] || (_cache[18] = _createElementVNode("label", null, [
                        _createTextVNode("前文衔接 "),
                        _createElementVNode("span", { class: "hint" }, "留空自动取上一章结尾 800 字")
                      ], -1 /* CACHED */)),
                      _withDirectives(_createElementVNode("textarea", {
                        "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.writeForm.previous_text) = $event)),
                        rows: "2",
                        placeholder: "也可手动粘贴特定片段"
                      }, null, 512 /* NEED_PATCH */), [
                        [_vModelText, $setup.writeForm.previous_text]
                      ]),
                      _createElementVNode("div", _hoisted_26, [
                        _createElementVNode("button", {
                          class: "primary",
                          disabled: $setup.writing || $setup.planning || $setup.variantsWriting,
                          onClick: $setup.onWrite
                        }, _toDisplayString($setup.writing ? '写作中…' : '开始写作（单版）'), 9 /* TEXT, PROPS */, _hoisted_27),
                        _createElementVNode("button", {
                          disabled: $setup.writing || $setup.planning || $setup.variantsWriting || !$setup.writeForm.outline.trim(),
                          onClick: $setup.onWriteVariants
                        }, _toDisplayString($setup.variantsWriting ? '生成 A/B/C 中…' : '生成 A/B/C 三版'), 9 /* TEXT, PROPS */, _hoisted_28),
                        _createElementVNode("button", {
                          disabled: !$setup.writing,
                          onClick: $setup.onStop
                        }, "停止", 8 /* PROPS */, _hoisted_29)
                      ]),
                      ($setup.writeError)
                        ? (_openBlock(), _createElementBlock("p", _hoisted_30, _toDisplayString($setup.writeError), 1 /* TEXT */))
                        : _createCommentVNode("v-if", true),
                      ($setup.variantsError)
                        ? (_openBlock(), _createElementBlock("p", _hoisted_31, _toDisplayString($setup.variantsError), 1 /* TEXT */))
                        : _createCommentVNode("v-if", true),
                      ($setup.variants.length)
                        ? (_openBlock(), _createElementBlock("div", _hoisted_32, [
                            _cache[15] || (_cache[15] = _createElementVNode("div", { class: "output-head" }, [
                              _createElementVNode("span", null, "三版正文素材"),
                              _createElementVNode("span", { class: "hint" }, "选择一版导入主编辑器，其他版本不会删除")
                            ], -1 /* CACHED */)),
                            _createElementVNode("div", _hoisted_33, [
                              (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.variants, (variant) => {
                                return (_openBlock(), _createElementBlock("article", {
                                  key: variant.label,
                                  class: "variant-card"
                                }, [
                                  _createElementVNode("div", _hoisted_34, [
                                    _createElementVNode("strong", null, "版本 " + _toDisplayString(variant.label), 1 /* TEXT */),
                                    _createElementVNode("span", _hoisted_35, _toDisplayString(variant.word_count) + " 字", 1 /* TEXT */)
                                  ]),
                                  _createElementVNode("pre", _hoisted_36, _toDisplayString(variant.content), 1 /* TEXT */),
                                  _createElementVNode("div", _hoisted_37, [
                                    _createElementVNode("button", {
                                      class: "primary",
                                      onClick: $event => ($setup.importVariant(variant))
                                    }, "导入主编辑器", 8 /* PROPS */, _hoisted_38),
                                    _createElementVNode("button", {
                                      onClick: $event => ($setup.copyVariant(variant))
                                    }, "复制全文", 8 /* PROPS */, _hoisted_39)
                                  ])
                                ]))
                              }), 128 /* KEYED_FRAGMENT */))
                            ])
                          ]))
                        : _createCommentVNode("v-if", true),
                      _withDirectives(_createElementVNode("div", _hoisted_40, [
                        _createElementVNode("div", _hoisted_41, [
                          _createElementVNode("span", null, _toDisplayString($setup.writing ? '正在生成…' : `主编辑器 · ${$setup.charCount} 字`), 1 /* TEXT */),
                          ($setup.variants.length)
                            ? (_openBlock(), _createElementBlock("span", _hoisted_42, "可粘贴素材面板片段进行合并"))
                            : _createCommentVNode("v-if", true)
                        ]),
                        _withDirectives(_createElementVNode("textarea", {
                          "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => (($setup.output) = $event)),
                          rows: "14",
                          class: "editor",
                          placeholder: $setup.writing ? '正文生成中…' : '选择版本导入，或直接编辑主稿'
                        }, null, 8 /* PROPS */, _hoisted_43), [
                          [_vModelText, $setup.output]
                        ]),
                        _createElementVNode("div", _hoisted_44, [
                          _withDirectives(_createElementVNode("input", {
                            "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => (($setup.saveTitle) = $event)),
                            class: "grow",
                            placeholder: "章节标题"
                          }, null, 512 /* NEED_PATCH */), [
                            [_vModelText, $setup.saveTitle]
                          ]),
                          _createElementVNode("button", {
                            disabled: $setup.titling,
                            title: 'AI 起标题',
                            onClick: $setup.onGenTitles
                          }, "✨", 8 /* PROPS */, _hoisted_45),
                          _createElementVNode("button", {
                            class: "primary",
                            disabled: !$setup.output || $setup.writing || $setup.variantsWriting,
                            onClick: $setup.onSaveAsChapter
                          }, "保存为章节", 8 /* PROPS */, _hoisted_46)
                        ]),
                        ($setup.titleCandidates.length)
                          ? (_openBlock(), _createElementBlock("div", _hoisted_47, [
                              _cache[16] || (_cache[16] = _createElementVNode("span", { class: "hint" }, "候选标题（点击选用）：", -1 /* CACHED */)),
                              (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.titleCandidates, (t, i) => {
                                return (_openBlock(), _createElementBlock("button", {
                                  key: i,
                                  class: "cand",
                                  onClick: $event => ($setup.pickTitle(t))
                                }, _toDisplayString(t), 9 /* TEXT, PROPS */, _hoisted_48))
                              }), 128 /* KEYED_FRAGMENT */))
                            ]))
                          : _createCommentVNode("v-if", true),
                        ($setup.msg)
                          ? (_openBlock(), _createElementBlock("p", {
                              key: 1,
                              class: _normalizeClass(["msg", $setup.msgOk ? 'ok' : 'err'])
                            }, _toDisplayString($setup.msg), 3 /* TEXT, CLASS */))
                          : _createCommentVNode("v-if", true),
                        ($setup.stats && !$setup.msg)
                          ? (_openBlock(), _createElementBlock("p", _hoisted_49, "生成完成：耗时 " + _toDisplayString(($setup.stats.duration_ms / 1000).toFixed(1)) + " s", 1 /* TEXT */))
                          : _createCommentVNode("v-if", true)
                      ], 512 /* NEED_PATCH */), [
                        [_vShow, $setup.output || $setup.writing]
                      ])
                    ], 64 /* STABLE_FRAGMENT */))
                  : (_openBlock(), _createElementBlock(_Fragment, { key: 1 }, [
                      _createCommentVNode(" ============ 编辑已有章节 ============ "),
                      _createElementVNode("h2", null, [
                        _cache[19] || (_cache[19] = _createTextVNode(" 编辑章节 ", -1 /* CACHED */)),
                        _createElementVNode("span", {
                          class: _normalizeClass(["badge", $setup.currentStatus === '已定稿' ? 'b-green' : 'b-gray'])
                        }, _toDisplayString($setup.currentStatus || '草稿'), 3 /* TEXT, CLASS */)
                      ]),
                      _cache[24] || (_cache[24] = _createElementVNode("label", null, "标题", -1 /* CACHED */)),
                      _createElementVNode("div", _hoisted_50, [
                        _withDirectives(_createElementVNode("input", {
                          "onUpdate:modelValue": _cache[6] || (_cache[6] = $event => (($setup.current.title) = $event)),
                          class: "grow"
                        }, null, 512 /* NEED_PATCH */), [
                          [_vModelText, $setup.current.title]
                        ]),
                        _createElementVNode("button", {
                          disabled: $setup.titling,
                          onClick: $setup.onGenTitles
                        }, _toDisplayString($setup.titling ? '起名中…' : '✨ AI 起标题'), 9 /* TEXT, PROPS */, _hoisted_51)
                      ]),
                      ($setup.titleCandidates.length)
                        ? (_openBlock(), _createElementBlock("div", _hoisted_52, [
                            _cache[20] || (_cache[20] = _createElementVNode("span", { class: "hint" }, "候选标题（点击选用）：", -1 /* CACHED */)),
                            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.titleCandidates, (t, i) => {
                              return (_openBlock(), _createElementBlock("button", {
                                key: i,
                                class: "cand",
                                onClick: $event => ($setup.pickTitle(t))
                              }, _toDisplayString(t), 9 /* TEXT, PROPS */, _hoisted_53))
                            }), 128 /* KEYED_FRAGMENT */))
                          ]))
                        : _createCommentVNode("v-if", true),
                      _cache[25] || (_cache[25] = _createElementVNode("label", null, "正文（可直接修改）", -1 /* CACHED */)),
                      _withDirectives(_createElementVNode("textarea", {
                        "onUpdate:modelValue": _cache[7] || (_cache[7] = $event => (($setup.current.content) = $event)),
                        rows: "14",
                        class: "editor"
                      }, null, 512 /* NEED_PATCH */), [
                        [_vModelText, $setup.current.content]
                      ]),
                      _cache[26] || (_cache[26] = _createElementVNode("label", null, "细纲", -1 /* CACHED */)),
                      _withDirectives(_createElementVNode("textarea", {
                        "onUpdate:modelValue": _cache[8] || (_cache[8] = $event => (($setup.writeForm.outline) = $event)),
                        rows: "3",
                        placeholder: "本章细纲，供校对与 AI 重写参考"
                      }, null, 512 /* NEED_PATCH */), [
                        [_vModelText, $setup.writeForm.outline]
                      ]),
                      _createElementVNode("div", _hoisted_54, [
                        _createElementVNode("button", {
                          class: "primary",
                          onClick: $setup.onSaveEdit
                        }, "保存修改"),
                        _createElementVNode("button", { onClick: $setup.openNew }, "写新章节"),
                        _createElementVNode("button", {
                          class: "danger",
                          onClick: $setup.onDeleteCurrent
                        }, "删除本章"),
                        _cache[21] || (_cache[21] = _createElementVNode("div", { class: "spacer" }, null, -1 /* CACHED */)),
                        _createElementVNode("button", {
                          disabled: $setup.checking,
                          onClick: $setup.onCheck
                        }, _toDisplayString($setup.checking ? '校对中…' : '🔍 校对'), 9 /* TEXT, PROPS */, _hoisted_55),
                        _createElementVNode("button", {
                          class: "primary",
                          disabled: $setup.finalizing,
                          onClick: $setup.onFinalize
                        }, _toDisplayString($setup.finalizing ? '更新记忆中…' : '📝 定稿（更新记忆）'), 9 /* TEXT, PROPS */, _hoisted_56)
                      ]),
                      ($setup.msg)
                        ? (_openBlock(), _createElementBlock("p", {
                            key: 1,
                            class: _normalizeClass(["msg", $setup.msgOk ? 'ok' : 'err'])
                          }, _toDisplayString($setup.msg), 3 /* TEXT, CLASS */))
                        : _createCommentVNode("v-if", true),
                      _createCommentVNode(" 校对报告 "),
                      ($setup.checkReport)
                        ? (_openBlock(), _createElementBlock("div", _hoisted_57, [
                            _createElementVNode("div", _hoisted_58, [
                              _cache[22] || (_cache[22] = _createElementVNode("span", null, "校对报告", -1 /* CACHED */)),
                              _createElementVNode("span", {
                                class: _normalizeClass(["badge", $setup.checkReport.verdict === 'pass' ? 'b-green' : 'b-high'])
                              }, _toDisplayString($setup.checkReport.verdict === 'pass' ? '✓ 通过' : '需修改'), 3 /* TEXT, CLASS */)
                            ]),
                            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.checkReport.issues, (it, i) => {
                              return (_openBlock(), _createElementBlock("div", {
                                key: i,
                                class: _normalizeClass(["issue", it.severity])
                              }, [
                                _createElementVNode("label", _hoisted_59, [
                                  _withDirectives(_createElementVNode("input", {
                                    type: "checkbox",
                                    "onUpdate:modelValue": $event => ((it.selected) = $event)
                                  }, null, 8 /* PROPS */, _hoisted_60), [
                                    [_vModelCheckbox, it.selected]
                                  ]),
                                  _createElementVNode("span", {
                                    class: _normalizeClass(["badge", `b-${it.severity}`])
                                  }, _toDisplayString(it.severity), 3 /* TEXT, CLASS */),
                                  _createElementVNode("b", null, _toDisplayString(it.type), 1 /* TEXT */),
                                  _createElementVNode("span", _hoisted_61, _toDisplayString(it.location), 1 /* TEXT */)
                                ]),
                                _createElementVNode("div", null, _toDisplayString(it.description), 1 /* TEXT */),
                                (it.suggestion)
                                  ? (_openBlock(), _createElementBlock("div", _hoisted_62, "建议：" + _toDisplayString(it.suggestion), 1 /* TEXT */))
                                  : _createCommentVNode("v-if", true)
                              ], 2 /* CLASS */))
                            }), 128 /* KEYED_FRAGMENT */)),
                            (!$setup.checkReport.issues.length)
                              ? (_openBlock(), _createElementBlock("p", _hoisted_63, "未发现问题"))
                              : (_openBlock(), _createElementBlock("div", _hoisted_64, [
                                  _createElementVNode("button", {
                                    class: "primary",
                                    disabled: $setup.revising || !$setup.selectedIssues.length,
                                    onClick: $setup.onRevise
                                  }, _toDisplayString($setup.revising ? 'AI 修稿中…' : `🛠 AI 修复所选问题（${$setup.selectedIssues.length}）`), 9 /* TEXT, PROPS */, _hoisted_65)
                                ]))
                          ]))
                        : _createCommentVNode("v-if", true),
                      _createCommentVNode(" 修订稿预览 "),
                      ($setup.revisePreview)
                        ? (_openBlock(), _createElementBlock("div", _hoisted_66, [
                            _cache[23] || (_cache[23] = _createElementVNode("div", { class: "output-head" }, [
                              _createElementVNode("span", null, "修订稿预览（只改问题相关处，其余原样保留）")
                            ], -1 /* CACHED */)),
                            _createElementVNode("pre", _hoisted_67, _toDisplayString($setup.revisePreview), 1 /* TEXT */),
                            _createElementVNode("div", _hoisted_68, [
                              _createElementVNode("button", {
                                class: "primary",
                                onClick: $setup.onApplyRevision
                              }, "应用修订"),
                              _createElementVNode("button", {
                                onClick: _cache[9] || (_cache[9] = $event => ($setup.revisePreview = ''))
                              }, "放弃")
                            ])
                          ]))
                        : _createCommentVNode("v-if", true),
                      _createCommentVNode(" 定稿结果 "),
                      ($setup.finalizeResult)
                        ? (_openBlock(), _createElementBlock("div", _hoisted_69, [
                            _createElementVNode("p", _hoisted_70, " 记忆已更新：角色状态 " + _toDisplayString($setup.finalizeResult.characters_updated) + " 处 · 新埋伏笔 " + _toDisplayString($setup.finalizeResult.foreshadowings_planted) + " 条 · 回收伏笔 " + _toDisplayString($setup.finalizeResult.foreshadowings_resolved) + " 条 ", 1 /* TEXT */),
                            _createElementVNode("div", _hoisted_71, "章摘要：" + _toDisplayString($setup.finalizeResult.summary), 1 /* TEXT */)
                          ]))
                        : _createCommentVNode("v-if", true)
                    ], 64 /* STABLE_FRAGMENT */))
              ])
            ]),
            _createCommentVNode(" 导出弹窗 "),
            ($setup.exportShow)
              ? (_openBlock(), _createElementBlock("div", {
                  key: 0,
                  class: "overlay",
                  onClick: _cache[12] || (_cache[12] = _withModifiers($event => ($setup.exportShow = false), ["self"]))
                }, [
                  _createElementVNode("div", _hoisted_72, [
                    _cache[28] || (_cache[28] = _createElementVNode("h3", null, "导出为 txt", -1 /* CACHED */)),
                    _cache[29] || (_cache[29] = _createElementVNode("p", { class: "hint" }, "勾选要导出的章节；文件含书名、卷名与章标题，适配阅读器与 AI 改编工具", -1 /* CACHED */)),
                    _createElementVNode("div", {
                      class: "row",
                      style: {"margin-top":"8px"}
                    }, [
                      _createElementVNode("button", { onClick: $setup.exportSelectAll }, "全选"),
                      _createElementVNode("button", { onClick: $setup.exportClear }, "清空")
                    ]),
                    _createElementVNode("div", _hoisted_73, [
                      (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.volumes, (v) => {
                        return (_openBlock(), _createElementBlock(_Fragment, {
                          key: v.id
                        }, [
                          _createElementVNode("div", _hoisted_74, _toDisplayString(v.title), 1 /* TEXT */),
                          (_openBlock(true), _createElementBlock(_Fragment, null, _renderList(v.chapters, (ch) => {
                            return (_openBlock(), _createElementBlock("label", {
                              key: ch.id,
                              class: "export-item"
                            }, [
                              _createElementVNode("input", {
                                type: "checkbox",
                                checked: $setup.exportSel.has(ch.id),
                                onChange: $event => ($setup.toggleExport(ch.id))
                              }, null, 40 /* PROPS, NEED_HYDRATION */, _hoisted_75),
                              _createElementVNode("span", null, "第" + _toDisplayString(ch.chapter_no) + "章 " + _toDisplayString(ch.title), 1 /* TEXT */),
                              _createElementVNode("span", _hoisted_76, _toDisplayString(ch.word_count) + " 字", 1 /* TEXT */)
                            ]))
                          }), 128 /* KEYED_FRAGMENT */))
                        ], 64 /* STABLE_FRAGMENT */))
                      }), 128 /* KEYED_FRAGMENT */)),
                      (!$setup.chapters.length)
                        ? (_openBlock(), _createElementBlock("p", _hoisted_77, "还没有章节可导出"))
                        : _createCommentVNode("v-if", true)
                    ]),
                    _createElementVNode("label", _hoisted_78, [
                      _withDirectives(_createElementVNode("input", {
                        type: "checkbox",
                        "onUpdate:modelValue": _cache[10] || (_cache[10] = $event => (($setup.exportIncludeOutline) = $event))
                      }, null, 512 /* NEED_PATCH */), [
                        [_vModelCheckbox, $setup.exportIncludeOutline]
                      ]),
                      _cache[27] || (_cache[27] = _createTextVNode(" 包含每章细纲（场景/人物/事件，方便 AI 漫剧分镜参考） ", -1 /* CACHED */))
                    ]),
                    _createElementVNode("div", _hoisted_79, [
                      _createElementVNode("button", {
                        class: "primary",
                        disabled: !$setup.exportSel.size || $setup.exporting,
                        onClick: $setup.onExport
                      }, _toDisplayString($setup.exporting ? '导出中…' : `下载 txt（已选 ${$setup.exportSel.size} 章）`), 9 /* TEXT, PROPS */, _hoisted_80),
                      _createElementVNode("button", {
                        onClick: _cache[11] || (_cache[11] = $event => ($setup.exportShow = false))
                      }, "取消")
                    ])
                  ])
                ]))
              : _createCommentVNode("v-if", true)
          ], 64 /* STABLE_FRAGMENT */))
        : _createCommentVNode("v-if", true)
  ]))
}



_sfc_main.__hmrId = "e451f46d"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/86184/Desktop/novel_web/frontend/src/views/NovelView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTm92ZWxWaWV3LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxuaW1wb3J0IHsgY29tcHV0ZWQsIG9uTW91bnRlZCwgcmVhY3RpdmUsIHJlZiB9IGZyb20gJ3Z1ZSdcbmltcG9ydCB7IHVzZVJvdXRlLCB1c2VSb3V0ZXIgfSBmcm9tICd2dWUtcm91dGVyJ1xuaW1wb3J0IHtcbiAgY2hlY2tDaGFwdGVyLFxuICBkZWxldGVDaGFwdGVyLFxuICBleHBvcnRDaGFwdGVyVHh0LFxuICBmaW5hbGl6ZUNoYXB0ZXIsXG4gIGdlbmVyYXRlVmFyaWFudHMsXG4gIGdlbk91dGxpbmUsXG4gIGdlblRpdGxlcyxcbiAgZ2V0Tm92ZWwsXG4gIHJldmlzZUNoYXB0ZXIsXG4gIHNhdmVDaGFwdGVyLFxuICBzdHJlYW1Xcml0ZSxcbiAgdXBkYXRlQ2hhcHRlcixcbn0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgZm10VGltZSB9IGZyb20gJy4uL3V0aWxzJ1xuXG5jb25zdCByb3V0ZSA9IHVzZVJvdXRlKClcbmNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG5jb25zdCBub3ZlbElkID0gTnVtYmVyKHJvdXRlLnBhcmFtcy5pZClcblxuY29uc3QgZGV0YWlsID0gcmVmKG51bGwpIC8vIHsgbm92ZWwsIHZvbHVtZXMgfVxuY29uc3QgbG9hZEVycm9yID0gcmVmKCcnKVxuXG5jb25zdCB2b2x1bWVzID0gY29tcHV0ZWQoKCkgPT4gZGV0YWlsLnZhbHVlPy52b2x1bWVzIHx8IFtdKVxuY29uc3QgY2hhcHRlcnMgPSBjb21wdXRlZCgoKSA9PiB2b2x1bWVzLnZhbHVlLmZsYXRNYXAoKHYpID0+IHYuY2hhcHRlcnMpKVxuY29uc3QgbmV4dENoYXB0ZXJObyA9IGNvbXB1dGVkKCgpID0+IGNoYXB0ZXJzLnZhbHVlLnJlZHVjZSgobSwgYykgPT4gTWF0aC5tYXgobSwgYy5jaGFwdGVyX25vKSwgMCkgKyAxKVxuXG4vKiDpnaLmnb/nirbmgIHvvJpuZXcgPSDlhpnmlrDnq6DoioLvvIxlZGl0ID0g57yW6L6R5bey5pyJ56ug6IqCICovXG5jb25zdCBtb2RlID0gcmVmKCduZXcnKVxuY29uc3QgY3VycmVudElkID0gcmVmKG51bGwpXG5jb25zdCBjdXJyZW50U3RhdHVzID0gcmVmKCcnKVxuY29uc3QgY3VycmVudCA9IHJlYWN0aXZlKHsgdGl0bGU6ICcnLCBjb250ZW50OiAnJyB9KVxuY29uc3Qgd3JpdGVGb3JtID0gcmVhY3RpdmUoeyBvdXRsaW5lOiAnJywgcHJldmlvdXNfdGV4dDogJycgfSlcblxuLyog4pGgIOe7hue6suW4iCAqL1xuY29uc3QgcGxhbm5lclJhdyA9IHJlZihudWxsKVxuY29uc3QgcGxhbm5pbmcgPSByZWYoZmFsc2UpXG5jb25zdCBwbGFuRXJyb3IgPSByZWYoJycpXG5cbi8qIOKRoSDlhpnmiYvvvIjmtYHlvI/vvIkgKi9cbmNvbnN0IG91dHB1dCA9IHJlZignJylcbmNvbnN0IHZhcmlhbnRzID0gcmVmKFtdKVxuY29uc3QgdmFyaWFudHNXcml0aW5nID0gcmVmKGZhbHNlKVxuY29uc3QgdmFyaWFudHNFcnJvciA9IHJlZignJylcbmNvbnN0IHdyaXRpbmcgPSByZWYoZmFsc2UpXG5jb25zdCB3cml0ZUVycm9yID0gcmVmKCcnKVxuY29uc3Qgc3RhdHMgPSByZWYobnVsbClcbmNvbnN0IHNhdmVUaXRsZSA9IHJlZignJylcbmxldCBhYm9ydEN0cmwgPSBudWxsXG5cbi8qIOKRoiDmoKHlr7kgLyDkv67nqL8gLyDikaMg5oC757uTICovXG5jb25zdCBjaGVja1JlcG9ydCA9IHJlZihudWxsKVxuY29uc3QgY2hlY2tpbmcgPSByZWYoZmFsc2UpXG5jb25zdCByZXZpc2luZyA9IHJlZihmYWxzZSlcbmNvbnN0IHJldmlzZVByZXZpZXcgPSByZWYoJycpXG5jb25zdCBmaW5hbGl6ZVJlc3VsdCA9IHJlZihudWxsKVxuY29uc3QgZmluYWxpemluZyA9IHJlZihmYWxzZSlcblxuY29uc3Qgc2VsZWN0ZWRJc3N1ZXMgPSBjb21wdXRlZCgoKSA9PiAoY2hlY2tSZXBvcnQudmFsdWU/Lmlzc3VlcyB8fCBbXSkuZmlsdGVyKChpdCkgPT4gaXQuc2VsZWN0ZWQpKVxuXG4vKiDmoIfpopjluIggKi9cbmNvbnN0IHRpdGxlQ2FuZGlkYXRlcyA9IHJlZihbXSlcbmNvbnN0IHRpdGxpbmcgPSByZWYoZmFsc2UpXG5jb25zdCBjdXJyZW50Q2hhcHRlck5vID0gcmVmKDApXG5cbmNvbnN0IG1zZyA9IHJlZignJylcbmNvbnN0IG1zZ09rID0gcmVmKHRydWUpXG5jb25zdCBjaGFyQ291bnQgPSBjb21wdXRlZCgoKSA9PiBvdXRwdXQudmFsdWUucmVwbGFjZSgvXFxzL2csICcnKS5sZW5ndGgpXG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWQoKSB7XG4gIGxvYWRFcnJvci52YWx1ZSA9ICcnXG4gIHRyeSB7XG4gICAgZGV0YWlsLnZhbHVlID0gYXdhaXQgZ2V0Tm92ZWwobm92ZWxJZClcbiAgICBvcGVuTmV3KClcbiAgfSBjYXRjaCAoZSkge1xuICAgIGxvYWRFcnJvci52YWx1ZSA9IGUubWVzc2FnZVxuICB9XG59XG5vbk1vdW50ZWQobG9hZClcblxuZnVuY3Rpb24gcmVzZXRUcmFuc2llbnQoKSB7XG4gIHBsYW5uZXJSYXcudmFsdWUgPSBudWxsXG4gIHBsYW5FcnJvci52YWx1ZSA9ICcnXG4gIG91dHB1dC52YWx1ZSA9ICcnXG4gIHZhcmlhbnRzLnZhbHVlID0gW11cbiAgdmFyaWFudHNFcnJvci52YWx1ZSA9ICcnXG4gIHN0YXRzLnZhbHVlID0gbnVsbFxuICB3cml0ZUVycm9yLnZhbHVlID0gJydcbiAgY2hlY2tSZXBvcnQudmFsdWUgPSBudWxsXG4gIHJldmlzZVByZXZpZXcudmFsdWUgPSAnJ1xuICBmaW5hbGl6ZVJlc3VsdC52YWx1ZSA9IG51bGxcbiAgdGl0bGVDYW5kaWRhdGVzLnZhbHVlID0gW11cbiAgbXNnLnZhbHVlID0gJydcbn1cblxuZnVuY3Rpb24gb3Blbk5ldygpIHtcbiAgbW9kZS52YWx1ZSA9ICduZXcnXG4gIGN1cnJlbnRJZC52YWx1ZSA9IG51bGxcbiAgY3VycmVudFN0YXR1cy52YWx1ZSA9ICcnXG4gIGN1cnJlbnRDaGFwdGVyTm8udmFsdWUgPSAwXG4gIGN1cnJlbnQudGl0bGUgPSAnJ1xuICBjdXJyZW50LmNvbnRlbnQgPSAnJ1xuICByZXNldFRyYW5zaWVudCgpXG4gIHNhdmVUaXRsZS52YWx1ZSA9IGDnrKwke25leHRDaGFwdGVyTm8udmFsdWV956ugYFxufVxuXG5mdW5jdGlvbiBvcGVuQ2hhcHRlcihjaCkge1xuICBtb2RlLnZhbHVlID0gJ2VkaXQnXG4gIGN1cnJlbnRJZC52YWx1ZSA9IGNoLmlkXG4gIGN1cnJlbnRTdGF0dXMudmFsdWUgPSBjaC5zdGF0dXNcbiAgY3VycmVudENoYXB0ZXJOby52YWx1ZSA9IGNoLmNoYXB0ZXJfbm9cbiAgY3VycmVudC50aXRsZSA9IGNoLnRpdGxlXG4gIGN1cnJlbnQuY29udGVudCA9IGNoLmNvbnRlbnRcbiAgcmVzZXRUcmFuc2llbnQoKVxuICB3cml0ZUZvcm0ub3V0bGluZSA9IGNoLmRldGFpbGVkX291dGxpbmUgfHwgJydcbiAgd3JpdGVGb3JtLnByZXZpb3VzX3RleHQgPSAnJ1xufVxuXG4vKiAtLS0tLS0tLS0tIOKRoCDnu4bnurLluIggLS0tLS0tLS0tLSAqL1xuZnVuY3Rpb24gb3V0bGluZVRvVGV4dChkYXRhKSB7XG4gIGNvbnN0IGxpbmVzID0gW11cbiAgaWYgKGRhdGEuY2hhcHRlcl90aXRsZSkgbGluZXMucHVzaChg5qCH6aKY77yaJHtkYXRhLmNoYXB0ZXJfdGl0bGV9YClcbiAgZm9yIChjb25zdCBzIG9mIGRhdGEuc2NlbmVzIHx8IFtdKSB7XG4gICAgbGluZXMucHVzaChcbiAgICAgIGBcXG7lnLrmma8gJHtzLnNjZW5lX25vfe+9nOWcsOeCue+8miR7cy5sb2NhdGlvbiB8fCAn5pyq5a6aJ33vvZzlh7rlnLrvvJokeyhzLnBhcnRpY2lwYW50cyB8fCBbXSkuam9pbign44CBJykgfHwgJ+acquWumid9YCxcbiAgICApXG4gICAgaWYgKHMuZ29hbCkgbGluZXMucHVzaChgICDliafmg4XkvZznlKjvvJoke3MuZ29hbH1gKVxuICAgIGlmIChzLmV2ZW50cykgbGluZXMucHVzaChgICDkuovku7bvvJoke3MuZXZlbnRzfWApXG4gIH1cbiAgaWYgKGRhdGEuZm9yZXNoYWRvd2luZ3NfcGxhbnRlZD8ubGVuZ3RoKVxuICAgIGxpbmVzLnB1c2goJ1xcbuWfi+iuvuS8j+eslO+8micgKyBkYXRhLmZvcmVzaGFkb3dpbmdzX3BsYW50ZWQubWFwKChmKSA9PiBgJHtmLnRpdGxlfe+8iCR7Zi5kZXNjcmlwdGlvbn3vvIlgKS5qb2luKCfvvJsnKSlcbiAgaWYgKGRhdGEuZm9yZXNoYWRvd2luZ3NfcmVzb2x2ZWQ/Lmxlbmd0aCkgbGluZXMucHVzaChg5Zue5pS25LyP56yU77yaJHtkYXRhLmZvcmVzaGFkb3dpbmdzX3Jlc29sdmVkLmpvaW4oJ+OAgScpfWApXG4gIGlmIChkYXRhLmhvb2spIGxpbmVzLnB1c2goYFxcbueroOacq+mSqeWtkO+8miR7ZGF0YS5ob29rfWApXG4gIGlmIChkYXRhLndvcmRfdGFyZ2V0KSBsaW5lcy5wdXNoKGDnm67moIflrZfmlbDvvJoke2RhdGEud29yZF90YXJnZXR9IOWtl2ApXG4gIHJldHVybiBsaW5lcy5qb2luKCdcXG4nKVxufVxuXG4vKiAtLS0tLS0tLS0tIOagh+mimOW4iCAtLS0tLS0tLS0tICovXG5hc3luYyBmdW5jdGlvbiBvbkdlblRpdGxlcygpIHtcbiAgdGl0bGluZy52YWx1ZSA9IHRydWVcbiAgdGl0bGVDYW5kaWRhdGVzLnZhbHVlID0gW11cbiAgdHJ5IHtcbiAgICBjb25zdCByID0gYXdhaXQgZ2VuVGl0bGVzKHtcbiAgICAgIG5vdmVsX2lkOiBub3ZlbElkLFxuICAgICAgY29udGVudDogbW9kZS52YWx1ZSA9PT0gJ2VkaXQnID8gY3VycmVudC5jb250ZW50IDogb3V0cHV0LnZhbHVlLFxuICAgICAgb3V0bGluZTogd3JpdGVGb3JtLm91dGxpbmUsXG4gICAgICBjaGFwdGVyX25vOiBtb2RlLnZhbHVlID09PSAnZWRpdCcgPyBjdXJyZW50Q2hhcHRlck5vLnZhbHVlIDogbmV4dENoYXB0ZXJOby52YWx1ZSxcbiAgICB9KVxuICAgIHRpdGxlQ2FuZGlkYXRlcy52YWx1ZSA9IHIudGl0bGVzIHx8IFtdXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBtc2cudmFsdWUgPSBlLm1lc3NhZ2VcbiAgICBtc2dPay52YWx1ZSA9IGZhbHNlXG4gIH0gZmluYWxseSB7XG4gICAgdGl0bGluZy52YWx1ZSA9IGZhbHNlXG4gIH1cbn1cblxuZnVuY3Rpb24gcGlja1RpdGxlKHQpIHtcbiAgaWYgKG1vZGUudmFsdWUgPT09ICdlZGl0JykgY3VycmVudC50aXRsZSA9IHRcbiAgZWxzZSBzYXZlVGl0bGUudmFsdWUgPSB0XG4gIHRpdGxlQ2FuZGlkYXRlcy52YWx1ZSA9IFtdXG59XG5cbmFzeW5jIGZ1bmN0aW9uIG9uUGxhbigpIHtcbiAgcGxhbm5pbmcudmFsdWUgPSB0cnVlXG4gIHBsYW5FcnJvci52YWx1ZSA9ICcnXG4gIHRyeSB7XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IGdlbk91dGxpbmUobm92ZWxJZCwgbmV4dENoYXB0ZXJOby52YWx1ZSlcbiAgICBwbGFubmVyUmF3LnZhbHVlID0gZGF0YVxuICAgIHdyaXRlRm9ybS5vdXRsaW5lID0gb3V0bGluZVRvVGV4dChkYXRhKVxuICAgIGlmIChkYXRhLmNoYXB0ZXJfdGl0bGUpIHNhdmVUaXRsZS52YWx1ZSA9IGRhdGEuY2hhcHRlcl90aXRsZVxuICB9IGNhdGNoIChlKSB7XG4gICAgcGxhbkVycm9yLnZhbHVlID0gZS5tZXNzYWdlXG4gIH0gZmluYWxseSB7XG4gICAgcGxhbm5pbmcudmFsdWUgPSBmYWxzZVxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG9uV3JpdGVWYXJpYW50cygpIHtcbiAgaWYgKHZhcmlhbnRzV3JpdGluZy52YWx1ZSB8fCAhd3JpdGVGb3JtLm91dGxpbmUudHJpbSgpKSByZXR1cm5cbiAgdmFyaWFudHNXcml0aW5nLnZhbHVlID0gdHJ1ZVxuICB2YXJpYW50c0Vycm9yLnZhbHVlID0gJydcbiAgdmFyaWFudHMudmFsdWUgPSBbXVxuICBtc2cudmFsdWUgPSAnJ1xuICB0cnkge1xuICAgIGNvbnN0IHIgPSBhd2FpdCBnZW5lcmF0ZVZhcmlhbnRzKHtcbiAgICAgIG5vdmVsX2lkOiBub3ZlbElkLFxuICAgICAgb3V0bGluZTogd3JpdGVGb3JtLm91dGxpbmUsXG4gICAgICBwcmV2aW91c190ZXh0OiB3cml0ZUZvcm0ucHJldmlvdXNfdGV4dCxcbiAgICAgIG1heF90b2tlbnM6IDQwOTYsXG4gICAgfSlcbiAgICB2YXJpYW50cy52YWx1ZSA9IHIudmFyaWFudHMgfHwgW11cbiAgICBzdGF0cy52YWx1ZSA9IHJcbiAgfSBjYXRjaCAoZSkge1xuICAgIHZhcmlhbnRzRXJyb3IudmFsdWUgPSBlLm1lc3NhZ2VcbiAgfSBmaW5hbGx5IHtcbiAgICB2YXJpYW50c1dyaXRpbmcudmFsdWUgPSBmYWxzZVxuICB9XG59XG5cbmZ1bmN0aW9uIGltcG9ydFZhcmlhbnQodmFyaWFudCkge1xuICBvdXRwdXQudmFsdWUgPSB2YXJpYW50LmNvbnRlbnRcbiAgbXNnLnZhbHVlID0gYOW3suWwhueJiOacrCAke3ZhcmlhbnQubGFiZWx9IOWvvOWFpeS4u+e8lui+keWZqO+8jOWFtuS7lueJiOacrOS7jeS/neeVmeS4uue0oOadkGBcbiAgbXNnT2sudmFsdWUgPSB0cnVlXG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNvcHlWYXJpYW50KHZhcmlhbnQpIHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh2YXJpYW50LmNvbnRlbnQpXG4gICAgbXNnLnZhbHVlID0gYOeJiOacrCAke3ZhcmlhbnQubGFiZWx9IOW3suWkjeWItu+8jOWPr+eymOi0tOWIsOS4u+e8lui+keWZqOWQiOW5tmBcbiAgICBtc2dPay52YWx1ZSA9IHRydWVcbiAgfSBjYXRjaCB7XG4gICAgbXNnLnZhbHVlID0gJ+WkjeWItuWksei0pe+8jOivt+aJi+WKqOmAieaLqeato+aWh+WQjuWkjeWItidcbiAgICBtc2dPay52YWx1ZSA9IGZhbHNlXG4gIH1cbn1cblxuLyogLS0tLS0tLS0tLSDikaEg5YaZ5omLIC0tLS0tLS0tLS0gKi9cbmFzeW5jIGZ1bmN0aW9uIG9uV3JpdGUoKSB7XG4gIGlmICh3cml0aW5nLnZhbHVlKSByZXR1cm5cbiAgb3V0cHV0LnZhbHVlID0gJydcbiAgd3JpdGVFcnJvci52YWx1ZSA9ICcnXG4gIHN0YXRzLnZhbHVlID0gbnVsbFxuICBtc2cudmFsdWUgPSAnJ1xuICB3cml0aW5nLnZhbHVlID0gdHJ1ZVxuICBhYm9ydEN0cmwgPSBuZXcgQWJvcnRDb250cm9sbGVyKClcbiAgdHJ5IHtcbiAgICBjb25zdCBkb25lID0gYXdhaXQgc3RyZWFtV3JpdGUoXG4gICAgICB7XG4gICAgICAgIG5vdmVsX2lkOiBub3ZlbElkLFxuICAgICAgICBvdXRsaW5lOiB3cml0ZUZvcm0ub3V0bGluZSxcbiAgICAgICAgcHJldmlvdXNfdGV4dDogd3JpdGVGb3JtLnByZXZpb3VzX3RleHQsXG4gICAgICAgIG1heF90b2tlbnM6IDQwOTYsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBvbkRlbHRhOiAodCkgPT4gKG91dHB1dC52YWx1ZSArPSB0KSxcbiAgICAgICAgb25FcnJvcjogKG0pID0+ICh3cml0ZUVycm9yLnZhbHVlID0gbSksXG4gICAgICAgIHNpZ25hbDogYWJvcnRDdHJsLnNpZ25hbCxcbiAgICAgIH0sXG4gICAgKVxuICAgIHN0YXRzLnZhbHVlID0gZG9uZVxuICB9IGNhdGNoIChlKSB7XG4gICAgaWYgKGUubmFtZSAhPT0gJ0Fib3J0RXJyb3InKSB3cml0ZUVycm9yLnZhbHVlID0gZS5tZXNzYWdlXG4gIH0gZmluYWxseSB7XG4gICAgd3JpdGluZy52YWx1ZSA9IGZhbHNlXG4gIH1cbn1cblxuZnVuY3Rpb24gb25TdG9wKCkge1xuICBhYm9ydEN0cmwgJiYgYWJvcnRDdHJsLmFib3J0KClcbn1cblxuYXN5bmMgZnVuY3Rpb24gb25TYXZlQXNDaGFwdGVyKCkge1xuICBpZiAoIW91dHB1dC52YWx1ZS50cmltKCkpIHtcbiAgICBtc2cudmFsdWUgPSAn6L+Y5rKh5pyJ55Sf5oiQ5YaF5a65J1xuICAgIG1zZ09rLnZhbHVlID0gZmFsc2VcbiAgICByZXR1cm5cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNoID0gYXdhaXQgc2F2ZUNoYXB0ZXIoe1xuICAgICAgbm92ZWxfaWQ6IG5vdmVsSWQsXG4gICAgICB0aXRsZTogc2F2ZVRpdGxlLnZhbHVlIHx8IGDnrKwke25leHRDaGFwdGVyTm8udmFsdWV956ugYCxcbiAgICAgIGNvbnRlbnQ6IG91dHB1dC52YWx1ZSxcbiAgICAgIGRldGFpbGVkX291dGxpbmU6IHdyaXRlRm9ybS5vdXRsaW5lLFxuICAgIH0pXG4gICAgd3JpdGVGb3JtLnByZXZpb3VzX3RleHQgPSAnJyAvLyDkuIvkuIDnq6Doh6rliqjlj5bmnKznq6Dnu5PlsL7ooZTmjqVcbiAgICBtc2cudmFsdWUgPSBg5bey5L+d5a2Y77yaJHtjaC50aXRsZX3vvIgke2NoLndvcmRfY291bnR9IOWtl++8iWBcbiAgICBtc2dPay52YWx1ZSA9IHRydWVcbiAgICBhd2FpdCBsb2FkKClcbiAgICBvcGVuQ2hhcHRlcihjaClcbiAgfSBjYXRjaCAoZSkge1xuICAgIG1zZy52YWx1ZSA9IGUubWVzc2FnZVxuICAgIG1zZ09rLnZhbHVlID0gZmFsc2VcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBvblNhdmVFZGl0KCkge1xuICBpZiAoIWN1cnJlbnRJZC52YWx1ZSkgcmV0dXJuXG4gIHRyeSB7XG4gICAgYXdhaXQgdXBkYXRlQ2hhcHRlcihjdXJyZW50SWQudmFsdWUsIHtcbiAgICAgIHRpdGxlOiBjdXJyZW50LnRpdGxlLFxuICAgICAgY29udGVudDogY3VycmVudC5jb250ZW50LFxuICAgICAgZGV0YWlsZWRfb3V0bGluZTogd3JpdGVGb3JtLm91dGxpbmUsXG4gICAgfSlcbiAgICBtc2cudmFsdWUgPSAn5bey5L+d5a2Y5L+u5pS5J1xuICAgIG1zZ09rLnZhbHVlID0gdHJ1ZVxuICAgIGF3YWl0IGxvYWQoKVxuICB9IGNhdGNoIChlKSB7XG4gICAgbXNnLnZhbHVlID0gZS5tZXNzYWdlXG4gICAgbXNnT2sudmFsdWUgPSBmYWxzZVxuICB9XG59XG5cbi8qIC0tLS0tLS0tLS0g4pGiIOagoeWvuSAtLS0tLS0tLS0tICovXG5hc3luYyBmdW5jdGlvbiBvbkNoZWNrKCkge1xuICBpZiAoIWN1cnJlbnRJZC52YWx1ZSkgcmV0dXJuXG4gIGNoZWNraW5nLnZhbHVlID0gdHJ1ZVxuICBjaGVja1JlcG9ydC52YWx1ZSA9IG51bGxcbiAgdHJ5IHtcbiAgICBjb25zdCByID0gYXdhaXQgY2hlY2tDaGFwdGVyKGN1cnJlbnRJZC52YWx1ZSlcbiAgICAvLyDpu5jorqTlhajpgInvvIzmlrnkvr/kuIDplK7kv67lpI1cbiAgICBjaGVja1JlcG9ydC52YWx1ZSA9IHsgLi4uciwgaXNzdWVzOiAoci5pc3N1ZXMgfHwgW10pLm1hcCgoaXQpID0+ICh7IC4uLml0LCBzZWxlY3RlZDogdHJ1ZSB9KSkgfVxuICB9IGNhdGNoIChlKSB7XG4gICAgbXNnLnZhbHVlID0gZS5tZXNzYWdlXG4gICAgbXNnT2sudmFsdWUgPSBmYWxzZVxuICB9IGZpbmFsbHkge1xuICAgIGNoZWNraW5nLnZhbHVlID0gZmFsc2VcbiAgfVxufVxuXG4vKiAtLS0tLS0tLS0tIOS/rueov++8muaMieagoeWvueaEj+ingeS4gOmUruS/ruWkjSAtLS0tLS0tLS0tICovXG5hc3luYyBmdW5jdGlvbiBvblJldmlzZSgpIHtcbiAgaWYgKCFjdXJyZW50SWQudmFsdWUgfHwgIXNlbGVjdGVkSXNzdWVzLnZhbHVlLmxlbmd0aCkgcmV0dXJuXG4gIHJldmlzaW5nLnZhbHVlID0gdHJ1ZVxuICByZXZpc2VQcmV2aWV3LnZhbHVlID0gJydcbiAgdHJ5IHtcbiAgICBjb25zdCByID0gYXdhaXQgcmV2aXNlQ2hhcHRlcihjdXJyZW50SWQudmFsdWUsIHsgaXNzdWVzOiBzZWxlY3RlZElzc3Vlcy52YWx1ZSB9KVxuICAgIHJldmlzZVByZXZpZXcudmFsdWUgPSByLmNvbnRlbnRcbiAgfSBjYXRjaCAoZSkge1xuICAgIG1zZy52YWx1ZSA9IGUubWVzc2FnZVxuICAgIG1zZ09rLnZhbHVlID0gZmFsc2VcbiAgfSBmaW5hbGx5IHtcbiAgICByZXZpc2luZy52YWx1ZSA9IGZhbHNlXG4gIH1cbn1cblxuZnVuY3Rpb24gb25BcHBseVJldmlzaW9uKCkge1xuICBjdXJyZW50LmNvbnRlbnQgPSByZXZpc2VQcmV2aWV3LnZhbHVlXG4gIHJldmlzZVByZXZpZXcudmFsdWUgPSAnJ1xuICBjaGVja1JlcG9ydC52YWx1ZSA9IG51bGwgLy8g5L+u6K6i5ZCO5oql5ZGK5bey6L+H5pyf77yM5bu66K6u6YeN5paw5qCh5a+5XG4gIG1zZy52YWx1ZSA9ICflt7LlupTnlKjkv67orqLvvIzor7fmo4Dmn6XlkI7ngrnjgIzkv53lrZjkv67mlLnjgI0nXG4gIG1zZ09rLnZhbHVlID0gdHJ1ZVxufVxuXG4vKiAtLS0tLS0tLS0tIOKRoyDlrprnqL/vvIjmm7TmlrDorrDlv4bvvIkgLS0tLS0tLS0tLSAqL1xuYXN5bmMgZnVuY3Rpb24gb25GaW5hbGl6ZSgpIHtcbiAgaWYgKCFjdXJyZW50SWQudmFsdWUpIHJldHVyblxuICBmaW5hbGl6aW5nLnZhbHVlID0gdHJ1ZVxuICBmaW5hbGl6ZVJlc3VsdC52YWx1ZSA9IG51bGxcbiAgdHJ5IHtcbiAgICBmaW5hbGl6ZVJlc3VsdC52YWx1ZSA9IGF3YWl0IGZpbmFsaXplQ2hhcHRlcihjdXJyZW50SWQudmFsdWUpXG4gICAgY3VycmVudFN0YXR1cy52YWx1ZSA9ICflt7LlrprnqL8nXG4gICAgbXNnLnZhbHVlID0gJ+iusOW/huW3suabtOaWsCdcbiAgICBtc2dPay52YWx1ZSA9IHRydWVcbiAgICBhd2FpdCBsb2FkKClcbiAgfSBjYXRjaCAoZSkge1xuICAgIG1zZy52YWx1ZSA9IGUubWVzc2FnZVxuICAgIG1zZ09rLnZhbHVlID0gZmFsc2VcbiAgfSBmaW5hbGx5IHtcbiAgICBmaW5hbGl6aW5nLnZhbHVlID0gZmFsc2VcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBvbkRlbGV0ZUN1cnJlbnQoKSB7XG4gIGlmICghY3VycmVudElkLnZhbHVlKSByZXR1cm5cbiAgaWYgKCFjb25maXJtKGDnoa7lrprliKDpmaTjgIwke2N1cnJlbnQudGl0bGV944CN77yfYCkpIHJldHVyblxuICB0cnkge1xuICAgIGF3YWl0IGRlbGV0ZUNoYXB0ZXIoY3VycmVudElkLnZhbHVlKVxuICAgIGF3YWl0IGxvYWQoKVxuICAgIG9wZW5OZXcoKVxuICB9IGNhdGNoIChlKSB7XG4gICAgbXNnLnZhbHVlID0gZS5tZXNzYWdlXG4gICAgbXNnT2sudmFsdWUgPSBmYWxzZVxuICB9XG59XG5cbi8qIC0tLS0tLS0tLS0g5a+85Ye6IHR4dCAtLS0tLS0tLS0tICovXG5jb25zdCBleHBvcnRTaG93ID0gcmVmKGZhbHNlKVxuY29uc3QgZXhwb3J0U2VsID0gcmVmKG5ldyBTZXQoKSlcbmNvbnN0IGV4cG9ydEluY2x1ZGVPdXRsaW5lID0gcmVmKGZhbHNlKVxuY29uc3QgZXhwb3J0aW5nID0gcmVmKGZhbHNlKVxuXG5mdW5jdGlvbiBvcGVuRXhwb3J0KCkge1xuICBleHBvcnRTZWwudmFsdWUgPSBuZXcgU2V0KGNoYXB0ZXJzLnZhbHVlLm1hcCgoYykgPT4gYy5pZCkpIC8vIOm7mOiupOWFqOmAiVxuICBleHBvcnRJbmNsdWRlT3V0bGluZS52YWx1ZSA9IGZhbHNlXG4gIGV4cG9ydFNob3cudmFsdWUgPSB0cnVlXG59XG5cbmZ1bmN0aW9uIHRvZ2dsZUV4cG9ydChpZCkge1xuICBpZiAoZXhwb3J0U2VsLnZhbHVlLmhhcyhpZCkpIGV4cG9ydFNlbC52YWx1ZS5kZWxldGUoaWQpXG4gIGVsc2UgZXhwb3J0U2VsLnZhbHVlLmFkZChpZClcbn1cblxuZnVuY3Rpb24gZXhwb3J0U2VsZWN0QWxsKCkge1xuICBleHBvcnRTZWwudmFsdWUgPSBuZXcgU2V0KGNoYXB0ZXJzLnZhbHVlLm1hcCgoYykgPT4gYy5pZCkpXG59XG5cbmZ1bmN0aW9uIGV4cG9ydENsZWFyKCkge1xuICBleHBvcnRTZWwudmFsdWUgPSBuZXcgU2V0KClcbn1cblxuYXN5bmMgZnVuY3Rpb24gb25FeHBvcnQoKSB7XG4gIGlmICghZXhwb3J0U2VsLnZhbHVlLnNpemUpIHJldHVyblxuICBleHBvcnRpbmcudmFsdWUgPSB0cnVlXG4gIHRyeSB7XG4gICAgY29uc3QgeyBibG9iLCBmaWxlbmFtZSB9ID0gYXdhaXQgZXhwb3J0Q2hhcHRlclR4dChub3ZlbElkLCB7XG4gICAgICBjaGFwdGVyX2lkczogWy4uLmV4cG9ydFNlbC52YWx1ZV0sXG4gICAgICBpbmNsdWRlX291dGxpbmU6IGV4cG9ydEluY2x1ZGVPdXRsaW5lLnZhbHVlLFxuICAgIH0pXG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKVxuICAgIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJylcbiAgICBhLmhyZWYgPSB1cmxcbiAgICBhLmRvd25sb2FkID0gZmlsZW5hbWVcbiAgICBhLmNsaWNrKClcbiAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybClcbiAgICBleHBvcnRTaG93LnZhbHVlID0gZmFsc2VcbiAgfSBjYXRjaCAoZSkge1xuICAgIG1zZy52YWx1ZSA9IGUubWVzc2FnZVxuICAgIG1zZ09rLnZhbHVlID0gZmFsc2VcbiAgfSBmaW5hbGx5IHtcbiAgICBleHBvcnRpbmcudmFsdWUgPSBmYWxzZVxuICB9XG59XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8ZGl2PlxuICAgIDxkaXYgdi1pZj1cImxvYWRFcnJvclwiIGNsYXNzPVwibXNnIGVyclwiPnt7IGxvYWRFcnJvciB9fTwvZGl2PlxuXG4gICAgPHRlbXBsYXRlIHYtZWxzZS1pZj1cImRldGFpbFwiPlxuICAgICAgPGRpdiBjbGFzcz1cIm5vdmVsLWhlYWRcIj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImxpbmtcIiBAY2xpY2s9XCJyb3V0ZXIucHVzaCgnLycpXCI+4oaQIOi/lOWbnuS5puaetjwvYnV0dG9uPlxuICAgICAgICA8aDI+e3sgZGV0YWlsLm5vdmVsLnRpdGxlIH19PC9oMj5cbiAgICAgICAgPHNwYW4gdi1pZj1cImRldGFpbC5ub3ZlbC5nZW5yZVwiIGNsYXNzPVwidGFnXCI+e3sgZGV0YWlsLm5vdmVsLmdlbnJlIH19PC9zcGFuPlxuICAgICAgICA8c3BhbiB2LWlmPVwiZGV0YWlsLm5vdmVsLnN0eWxlXCIgY2xhc3M9XCJ0YWdcIj57eyBkZXRhaWwubm92ZWwuc3R5bGUgfX08L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzPVwiaGludFwiPnt7IGNoYXB0ZXJzLmxlbmd0aCB9fSDnq6Agwrcg5pu05paw5LqOIHt7IGZtdFRpbWUoZGV0YWlsLm5vdmVsLnVwZGF0ZWRfYXQpIH19PC9zcGFuPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2VyXCI+PC9kaXY+XG4gICAgICAgIDxidXR0b24gQGNsaWNrPVwib3BlbkV4cG9ydFwiPuKshyDlr7zlh7ogdHh0PC9idXR0b24+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJsaW5rXCIgQGNsaWNrPVwicm91dGVyLnB1c2goYC9ub3ZlbC8ke25vdmVsSWR9L3NldHRpbmdzYClcIj7wn6egIOiuvuWumiAvIOiusOW/hjwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIEBjbGljaz1cIm9wZW5OZXdcIj7vvIsg5YaZ5paw56ug6IqCPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzcz1cIndvcmtiZW5jaFwiPlxuICAgICAgICA8IS0tIOW3pu+8mueroOiKguWIl+ihqCAtLT5cbiAgICAgICAgPGFzaWRlIGNsYXNzPVwiY2hhcHRlci1saXN0IGNhcmRcIj5cbiAgICAgICAgICA8ZGl2IHYtZm9yPVwidiBpbiB2b2x1bWVzXCIgOmtleT1cInYuaWRcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzcz1cInZvbHVtZS10aXRsZVwiPnt7IHYudGl0bGUgfX08L2gzPlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICB2LWZvcj1cImNoIGluIHYuY2hhcHRlcnNcIlxuICAgICAgICAgICAgICA6a2V5PVwiY2guaWRcIlxuICAgICAgICAgICAgICBjbGFzcz1cImNoYXB0ZXItaXRlbVwiXG4gICAgICAgICAgICAgIDpjbGFzcz1cInsgYWN0aXZlOiBtb2RlID09PSAnZWRpdCcgJiYgY3VycmVudElkID09PSBjaC5pZCB9XCJcbiAgICAgICAgICAgICAgQGNsaWNrPVwib3BlbkNoYXB0ZXIoY2gpXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJjaC1sYWJlbFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZG90XCIgOmNsYXNzPVwiY2guc3RhdHVzID09PSAn5bey5a6a56i/JyA/ICdiLWdyZWVuJyA6ICdiLWdyYXknXCIgOnRpdGxlPVwiY2guc3RhdHVzXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIOesrHt7IGNoLmNoYXB0ZXJfbm8gfX3nq6Age3sgY2gudGl0bGUgfX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImhpbnRcIj57eyBjaC53b3JkX2NvdW50IH19IOWtlzwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIHYtaWY9XCIhY2hhcHRlcnMubGVuZ3RoXCIgY2xhc3M9XCJoaW50XCI+XG4gICAgICAgICAgICDov5jmsqHmnInnq6DoioLjgILlu7rorq7mtYHnqIvvvJrinKgg55Sf5oiQ57uG57qyIOKGkiDlvIDlp4vlhpnkvZwg4oaSIOS/neWtmCDihpIg5qCh5a+5IOKGkiDlrprnqL/vvIjmm7TmlrDorrDlv4bvvIlcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvYXNpZGU+XG5cbiAgICAgICAgPCEtLSDlj7PvvJrlhpnkvZwgLyDnvJbovpHpnaLmnb8gLS0+XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzPVwiY2FyZCBwYW5lbFwiPlxuICAgICAgICAgIDwhLS0gPT09PT09PT09PT09IOWGmeaWsOeroOiKgiA9PT09PT09PT09PT0gLS0+XG4gICAgICAgICAgPHRlbXBsYXRlIHYtaWY9XCJtb2RlID09PSAnbmV3J1wiPlxuICAgICAgICAgICAgPGgyPuWGmeaWsOeroOiKgiA8c3BhbiBjbGFzcz1cImhpbnRcIj7nrKwge3sgbmV4dENoYXB0ZXJObyB9fSDnq6DvvIjnq6Dlj7foh6rliqjvvIk8L3NwYW4+PC9oMj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIDpkaXNhYmxlZD1cInBsYW5uaW5nIHx8IHdyaXRpbmdcIiBAY2xpY2s9XCJvblBsYW5cIj5cbiAgICAgICAgICAgICAgICB7eyBwbGFubmluZyA/ICfnlJ/miJDnu4bnurLkuK3igKYnIDogJ+KcqCBBSSDnlJ/miJDnu4bnurLvvIjnu4bnurLluIjvvIknIH19XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCB2LWlmPVwicGxhbkVycm9yXCIgY2xhc3M9XCJtc2cgZXJyXCI+e3sgcGxhbkVycm9yIH19PC9wPlxuXG4gICAgICAgICAgICA8ZGl2IHYtaWY9XCJwbGFubmVyUmF3XCIgY2xhc3M9XCJwbGFuLXByZXZpZXdcIj5cbiAgICAgICAgICAgICAgPGgzPnt7IHBsYW5uZXJSYXcuY2hhcHRlcl90aXRsZSB8fCBg56ysJHtuZXh0Q2hhcHRlck5vfeeroGAgfX08L2gzPlxuICAgICAgICAgICAgICA8ZGl2IHYtZm9yPVwicyBpbiBwbGFubmVyUmF3LnNjZW5lc1wiIDprZXk9XCJzLnNjZW5lX25vXCIgY2xhc3M9XCJwbGFuLXNjZW5lXCI+XG4gICAgICAgICAgICAgICAgPGI+5Zy65pmvIHt7IHMuc2NlbmVfbm8gfX08L2I+XG4gICAgICAgICAgICAgICAg772ce3sgcy5sb2NhdGlvbiB8fCAn5Zyw54K55pyq5a6aJyB9fe+9nHt7IChzLnBhcnRpY2lwYW50cyB8fCBbXSkuam9pbign44CBJykgfHwgJ+WHuuWcuuacquWumicgfX1cbiAgICAgICAgICAgICAgICA8ZGl2IHYtaWY9XCJzLmdvYWxcIiBjbGFzcz1cImhpbnRcIj7liafmg4XkvZznlKjvvJp7eyBzLmdvYWwgfX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IHYtaWY9XCJzLmV2ZW50c1wiPnt7IHMuZXZlbnRzIH19PC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGxhbi1mb290XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gdi1pZj1cInBsYW5uZXJSYXcuZm9yZXNoYWRvd2luZ3NfcGxhbnRlZD8ubGVuZ3RoXCIgY2xhc3M9XCJ0YWcgdGFnLW5ld1wiPlxuICAgICAgICAgICAgICAgICAg5Z+L6K6+77yae3sgcGxhbm5lclJhdy5mb3Jlc2hhZG93aW5nc19wbGFudGVkLm1hcCgoZikgPT4gZi50aXRsZSkuam9pbign44CBJykgfX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gdi1pZj1cInBsYW5uZXJSYXcuZm9yZXNoYWRvd2luZ3NfcmVzb2x2ZWQ/Lmxlbmd0aFwiIGNsYXNzPVwidGFnIHRhZy1kb25lXCI+XG4gICAgICAgICAgICAgICAgICDlm57mlLbvvJp7eyBwbGFubmVyUmF3LmZvcmVzaGFkb3dpbmdzX3Jlc29sdmVkLmpvaW4oJ+OAgScpIH19XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiB2LWlmPVwicGxhbm5lclJhdy5ob29rXCIgY2xhc3M9XCJwbGFuLWhvb2tcIj7wn6qdIHt7IHBsYW5uZXJSYXcuaG9vayB9fTwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxsYWJlbD7nu4bnurLvvIjlj6/nvJbovpHvvIzlt7LlkIzmraXkuLrkuIrmlofnlJ/miJDnu5PmnpzvvIk8L2xhYmVsPlxuICAgICAgICAgICAgPHRleHRhcmVhIHYtbW9kZWw9XCJ3cml0ZUZvcm0ub3V0bGluZVwiIHJvd3M9XCI1XCIgcGxhY2Vob2xkZXI9XCLnlZnnqbrliJkgQUkg6Ieq6KGM5a6J5o6S77yb5bu66K6u5YWI54K544CM4pyoIEFJIOeUn+aIkOe7hue6suOAjVwiPjwvdGV4dGFyZWE+XG4gICAgICAgICAgICA8bGFiZWw+5YmN5paH6KGU5o6lIDxzcGFuIGNsYXNzPVwiaGludFwiPueVmeepuuiHquWKqOWPluS4iuS4gOeroOe7k+WwviA4MDAg5a2XPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgICAgICA8dGV4dGFyZWEgdi1tb2RlbD1cIndyaXRlRm9ybS5wcmV2aW91c190ZXh0XCIgcm93cz1cIjJcIiBwbGFjZWhvbGRlcj1cIuS5n+WPr+aJi+WKqOeymOi0tOeJueWumueJh+autVwiPjwvdGV4dGFyZWE+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgOmRpc2FibGVkPVwid3JpdGluZyB8fCBwbGFubmluZyB8fCB2YXJpYW50c1dyaXRpbmdcIiBAY2xpY2s9XCJvbldyaXRlXCI+XG4gICAgICAgICAgICAgICAge3sgd3JpdGluZyA/ICflhpnkvZzkuK3igKYnIDogJ+W8gOWni+WGmeS9nO+8iOWNleeJiO+8iScgfX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b24gOmRpc2FibGVkPVwid3JpdGluZyB8fCBwbGFubmluZyB8fCB2YXJpYW50c1dyaXRpbmcgfHwgIXdyaXRlRm9ybS5vdXRsaW5lLnRyaW0oKVwiIEBjbGljaz1cIm9uV3JpdGVWYXJpYW50c1wiPlxuICAgICAgICAgICAgICAgIHt7IHZhcmlhbnRzV3JpdGluZyA/ICfnlJ/miJAgQS9CL0Mg5Lit4oCmJyA6ICfnlJ/miJAgQS9CL0Mg5LiJ54mIJyB9fVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiA6ZGlzYWJsZWQ9XCIhd3JpdGluZ1wiIEBjbGljaz1cIm9uU3RvcFwiPuWBnOatojwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCB2LWlmPVwid3JpdGVFcnJvclwiIGNsYXNzPVwibXNnIGVyclwiPnt7IHdyaXRlRXJyb3IgfX08L3A+XG4gICAgICAgICAgICA8cCB2LWlmPVwidmFyaWFudHNFcnJvclwiIGNsYXNzPVwibXNnIGVyclwiPnt7IHZhcmlhbnRzRXJyb3IgfX08L3A+XG5cbiAgICAgICAgICAgIDxkaXYgdi1pZj1cInZhcmlhbnRzLmxlbmd0aFwiIGNsYXNzPVwidmFyaWFudHMtcGFuZWxcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm91dHB1dC1oZWFkXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+5LiJ54mI5q2j5paH57Sg5p2QPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaGludFwiPumAieaLqeS4gOeJiOWvvOWFpeS4u+e8lui+keWZqO+8jOWFtuS7lueJiOacrOS4jeS8muWIoOmZpDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ2YXJpYW50LWdyaWRcIj5cbiAgICAgICAgICAgICAgICA8YXJ0aWNsZSB2LWZvcj1cInZhcmlhbnQgaW4gdmFyaWFudHNcIiA6a2V5PVwidmFyaWFudC5sYWJlbFwiIGNsYXNzPVwidmFyaWFudC1jYXJkXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidmFyaWFudC1oZWFkXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+54mI5pysIHt7IHZhcmlhbnQubGFiZWwgfX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJoaW50XCI+e3sgdmFyaWFudC53b3JkX2NvdW50IH19IOWtlzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHByZSBjbGFzcz1cInZhcmlhbnQtYm9keVwiIHRhYmluZGV4PVwiMFwiPnt7IHZhcmlhbnQuY29udGVudCB9fTwvcHJlPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvdyB2YXJpYW50LWFjdGlvbnNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBAY2xpY2s9XCJpbXBvcnRWYXJpYW50KHZhcmlhbnQpXCI+5a+85YWl5Li757yW6L6R5ZmoPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gQGNsaWNrPVwiY29weVZhcmlhbnQodmFyaWFudClcIj7lpI3liLblhajmloc8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiB2LXNob3c9XCJvdXRwdXQgfHwgd3JpdGluZ1wiIGNsYXNzPVwib3V0cHV0XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJvdXRwdXQtaGVhZFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPnt7IHdyaXRpbmcgPyAn5q2j5Zyo55Sf5oiQ4oCmJyA6IGDkuLvnvJbovpHlmaggwrcgJHtjaGFyQ291bnR9IOWtl2AgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gdi1pZj1cInZhcmlhbnRzLmxlbmd0aFwiIGNsYXNzPVwiaGludFwiPuWPr+eymOi0tOe0oOadkOmdouadv+eJh+autei/m+ihjOWQiOW5tjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDx0ZXh0YXJlYSB2LW1vZGVsPVwib3V0cHV0XCIgcm93cz1cIjE0XCIgY2xhc3M9XCJlZGl0b3JcIiA6cGxhY2Vob2xkZXI9XCJ3cml0aW5nID8gJ+ato+aWh+eUn+aIkOS4reKApicgOiAn6YCJ5oup54mI5pys5a+85YWl77yM5oiW55u05o6l57yW6L6R5Li756i/J1wiPjwvdGV4dGFyZWE+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3cgc2F2ZS1yb3dcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXQgdi1tb2RlbD1cInNhdmVUaXRsZVwiIGNsYXNzPVwiZ3Jvd1wiIHBsYWNlaG9sZGVyPVwi56ug6IqC5qCH6aKYXCIgLz5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIDpkaXNhYmxlZD1cInRpdGxpbmdcIiA6dGl0bGU9XCInQUkg6LW35qCH6aKYJ1wiIEBjbGljaz1cIm9uR2VuVGl0bGVzXCI+4pyoPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiA6ZGlzYWJsZWQ9XCIhb3V0cHV0IHx8IHdyaXRpbmcgfHwgdmFyaWFudHNXcml0aW5nXCIgQGNsaWNrPVwib25TYXZlQXNDaGFwdGVyXCI+5L+d5a2Y5Li656ug6IqCPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IHYtaWY9XCJ0aXRsZUNhbmRpZGF0ZXMubGVuZ3RoXCIgY2xhc3M9XCJ0aXRsZS1jYW5kc1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaGludFwiPuWAmemAieagh+mimO+8iOeCueWHu+mAieeUqO+8ie+8mjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHYtZm9yPVwiKHQsIGkpIGluIHRpdGxlQ2FuZGlkYXRlc1wiIDprZXk9XCJpXCIgY2xhc3M9XCJjYW5kXCIgQGNsaWNrPVwicGlja1RpdGxlKHQpXCI+e3sgdCB9fTwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgdi1pZj1cIm1zZ1wiIGNsYXNzPVwibXNnXCIgOmNsYXNzPVwibXNnT2sgPyAnb2snIDogJ2VycidcIj57eyBtc2cgfX08L3A+XG4gICAgICAgICAgICAgIDxwIHYtaWY9XCJzdGF0cyAmJiAhbXNnXCIgY2xhc3M9XCJtc2cgb2tcIj7nlJ/miJDlrozmiJDvvJrogJfml7Yge3sgKHN0YXRzLmR1cmF0aW9uX21zIC8gMTAwMCkudG9GaXhlZCgxKSB9fSBzPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC90ZW1wbGF0ZT5cblxuICAgICAgICAgIDwhLS0gPT09PT09PT09PT09IOe8lui+keW3suacieeroOiKgiA9PT09PT09PT09PT0gLS0+XG4gICAgICAgICAgPHRlbXBsYXRlIHYtZWxzZT5cbiAgICAgICAgICAgIDxoMj5cbiAgICAgICAgICAgICAg57yW6L6R56ug6IqCXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2VcIiA6Y2xhc3M9XCJjdXJyZW50U3RhdHVzID09PSAn5bey5a6a56i/JyA/ICdiLWdyZWVuJyA6ICdiLWdyYXknXCI+XG4gICAgICAgICAgICAgICAge3sgY3VycmVudFN0YXR1cyB8fCAn6I2J56i/JyB9fVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPGxhYmVsPuagh+mimDwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCIgc3R5bGU9XCJtYXJnaW4tdG9wOiA0cHhcIj5cbiAgICAgICAgICAgICAgPGlucHV0IHYtbW9kZWw9XCJjdXJyZW50LnRpdGxlXCIgY2xhc3M9XCJncm93XCIgLz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiA6ZGlzYWJsZWQ9XCJ0aXRsaW5nXCIgQGNsaWNrPVwib25HZW5UaXRsZXNcIj5cbiAgICAgICAgICAgICAgICB7eyB0aXRsaW5nID8gJ+i1t+WQjeS4reKApicgOiAn4pyoIEFJIOi1t+agh+mimCcgfX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgdi1pZj1cInRpdGxlQ2FuZGlkYXRlcy5sZW5ndGhcIiBjbGFzcz1cInRpdGxlLWNhbmRzXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaGludFwiPuWAmemAieagh+mimO+8iOeCueWHu+mAieeUqO+8ie+8mjwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiB2LWZvcj1cIih0LCBpKSBpbiB0aXRsZUNhbmRpZGF0ZXNcIiA6a2V5PVwiaVwiIGNsYXNzPVwiY2FuZFwiIEBjbGljaz1cInBpY2tUaXRsZSh0KVwiPnt7IHQgfX08L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGxhYmVsPuato+aWh++8iOWPr+ebtOaOpeS/ruaUue+8iTwvbGFiZWw+XG4gICAgICAgICAgICA8dGV4dGFyZWEgdi1tb2RlbD1cImN1cnJlbnQuY29udGVudFwiIHJvd3M9XCIxNFwiIGNsYXNzPVwiZWRpdG9yXCI+PC90ZXh0YXJlYT5cbiAgICAgICAgICAgIDxsYWJlbD7nu4bnurI8L2xhYmVsPlxuICAgICAgICAgICAgPHRleHRhcmVhIHYtbW9kZWw9XCJ3cml0ZUZvcm0ub3V0bGluZVwiIHJvd3M9XCIzXCIgcGxhY2Vob2xkZXI9XCLmnKznq6Dnu4bnurLvvIzkvpvmoKHlr7nkuI4gQUkg6YeN5YaZ5Y+C6ICDXCI+PC90ZXh0YXJlYT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBAY2xpY2s9XCJvblNhdmVFZGl0XCI+5L+d5a2Y5L+u5pS5PC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b24gQGNsaWNrPVwib3Blbk5ld1wiPuWGmeaWsOeroOiKgjwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiZGFuZ2VyXCIgQGNsaWNrPVwib25EZWxldGVDdXJyZW50XCI+5Yig6Zmk5pys56ugPC9idXR0b24+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZXJcIj48L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiA6ZGlzYWJsZWQ9XCJjaGVja2luZ1wiIEBjbGljaz1cIm9uQ2hlY2tcIj57eyBjaGVja2luZyA/ICfmoKHlr7nkuK3igKYnIDogJ/CflI0g5qCh5a+5JyB9fTwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIDpkaXNhYmxlZD1cImZpbmFsaXppbmdcIiBAY2xpY2s9XCJvbkZpbmFsaXplXCI+XG4gICAgICAgICAgICAgICAge3sgZmluYWxpemluZyA/ICfmm7TmlrDorrDlv4bkuK3igKYnIDogJ/Cfk50g5a6a56i/77yI5pu05paw6K6w5b+G77yJJyB9fVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHAgdi1pZj1cIm1zZ1wiIGNsYXNzPVwibXNnXCIgOmNsYXNzPVwibXNnT2sgPyAnb2snIDogJ2VycidcIj57eyBtc2cgfX08L3A+XG5cbiAgICAgICAgICAgIDwhLS0g5qCh5a+55oql5ZGKIC0tPlxuICAgICAgICAgICAgPGRpdiB2LWlmPVwiY2hlY2tSZXBvcnRcIiBjbGFzcz1cImNoZWNrLXJlcG9ydFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwib3V0cHV0LWhlYWRcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj7moKHlr7nmiqXlkYo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZVwiIDpjbGFzcz1cImNoZWNrUmVwb3J0LnZlcmRpY3QgPT09ICdwYXNzJyA/ICdiLWdyZWVuJyA6ICdiLWhpZ2gnXCI+XG4gICAgICAgICAgICAgICAgICB7eyBjaGVja1JlcG9ydC52ZXJkaWN0ID09PSAncGFzcycgPyAn4pyTIOmAmui/hycgOiAn6ZyA5L+u5pS5JyB9fVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgdi1mb3I9XCIoaXQsIGkpIGluIGNoZWNrUmVwb3J0Lmlzc3Vlc1wiIDprZXk9XCJpXCIgY2xhc3M9XCJpc3N1ZVwiIDpjbGFzcz1cIml0LnNldmVyaXR5XCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiaXNzdWUtY2hlY2tcIj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiB2LW1vZGVsPVwiaXQuc2VsZWN0ZWRcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZVwiIDpjbGFzcz1cImBiLSR7aXQuc2V2ZXJpdHl9YFwiPnt7IGl0LnNldmVyaXR5IH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGI+e3sgaXQudHlwZSB9fTwvYj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaGludFwiPnt7IGl0LmxvY2F0aW9uIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGRpdj57eyBpdC5kZXNjcmlwdGlvbiB9fTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgdi1pZj1cIml0LnN1Z2dlc3Rpb25cIiBjbGFzcz1cImhpbnRcIj7lu7rorq7vvJp7eyBpdC5zdWdnZXN0aW9uIH19PC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCB2LWlmPVwiIWNoZWNrUmVwb3J0Lmlzc3Vlcy5sZW5ndGhcIiBjbGFzcz1cIm1zZyBva1wiPuacquWPkeeOsOmXrumimDwvcD5cbiAgICAgICAgICAgICAgPGRpdiB2LWVsc2UgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIDpkaXNhYmxlZD1cInJldmlzaW5nIHx8ICFzZWxlY3RlZElzc3Vlcy5sZW5ndGhcIiBAY2xpY2s9XCJvblJldmlzZVwiPlxuICAgICAgICAgICAgICAgICAge3sgcmV2aXNpbmcgPyAnQUkg5L+u56i/5Lit4oCmJyA6IGDwn5ugIEFJIOS/ruWkjeaJgOmAiemXrumimO+8iCR7c2VsZWN0ZWRJc3N1ZXMubGVuZ3Rofe+8iWAgfX1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPCEtLSDkv67orqLnqL/pooTop4ggLS0+XG4gICAgICAgICAgICA8ZGl2IHYtaWY9XCJyZXZpc2VQcmV2aWV3XCIgY2xhc3M9XCJyZXZpc2UtcHJldmlld1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwib3V0cHV0LWhlYWRcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj7kv67orqLnqL/pooTop4jvvIjlj6rmlLnpl67popjnm7jlhbPlpITvvIzlhbbkvZnljp/moLfkv53nlZnvvIk8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cHJlIGNsYXNzPVwib3V0cHV0LWJvZHlcIj57eyByZXZpc2VQcmV2aWV3IH19PC9wcmU+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIEBjbGljaz1cIm9uQXBwbHlSZXZpc2lvblwiPuW6lOeUqOS/ruiuojwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gQGNsaWNrPVwicmV2aXNlUHJldmlldyA9ICcnXCI+5pS+5byDPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDwhLS0g5a6a56i/57uT5p6cIC0tPlxuICAgICAgICAgICAgPGRpdiB2LWlmPVwiZmluYWxpemVSZXN1bHRcIiBjbGFzcz1cImZpbmFsaXplLXJlc3VsdFwiPlxuICAgICAgICAgICAgICA8cCBjbGFzcz1cIm1zZyBva1wiPlxuICAgICAgICAgICAgICAgIOiusOW/huW3suabtOaWsO+8muinkuiJsueKtuaAgSB7eyBmaW5hbGl6ZVJlc3VsdC5jaGFyYWN0ZXJzX3VwZGF0ZWQgfX0g5aSEIMK3XG4gICAgICAgICAgICAgICAg5paw5Z+L5LyP56yUIHt7IGZpbmFsaXplUmVzdWx0LmZvcmVzaGFkb3dpbmdzX3BsYW50ZWQgfX0g5p2hIMK3XG4gICAgICAgICAgICAgICAg5Zue5pS25LyP56yUIHt7IGZpbmFsaXplUmVzdWx0LmZvcmVzaGFkb3dpbmdzX3Jlc29sdmVkIH19IOadoVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaW50XCI+56ug5pGY6KaB77yae3sgZmluYWxpemVSZXN1bHQuc3VtbWFyeSB9fTwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC90ZW1wbGF0ZT5cbiAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDwhLS0g5a+85Ye65by556qXIC0tPlxuICAgICAgPGRpdiB2LWlmPVwiZXhwb3J0U2hvd1wiIGNsYXNzPVwib3ZlcmxheVwiIEBjbGljay5zZWxmPVwiZXhwb3J0U2hvdyA9IGZhbHNlXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbCBtb2RhbC1sZ1wiPlxuICAgICAgICAgIDxoMz7lr7zlh7rkuLogdHh0PC9oMz5cbiAgICAgICAgICA8cCBjbGFzcz1cImhpbnRcIj7li77pgInopoHlr7zlh7rnmoTnq6DoioLvvJvmlofku7blkKvkuablkI3jgIHljbflkI3kuI7nq6DmoIfpopjvvIzpgILphY3pmIXor7vlmajkuI4gQUkg5pS557yW5bel5YW3PC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDhweFwiPlxuICAgICAgICAgICAgPGJ1dHRvbiBAY2xpY2s9XCJleHBvcnRTZWxlY3RBbGxcIj7lhajpgIk8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gQGNsaWNrPVwiZXhwb3J0Q2xlYXJcIj7muIXnqbo8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZXhwb3J0LWxpc3RcIj5cbiAgICAgICAgICAgIDx0ZW1wbGF0ZSB2LWZvcj1cInYgaW4gdm9sdW1lc1wiIDprZXk9XCJ2LmlkXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ2b2x1bWUtdGl0bGVcIj57eyB2LnRpdGxlIH19PC9kaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCB2LWZvcj1cImNoIGluIHYuY2hhcHRlcnNcIiA6a2V5PVwiY2guaWRcIiBjbGFzcz1cImV4cG9ydC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgOmNoZWNrZWQ9XCJleHBvcnRTZWwuaGFzKGNoLmlkKVwiXG4gICAgICAgICAgICAgICAgICBAY2hhbmdlPVwidG9nZ2xlRXhwb3J0KGNoLmlkKVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj7nrKx7eyBjaC5jaGFwdGVyX25vIH1956ugIHt7IGNoLnRpdGxlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaGludFwiPnt7IGNoLndvcmRfY291bnQgfX0g5a2XPC9zcGFuPlxuICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPC90ZW1wbGF0ZT5cbiAgICAgICAgICAgIDxwIHYtaWY9XCIhY2hhcHRlcnMubGVuZ3RoXCIgY2xhc3M9XCJoaW50XCI+6L+Y5rKh5pyJ56ug6IqC5Y+v5a+85Ye6PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImV4cG9ydC1vcHRcIj5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiB2LW1vZGVsPVwiZXhwb3J0SW5jbHVkZU91dGxpbmVcIiAvPlxuICAgICAgICAgICAg5YyF5ZCr5q+P56ug57uG57qy77yI5Zy65pmvL+S6uueJqS/kuovku7bvvIzmlrnkvr8gQUkg5ryr5Ymn5YiG6ZWc5Y+C6ICD77yJXG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIDpkaXNhYmxlZD1cIiFleHBvcnRTZWwuc2l6ZSB8fCBleHBvcnRpbmdcIiBAY2xpY2s9XCJvbkV4cG9ydFwiPlxuICAgICAgICAgICAgICB7eyBleHBvcnRpbmcgPyAn5a+85Ye65Lit4oCmJyA6IGDkuIvovb0gdHh077yI5bey6YCJICR7ZXhwb3J0U2VsLnNpemV9IOeroO+8iWAgfX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiBAY2xpY2s9XCJleHBvcnRTaG93ID0gZmFsc2VcIj7lj5bmtog8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3RlbXBsYXRlPlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG4iXSwibWFwcGluZ3MiOiJBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7QUFFakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUV0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFdEcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRTdELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRXhCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUVuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRTVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUVuRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUU5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFdkUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUVkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0M7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3Qjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0csQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDO0FBQ0Y7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUM7QUFDRjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQztBQUNGOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkI7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUM7QUFDRjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDO0FBQ0Y7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDO0FBQ0Y7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUM7QUFDRjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDO0FBQ0Y7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25GLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDO0FBQ0Y7O0FBRUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25COztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUM7QUFDRjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUM7QUFDRjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUUzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCOztBQUVBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRDs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1Qjs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUM7QUFDRjs7Ozs7Ozs7Ozs7O0VBSzBCLEtBQUssRUFBQyxTQUFTOztxQkFHOUIsS0FBSyxFQUFDLFlBQVk7OztFQUdXLEtBQUssRUFBQyxLQUFLOzs7O0VBQ1gsS0FBSyxFQUFDLEtBQUs7O3FCQUNyQyxLQUFLLEVBQUMsTUFBTTtxQkFPZixLQUFLLEVBQUMsV0FBVztxQkFFYixLQUFLLEVBQUMsbUJBQW1CO3FCQUV4QixLQUFLLEVBQUMsY0FBYzs7c0JBUWhCLEtBQUssRUFBQyxVQUFVOztzQkFJaEIsS0FBSyxFQUFDLE1BQU07OztFQUdLLEtBQUssRUFBQyxNQUFNOztzQkFNaEMsS0FBSyxFQUFDLFlBQVk7c0JBR1IsS0FBSyxFQUFDLE1BQU07c0JBRXRCLEtBQUssRUFBQyxLQUFLOzs7O0VBS0ksS0FBSyxFQUFDLFNBQVM7Ozs7RUFFWixLQUFLLEVBQUMsY0FBYzs7OztFQUtwQixLQUFLLEVBQUMsTUFBTTs7O3NCQUc1QixLQUFLLEVBQUMsV0FBVzs7O0VBQ21DLEtBQUssRUFBQyxhQUFhOzs7O0VBR2xCLEtBQUssRUFBQyxjQUFjOzs7O0VBSWxELEtBQUssRUFBQyxXQUFXOztzQkFPMUMsS0FBSyxFQUFDLEtBQUs7Ozs7OztFQVNLLEtBQUssRUFBQyxTQUFTOzs7O0VBQ1osS0FBSyxFQUFDLFNBQVM7Ozs7RUFFWCxLQUFLLEVBQUMsZ0JBQWdCOztzQkFLM0MsS0FBSyxFQUFDLGNBQWM7c0JBRWhCLEtBQUssRUFBQyxjQUFjO3NCQUVqQixLQUFLLEVBQUMsTUFBTTs7RUFFZixLQUFLLEVBQUMsY0FBYztFQUFDLFFBQVEsRUFBQyxHQUFHOztzQkFDakMsS0FBSyxFQUFDLHFCQUFxQjs7O3NCQVFOLEtBQUssRUFBQyxRQUFRO3NCQUN2QyxLQUFLLEVBQUMsYUFBYTs7O0VBRU8sS0FBSyxFQUFDLE1BQU07OztzQkFHdEMsS0FBSyxFQUFDLGNBQWM7Ozs7O0VBS1UsS0FBSyxFQUFDLGFBQWE7Ozs7O0VBSzlCLEtBQUssRUFBQyxRQUFROzs7RUFhbkMsS0FBSyxFQUFDLEtBQUs7RUFBQyxLQUF1QixFQUF2QixvQkFBdUI7Ozs7O0VBTUwsS0FBSyxFQUFDLGFBQWE7OztzQkFRakQsS0FBSyxFQUFDLEtBQUs7Ozs7O0VBYVEsS0FBSyxFQUFDLGNBQWM7O3NCQUNyQyxLQUFLLEVBQUMsYUFBYTtzQkFPZixLQUFLLEVBQUMsYUFBYTs7c0JBSWxCLEtBQUssRUFBQyxNQUFNOzs7RUFHTSxLQUFLLEVBQUMsTUFBTTs7OztFQUVILEtBQUssRUFBQyxRQUFROzs7O0VBQ3ZDLEtBQUssRUFBQyxLQUFLOzs7OztFQVFDLEtBQUssRUFBQyxnQkFBZ0I7O3NCQUl6QyxLQUFLLEVBQUMsYUFBYTtzQkFDbkIsS0FBSyxFQUFDLEtBQUs7OztFQU9TLEtBQUssRUFBQyxpQkFBaUI7O3NCQUM3QyxLQUFLLEVBQUMsUUFBUTtzQkFLWixLQUFLLEVBQUMsTUFBTTtzQkFRbEIsS0FBSyxFQUFDLGdCQUFnQjtzQkFPcEIsS0FBSyxFQUFDLGFBQWE7c0JBRWYsS0FBSyxFQUFDLGNBQWM7O3NCQVFqQixLQUFLLEVBQUMsTUFBTTs7O0VBR0ssS0FBSyxFQUFDLE1BQU07O3NCQUVsQyxLQUFLLEVBQUMsWUFBWTtzQkFJcEIsS0FBSyxFQUFDLEtBQUs7Ozs7d0JBbFB4QixvQkEyUE07S0ExUE8sZ0JBQVM7dUJBQXBCLG9CQUEyRCxPQUEzRCxVQUEyRCxtQkFBbEIsZ0JBQVM7U0FFN0IsYUFBTTt5QkFBM0Isb0JBdVBXO1lBdFBULG9CQVVNLE9BVk4sVUFVTTtjQVRKLG9CQUE4RDtnQkFBdEQsS0FBSyxFQUFDLE1BQU07Z0JBQUUsT0FBSyx1Q0FBRSxhQUFNLENBQUMsSUFBSTtpQkFBTyxRQUFNO2NBQ3JELG9CQUFpQyw2QkFBMUIsYUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLO2VBQ2IsYUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLO2lDQUE5QixvQkFBMkUsUUFBM0UsVUFBMkUsbUJBQTVCLGFBQU0sQ0FBQyxLQUFLLENBQUMsS0FBSzs7ZUFDckQsYUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLO2lDQUE5QixvQkFBMkUsUUFBM0UsVUFBMkUsbUJBQTVCLGFBQU0sQ0FBQyxLQUFLLENBQUMsS0FBSzs7Y0FDakUsb0JBQThGLFFBQTlGLFVBQThGLG1CQUF4RSxlQUFRLENBQUMsTUFBTSxJQUFHLFdBQVMsb0JBQUcsY0FBTyxDQUFDLGFBQU0sQ0FBQyxLQUFLLENBQUMsVUFBVTswQ0FDbkYsb0JBQTBCLFNBQXJCLEtBQUssRUFBQyxRQUFRO2NBQ25CLG9CQUE2QyxZQUFwQyxPQUFLLEVBQUUsaUJBQVUsSUFBRSxVQUFRO2NBQ3BDLG9CQUEyRjtnQkFBbkYsS0FBSyxFQUFDLE1BQU07Z0JBQUUsT0FBSyx1Q0FBRSxhQUFNLENBQUMsSUFBSSxXQUFXLGNBQU87aUJBQWMsWUFBVTtjQUNsRixvQkFBd0Q7Z0JBQWhELEtBQUssRUFBQyxTQUFTO2dCQUFFLE9BQUssRUFBRSxjQUFPO2lCQUFFLFFBQU07O1lBR2pELG9CQW9NTSxPQXBNTixVQW9NTTtjQW5NSiwrQkFBZTtjQUNmLG9CQW9CUSxTQXBCUixVQW9CUTttQ0FuQk4sb0JBZU0sNkJBZlcsY0FBTyxHQUFaLENBQUM7d0NBQWIsb0JBZU07b0JBZnFCLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRTs7b0JBQ2xDLG9CQUEyQyxNQUEzQyxVQUEyQyxtQkFBZixDQUFDLENBQUMsS0FBSzt1Q0FDbkMsb0JBWU0sNkJBWFMsQ0FBQyxDQUFDLFFBQVEsR0FBaEIsRUFBRTs0Q0FEWCxvQkFZTTt3QkFWSCxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUU7d0JBQ1gsS0FBSyxtQkFBQyxjQUFjLFlBQ0YsV0FBSSxlQUFlLGdCQUFTLEtBQUssRUFBRSxDQUFDLEVBQUU7d0JBQ3ZELE9BQUssYUFBRSxrQkFBVyxDQUFDLEVBQUU7O3dCQUV0QixvQkFHTyxRQUhQLFdBR087MEJBRkwsb0JBQWdHOzRCQUExRixLQUFLLG1CQUFDLEtBQUssRUFBUyxFQUFFLENBQUMsTUFBTTs0QkFBb0MsS0FBSyxFQUFFLEVBQUUsQ0FBQyxNQUFNOzsyQ0FBUyxJQUMvRixvQkFBRyxFQUFFLENBQUMsVUFBVSxJQUFHLElBQUUsb0JBQUcsRUFBRSxDQUFDLEtBQUs7O3dCQUVuQyxvQkFBK0MsUUFBL0MsV0FBK0MsbUJBQXpCLEVBQUUsQ0FBQyxVQUFVLElBQUcsSUFBRTs7Ozs7a0JBR2xDLGVBQVEsQ0FBQyxNQUFNO21DQUF6QixvQkFFSSxLQUZKLFdBRUksRUFGb0MsaURBRXhDOzs7Y0FHRixvQ0FBb0I7Y0FDcEIsb0JBMEtVLFdBMUtWLFdBMEtVO2dCQXpLUix1REFBdUM7aUJBQ3ZCLFdBQUk7bUNBQXBCLG9CQW1GVztzQkFsRlQsb0JBQXFFO3FFQUFqRSxPQUFLO3dCQUFBLG9CQUF1RCxRQUF2RCxXQUF1RCxFQUFwQyxJQUFFLG9CQUFHLG9CQUFhLElBQUcsVUFBUTs7c0JBRXpELG9CQUlNLE9BSk4sV0FJTTt3QkFISixvQkFFUzswQkFGRCxLQUFLLEVBQUMsU0FBUzswQkFBRSxRQUFRLEVBQUUsZUFBUSxJQUFJLGNBQU87MEJBQUcsT0FBSyxFQUFFLGFBQU07NENBQ2pFLGVBQVE7O3VCQUdOLGdCQUFTO3lDQUFsQixvQkFBdUQsS0FBdkQsV0FBdUQsbUJBQWhCLGdCQUFTOzt1QkFFckMsaUJBQVU7eUNBQXJCLG9CQWlCTSxPQWpCTixXQWlCTTs0QkFoQkosb0JBQStELDZCQUF4RCxpQkFBVSxDQUFDLGFBQWEsUUFBUSxvQkFBYTsrQ0FDcEQsb0JBS00sNkJBTFcsaUJBQVUsQ0FBQyxNQUFNLEdBQXRCLENBQUM7b0RBQWIsb0JBS007Z0NBTCtCLEdBQUcsRUFBRSxDQUFDLENBQUMsUUFBUTtnQ0FBRSxLQUFLLEVBQUMsWUFBWTs7Z0NBQ3RFLG9CQUEwQixXQUF2QixLQUFHLG9CQUFHLENBQUMsQ0FBQyxRQUFRO2lEQUFPLElBQ3pCLG9CQUFHLENBQUMsQ0FBQyxRQUFRLGNBQWEsR0FBQyxxQkFBSSxDQUFDLENBQUMsWUFBWSxRQUFRLElBQUksbUJBQWtCLEdBQzVFO2lDQUFXLENBQUMsQ0FBQyxJQUFJO21EQUFqQixvQkFBdUQsT0FBdkQsV0FBdUQsRUFBdkIsT0FBSyxvQkFBRyxDQUFDLENBQUMsSUFBSTs7aUNBQ25DLENBQUMsQ0FBQyxNQUFNO21EQUFuQixvQkFBeUMscUNBQWpCLENBQUMsQ0FBQyxNQUFNOzs7OzRCQUVsQyxvQkFPTSxPQVBOLFdBT007K0JBTlEsaUJBQVUsQ0FBQyxzQkFBc0IsRUFBRSxNQUFNO2lEQUFyRCxvQkFFTyxRQUZQLFdBRU8sRUFGb0UsTUFDdEUsb0JBQUcsaUJBQVUsQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLEVBQUUsSUFBSTs7K0JBRXRELGlCQUFVLENBQUMsdUJBQXVCLEVBQUUsTUFBTTtpREFBdEQsb0JBRU8sUUFGUCxXQUVPLEVBRnNFLE1BQ3hFLG9CQUFHLGlCQUFVLENBQUMsdUJBQXVCLENBQUMsSUFBSTs7OzZCQUd0QyxpQkFBVSxDQUFDLElBQUk7K0NBQTFCLG9CQUE0RSxPQUE1RSxXQUE0RSxFQUE5QixLQUFHLG9CQUFHLGlCQUFVLENBQUMsSUFBSTs7OztrREFHckUsb0JBQWlDLGVBQTFCLG9CQUFrQjtzQ0FDekIsb0JBQW9HO3FGQUFqRixnQkFBUyxDQUFDLE9BQU87d0JBQUUsSUFBSSxFQUFDLEdBQUc7d0JBQUMsV0FBVyxFQUFDLDZCQUE2Qjs7c0NBQXJFLGdCQUFTLENBQUMsT0FBTzs7a0RBQ3BDLG9CQUE4RDt5Q0FBdkQsT0FBSzt3QkFBQSxvQkFBMEMsVUFBcEMsS0FBSyxFQUFDLE1BQU0sSUFBQyxrQkFBZ0I7O3NDQUMvQyxvQkFBeUY7cUZBQXRFLGdCQUFTLENBQUMsYUFBYTt3QkFBRSxJQUFJLEVBQUMsR0FBRzt3QkFBQyxXQUFXLEVBQUMsWUFBWTs7c0NBQTFELGdCQUFTLENBQUMsYUFBYTs7c0JBQzFDLG9CQVFNLE9BUk4sV0FRTTt3QkFQSixvQkFFUzswQkFGRCxLQUFLLEVBQUMsU0FBUzswQkFBRSxRQUFRLEVBQUUsY0FBTyxJQUFJLGVBQVEsSUFBSSxzQkFBZTswQkFBRyxPQUFLLEVBQUUsY0FBTzs0Q0FDckYsY0FBTzt3QkFFWixvQkFFUzswQkFGQSxRQUFRLEVBQUUsY0FBTyxJQUFJLGVBQVEsSUFBSSxzQkFBZSxLQUFLLGdCQUFTLENBQUMsT0FBTyxDQUFDLElBQUk7MEJBQUssT0FBSyxFQUFFLHNCQUFlOzRDQUMxRyxzQkFBZTt3QkFFcEIsb0JBQXdEOzBCQUEvQyxRQUFRLEdBQUcsY0FBTzswQkFBRyxPQUFLLEVBQUUsYUFBTTsyQkFBRSxJQUFFOzt1QkFFeEMsaUJBQVU7eUNBQW5CLG9CQUF5RCxLQUF6RCxXQUF5RCxtQkFBakIsaUJBQVU7O3VCQUN6QyxvQkFBYTt5Q0FBdEIsb0JBQStELEtBQS9ELFdBQStELG1CQUFwQixvQkFBYTs7dUJBRTdDLGVBQVEsQ0FBQyxNQUFNO3lDQUExQixvQkFrQk0sT0FsQk4sV0FrQk07d0RBakJKLG9CQUdNLFNBSEQsS0FBSyxFQUFDLGFBQWE7OEJBQ3RCLG9CQUFtQixjQUFiLFFBQU07OEJBQ1osb0JBQTZDLFVBQXZDLEtBQUssRUFBQyxNQUFNLElBQUMscUJBQW1COzs0QkFFeEMsb0JBWU0sT0FaTixXQVlNO2lEQVhKLG9CQVVVLDZCQVZpQixlQUFRLEdBQW5CLE9BQU87c0RBQXZCLG9CQVVVO2tDQVY0QixHQUFHLEVBQUUsT0FBTyxDQUFDLEtBQUs7a0NBQUUsS0FBSyxFQUFDLGNBQWM7O2tDQUM1RSxvQkFHTSxPQUhOLFdBR007b0NBRkosb0JBQXVDLGdCQUEvQixLQUFHLG9CQUFHLE9BQU8sQ0FBQyxLQUFLO29DQUMzQixvQkFBb0QsUUFBcEQsV0FBb0QsbUJBQTlCLE9BQU8sQ0FBQyxVQUFVLElBQUcsSUFBRTs7a0NBRS9DLG9CQUFrRSxPQUFsRSxXQUFrRSxtQkFBeEIsT0FBTyxDQUFDLE9BQU87a0NBQ3pELG9CQUdNLE9BSE4sV0FHTTtvQ0FGSixvQkFBdUU7c0NBQS9ELEtBQUssRUFBQyxTQUFTO3NDQUFFLE9BQUssYUFBRSxvQkFBYSxDQUFDLE9BQU87dUNBQUcsUUFBTTtvQ0FDOUQsb0JBQW1EO3NDQUExQyxPQUFLLGFBQUUsa0JBQVcsQ0FBQyxPQUFPO3VDQUFHLE1BQUk7Ozs7Ozs7c0NBTWxELG9CQWlCTSxPQWpCTixXQWlCTTt3QkFoQkosb0JBR00sT0FITixXQUdNOzBCQUZKLG9CQUE4RCwrQkFBckQsY0FBTyx1QkFBdUIsZ0JBQVM7MkJBQ3BDLGVBQVEsQ0FBQyxNQUFNOzZDQUEzQixvQkFBOEQsUUFBOUQsV0FBOEQsRUFBcEIsZUFBYTs7O3dDQUV6RCxvQkFBb0g7dUZBQWpHLGFBQU07MEJBQUUsSUFBSSxFQUFDLElBQUk7MEJBQUMsS0FBSyxFQUFDLFFBQVE7MEJBQUUsV0FBVyxFQUFFLGNBQU87O3dDQUF0RCxhQUFNOzt3QkFDekIsb0JBSU0sT0FKTixXQUlNOzBDQUhKLG9CQUE2RDt5RkFBN0MsZ0JBQVM7NEJBQUUsS0FBSyxFQUFDLE1BQU07NEJBQUMsV0FBVyxFQUFDLE1BQU07OzBDQUExQyxnQkFBUzs7MEJBQ3pCLG9CQUE2RTs0QkFBcEUsUUFBUSxFQUFFLGNBQU87NEJBQUcsS0FBSyxFQUFFLFFBQVE7NEJBQUcsT0FBSyxFQUFFLGtCQUFXOzZCQUFFLEdBQUM7MEJBQ3BFLG9CQUFpSDs0QkFBekcsS0FBSyxFQUFDLFNBQVM7NEJBQUUsUUFBUSxHQUFHLGFBQU0sSUFBSSxjQUFPLElBQUksc0JBQWU7NEJBQUcsT0FBSyxFQUFFLHNCQUFlOzZCQUFFLE9BQUs7O3lCQUUvRixzQkFBZSxDQUFDLE1BQU07MkNBQWpDLG9CQUdNLE9BSE4sV0FHTTswREFGSixvQkFBcUMsVUFBL0IsS0FBSyxFQUFDLE1BQU0sSUFBQyxhQUFXO2lEQUM5QixvQkFBc0csNkJBQTdFLHNCQUFlLEdBQXhCLENBQUMsRUFBRSxDQUFDO3NEQUFwQixvQkFBc0c7a0NBQTNELEdBQUcsRUFBRSxDQUFDO2tDQUFFLEtBQUssRUFBQyxNQUFNO2tDQUFFLE9BQUssYUFBRSxnQkFBUyxDQUFDLENBQUM7b0RBQU0sQ0FBQzs7Ozt5QkFFbkYsVUFBRzsyQ0FBWixvQkFBcUU7OzhCQUF2RCxLQUFLLG1CQUFDLEtBQUssRUFBUyxZQUFLO2dEQUFvQixVQUFHOzt5QkFDckQsWUFBSyxLQUFLLFVBQUc7MkNBQXRCLG9CQUFnRyxLQUFoRyxXQUFnRyxFQUF6RCxVQUFRLHFCQUFJLFlBQUssQ0FBQyxXQUFXLFNBQVMsT0FBTyxPQUFNLElBQUU7OztpQ0FoQmpGLGFBQU0sSUFBSSxjQUFPOzs7bUNBcUJoQyxvQkFpRlc7c0JBbEZYLHlEQUF5QztzQkFFdkMsb0JBS0s7cUVBTEQsUUFFRjt3QkFBQSxvQkFFTzswQkFGRCxLQUFLLG1CQUFDLE9BQU8sRUFBUyxvQkFBYTs0Q0FDcEMsb0JBQWE7O2tEQUdwQixvQkFBaUIsZUFBVixJQUFFO3NCQUNULG9CQUtNLE9BTE4sV0FLTTt3Q0FKSixvQkFBOEM7dUZBQTlCLGNBQU8sQ0FBQyxLQUFLOzBCQUFFLEtBQUssRUFBQyxNQUFNOzt3Q0FBM0IsY0FBTyxDQUFDLEtBQUs7O3dCQUM3QixvQkFFUzswQkFGQSxRQUFRLEVBQUUsY0FBTzswQkFBRyxPQUFLLEVBQUUsa0JBQVc7NENBQzFDLGNBQU87O3VCQUdILHNCQUFlLENBQUMsTUFBTTt5Q0FBakMsb0JBR00sT0FITixXQUdNO3dEQUZKLG9CQUFxQyxVQUEvQixLQUFLLEVBQUMsTUFBTSxJQUFDLGFBQVc7K0NBQzlCLG9CQUFzRyw2QkFBN0Usc0JBQWUsR0FBeEIsQ0FBQyxFQUFFLENBQUM7b0RBQXBCLG9CQUFzRztnQ0FBM0QsR0FBRyxFQUFFLENBQUM7Z0NBQUUsS0FBSyxFQUFDLE1BQU07Z0NBQUUsT0FBSyxhQUFFLGdCQUFTLENBQUMsQ0FBQztrREFBTSxDQUFDOzs7O2tEQUU1RixvQkFBd0IsZUFBakIsV0FBUztzQ0FDaEIsb0JBQXdFO3FGQUFyRCxjQUFPLENBQUMsT0FBTzt3QkFBRSxJQUFJLEVBQUMsSUFBSTt3QkFBQyxLQUFLLEVBQUMsUUFBUTs7c0NBQXpDLGNBQU8sQ0FBQyxPQUFPOztrREFDbEMsb0JBQWlCLGVBQVYsSUFBRTtzQ0FDVCxvQkFBMEY7cUZBQXZFLGdCQUFTLENBQUMsT0FBTzt3QkFBRSxJQUFJLEVBQUMsR0FBRzt3QkFBQyxXQUFXLEVBQUMsbUJBQW1COztzQ0FBM0QsZ0JBQVMsQ0FBQyxPQUFPOztzQkFDcEMsb0JBU00sT0FUTixXQVNNO3dCQVJKLG9CQUF5RDswQkFBakQsS0FBSyxFQUFDLFNBQVM7MEJBQUUsT0FBSyxFQUFFLGlCQUFVOzJCQUFFLE1BQUk7d0JBQ2hELG9CQUFzQyxZQUE3QixPQUFLLEVBQUUsY0FBTyxJQUFFLE1BQUk7d0JBQzdCLG9CQUE2RDswQkFBckQsS0FBSyxFQUFDLFFBQVE7MEJBQUUsT0FBSyxFQUFFLHNCQUFlOzJCQUFFLE1BQUk7b0RBQ3BELG9CQUEwQixTQUFyQixLQUFLLEVBQUMsUUFBUTt3QkFDbkIsb0JBQXdGOzBCQUEvRSxRQUFRLEVBQUUsZUFBUTswQkFBRyxPQUFLLEVBQUUsY0FBTzs0Q0FBSyxlQUFRO3dCQUN6RCxvQkFFUzswQkFGRCxLQUFLLEVBQUMsU0FBUzswQkFBRSxRQUFRLEVBQUUsaUJBQVU7MEJBQUcsT0FBSyxFQUFFLGlCQUFVOzRDQUM1RCxpQkFBVTs7dUJBR1IsVUFBRzt5Q0FBWixvQkFBcUU7OzRCQUF2RCxLQUFLLG1CQUFDLEtBQUssRUFBUyxZQUFLOzhDQUFvQixVQUFHOztzQkFFOUQsNkJBQWE7dUJBQ0Ysa0JBQVc7eUNBQXRCLG9CQXVCTSxPQXZCTixXQXVCTTs0QkF0Qkosb0JBS00sT0FMTixXQUtNOzBEQUpKLG9CQUFpQixjQUFYLE1BQUk7OEJBQ1Ysb0JBRU87Z0NBRkQsS0FBSyxtQkFBQyxPQUFPLEVBQVMsa0JBQVcsQ0FBQyxPQUFPO2tEQUMxQyxrQkFBVyxDQUFDLE9BQU87OytDQUcxQixvQkFTTSw2QkFUaUIsa0JBQVcsQ0FBQyxNQUFNLEdBQTVCLEVBQUUsRUFBRSxDQUFDO29EQUFsQixvQkFTTTtnQ0FUc0MsR0FBRyxFQUFFLENBQUM7Z0NBQUUsS0FBSyxtQkFBQyxPQUFPLEVBQVMsRUFBRSxDQUFDLFFBQVE7O2dDQUNuRixvQkFLUSxTQUxSLFdBS1E7a0RBSk4sb0JBQStDO29DQUF4QyxJQUFJLEVBQUMsVUFBVTt1RUFBVSxFQUFFLENBQUMsUUFBUTs7c0RBQVgsRUFBRSxDQUFDLFFBQVE7O2tDQUMzQyxvQkFBd0U7b0NBQWxFLEtBQUssbUJBQUMsT0FBTyxPQUFjLEVBQUUsQ0FBQyxRQUFRO3NEQUFPLEVBQUUsQ0FBQyxRQUFRO2tDQUM5RCxvQkFBb0IsNEJBQWQsRUFBRSxDQUFDLElBQUk7a0NBQ2Isb0JBQTJDLFFBQTNDLFdBQTJDLG1CQUFyQixFQUFFLENBQUMsUUFBUTs7Z0NBRW5DLG9CQUErQiw4QkFBdkIsRUFBRSxDQUFDLFdBQVc7aUNBQ1gsRUFBRSxDQUFDLFVBQVU7bURBQXhCLG9CQUFtRSxPQUFuRSxXQUFtRSxFQUE1QixLQUFHLG9CQUFHLEVBQUUsQ0FBQyxVQUFVOzs7OzhCQUVsRCxrQkFBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNOytDQUFuQyxvQkFBNkQsS0FBN0QsV0FBNkQsRUFBVCxPQUFLOytDQUN6RCxvQkFJTSxPQUpOLFdBSU07a0NBSEosb0JBRVM7b0NBRkQsS0FBSyxFQUFDLFNBQVM7b0NBQUUsUUFBUSxFQUFFLGVBQVEsS0FBSyxxQkFBYyxDQUFDLE1BQU07b0NBQUcsT0FBSyxFQUFFLGVBQVE7c0RBQ2xGLGVBQVEsK0JBQStCLHFCQUFjLENBQUMsTUFBTTs7OztzQkFLckUsOEJBQWM7dUJBQ0gsb0JBQWE7eUNBQXhCLG9CQVNNLE9BVE4sV0FTTTt3REFSSixvQkFFTSxTQUZELEtBQUssRUFBQyxhQUFhOzhCQUN0QixvQkFBa0MsY0FBNUIsdUJBQXFCOzs0QkFFN0Isb0JBQWtELE9BQWxELFdBQWtELG1CQUF0QixvQkFBYTs0QkFDekMsb0JBR00sT0FITixXQUdNOzhCQUZKLG9CQUE4RDtnQ0FBdEQsS0FBSyxFQUFDLFNBQVM7Z0NBQUUsT0FBSyxFQUFFLHNCQUFlO2lDQUFFLE1BQUk7OEJBQ3JELG9CQUErQztnQ0FBdEMsT0FBSyx1Q0FBRSxvQkFBYTtpQ0FBTyxJQUFFOzs7O3NCQUkxQyw2QkFBYTt1QkFDRixxQkFBYzt5Q0FBekIsb0JBT00sT0FQTixXQU9NOzRCQU5KLG9CQUlJLEtBSkosV0FJSSxFQUpjLGNBQ0wsb0JBQUcscUJBQWMsQ0FBQyxrQkFBa0IsSUFBRyxZQUM3QyxvQkFBRyxxQkFBYyxDQUFDLHNCQUFzQixJQUFHLFlBQzNDLG9CQUFHLHFCQUFjLENBQUMsdUJBQXVCLElBQUcsS0FDbkQ7NEJBQ0Esb0JBQXdELE9BQXhELFdBQXdELEVBQXRDLE1BQUksb0JBQUcscUJBQWMsQ0FBQyxPQUFPOzs7Ozs7WUFNdkQsNkJBQWE7YUFDRixpQkFBVTsrQkFBckIsb0JBa0NNOztrQkFsQ2lCLEtBQUssRUFBQyxTQUFTO2tCQUFFLE9BQUssd0RBQU8saUJBQVU7O2tCQUM1RCxvQkFnQ00sT0FoQ04sV0FnQ007Z0RBL0JKLG9CQUFnQixZQUFaLFNBQU87Z0RBQ1gsb0JBQXdELE9BQXJELEtBQUssRUFBQyxNQUFNLElBQUMsc0NBQW9DO29CQUNwRCxvQkFHTTtzQkFIRCxLQUFLLEVBQUMsS0FBSztzQkFBQyxLQUF1QixFQUF2QixvQkFBdUI7O3NCQUN0QyxvQkFBNEMsWUFBbkMsT0FBSyxFQUFFLHNCQUFlLElBQUUsSUFBRTtzQkFDbkMsb0JBQXdDLFlBQS9CLE9BQUssRUFBRSxrQkFBVyxJQUFFLElBQUU7O29CQUVqQyxvQkFjTSxPQWROLFdBY007eUNBYkosb0JBV1csNkJBWFcsY0FBTyxHQUFaLENBQUM7OytCQUFtQixDQUFDLENBQUMsRUFBRTs7MEJBQ3ZDLG9CQUE2QyxPQUE3QyxXQUE2QyxtQkFBaEIsQ0FBQyxDQUFDLEtBQUs7NkNBQ3BDLG9CQVFRLDZCQVJZLENBQUMsQ0FBQyxRQUFRLEdBQWhCLEVBQUU7a0RBQWhCLG9CQVFROzhCQVJ5QixHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUU7OEJBQUUsS0FBSyxFQUFDLGFBQWE7OzhCQUM5RCxvQkFJRTtnQ0FIQSxJQUFJLEVBQUMsVUFBVTtnQ0FDZCxPQUFPLEVBQUUsZ0JBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUU7Z0NBQzVCLFFBQU0sYUFBRSxtQkFBWSxDQUFDLEVBQUUsQ0FBQyxFQUFFOzs4QkFFN0Isb0JBQWlELGNBQTNDLEdBQUMsb0JBQUcsRUFBRSxDQUFDLFVBQVUsSUFBRyxJQUFFLG9CQUFHLEVBQUUsQ0FBQyxLQUFLOzhCQUN2QyxvQkFBK0MsUUFBL0MsV0FBK0MsbUJBQXpCLEVBQUUsQ0FBQyxVQUFVLElBQUcsSUFBRTs7Ozs7d0JBR2xDLGVBQVEsQ0FBQyxNQUFNO3lDQUF6QixvQkFBb0QsS0FBcEQsV0FBb0QsRUFBWixVQUFROzs7b0JBRWxELG9CQUdRLFNBSFIsV0FHUTtzQ0FGTixvQkFBd0Q7d0JBQWpELElBQUksRUFBQyxVQUFVO3VGQUFVLDJCQUFvQjs7MENBQXBCLDJCQUFvQjs7bUVBQUksaUNBRTFEOztvQkFDQSxvQkFLTSxPQUxOLFdBS007c0JBSkosb0JBRVM7d0JBRkQsS0FBSyxFQUFDLFNBQVM7d0JBQUUsUUFBUSxHQUFHLGdCQUFTLENBQUMsSUFBSSxJQUFJLGdCQUFTO3dCQUFHLE9BQUssRUFBRSxlQUFROzBDQUM1RSxnQkFBUyx5QkFBeUIsZ0JBQVMsQ0FBQyxJQUFJO3NCQUVyRCxvQkFBK0M7d0JBQXRDLE9BQUsseUNBQUUsaUJBQVU7eUJBQVUsSUFBRSIsImlnbm9yZUxpc3QiOltdfQ==